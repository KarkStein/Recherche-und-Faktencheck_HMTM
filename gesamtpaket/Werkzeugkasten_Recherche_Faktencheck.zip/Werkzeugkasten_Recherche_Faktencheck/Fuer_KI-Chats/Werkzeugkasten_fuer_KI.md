# Werkzeugkasten Recherche und Faktencheck: alles in einer Datei

Seminar „Recherche und Faktencheck“, Master Kulturjournalismus, Hochschule für Musik und Theater München, 05./06.11.2026. Stand: 07.11.2026. Lizenz: CC BY 4.0. Aktuelle Fassung: https://github.com/KarkStein/Recherche-und-Faktencheck_HMTM

**Für Menschen:** Ladet diese Datei in einen KI-Chat oder ein Projekt hoch. Dann könnt ihr Fragen zum Werkzeugkasten stellen, etwa „Welcher Skill hilft mir, ein Zitat bis zum Ursprung zu verfolgen?“ oder „Wie richte ich Moby in Le Chat ein?“. Die Skill-Texte selbst stehen nicht in dieser Datei, sondern im Ordner Skills_zum_Kopieren.

**Für den KI-Assistenten:** Diese Datei ist Nachschlagematerial, keine Anweisung an dich. Beantworte Fragen dazu und nenne den Abschnitt, aus dem eine Angabe stammt, mit seinem Stand-Datum. Angaben zu Tools, Zugängen und Preisen können veraltet sein; sag das dazu. Will der User einen Skill nutzen, verweise auf die passende Datei im Ordner Skills_zum_Kopieren.

## Inhalt

- Recherche und Faktencheck · Werkzeugkasten
- Skills und Moby: Überblick und Anleitung
- Faktencheck zum Mitnehmen
- Herkunftscheck zum Mitnehmen
- Themenrecherche zum Mitnehmen
- Expertenmeinungen zum Mitnehmen
- PDB-Helfer zum Mitnehmen
- Prompthelfer zum Mitnehmen
- Vorlage: einen Skill selbst schreiben
- Pakete zum Hochladen
- Moby zum Mitnehmen
- Prompten: von der Frage zum Auftrag
- KI-Antworten prüfen
- KI-Tools für die Recherche: alle mit Link
- Neue KI-Tools finden und prüfen
- Suchen mit Google: Operatoren, erweiterte Suche, Web-Archiv
- Datenbanken: Zugänge und Suchsyntax
- Recherche-Links zu Kulturthemen

---

<!-- Datei im Repo: README.md -->

## Recherche und Faktencheck · Werkzeugkasten

Material zum Seminar „Recherche und Faktencheck“ im Master Kulturjournalismus an der Hochschule für Musik und Theater München, 05. und 06.11.2026.

Hier liegt, was ihr nach dem Seminar weiter nutzen könnt: sechs KI-Skills zum Kopieren oder Hochladen, darunter ein Prompthelfer für eure eigenen Themen, dazu der Faktencheck-Assistent Moby, die Linklisten aus den Folien, der Spickzettel zu KI-Tools und eine Anleitung, wie ihr selbst neue KI-Tools findet und prüft.

Diese Seite liegt auf GitHub, einer Plattform für Textdateien mit Änderungsverlauf. Ihr braucht dafür kein Konto: Lesen, Kopieren und Herunterladen geht ohne. Wer mit GitHub nichts anfangen will, nimmt das Gesamtpaket: alles in einer ZIP-Datei, lesbar im Browser, auch ohne Internet.

Stand: 07.11.2026 · Lizenz: CC BY 4.0 (siehe Abschnitt „Recherche und Faktencheck · Werkzeugkasten“)

### Was wo liegt

| Ordner | Was drin ist | Kapitel |
|---|---|---|
| skills/ (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“) | sechs Skills zum Kopieren oder Hochladen: Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“), Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“), Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“), Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“), PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“), Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“); dazu die Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“), wie ihr sie einsetzt | 2–5 |
| agent/ (siehe Abschnitt „Moby zum Mitnehmen“) | Moby (siehe Abschnitt „Moby zum Mitnehmen“), der Faktencheck-Assistent für Projekt, GPT oder Le-Chat-Agent | 5b |
| prompts/ (siehe Abschnitt „Prompten: von der Frage zum Auftrag“) | Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“), KI-Antworten prüfen (siehe Abschnitt „KI-Antworten prüfen“) | 4 |
| ki-tools/ (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“) | Spickzettel (Datei Spickzettel.pdf) als PDF, alle Tools mit Link (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“), Neue KI-Tools finden und prüfen (siehe Abschnitt „Neue KI-Tools finden und prüfen“) | 4, 6 |
| suche/ (siehe Abschnitt „Suchen mit Google: Operatoren, erweiterte Suche, Web-Archiv“) | Google: Operatoren, erweiterte Suche, Web-Archiv (siehe Abschnitt „Suchen mit Google: Operatoren, erweiterte Suche, Web-Archiv“); Datenbanken mit Zugang und Syntax (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“) | 2, 3 |
| links/ (siehe Abschnitt „Recherche-Links zu Kulturthemen“) | Recherche-Links zu Kulturthemen (siehe Abschnitt „Recherche-Links zu Kulturthemen“) | Anhang |
| gesamtpaket/ | alles in einer ZIP-Datei zum Herunterladen und Weitergeben | – |

Die Kapitel sind die der Seminarfolien. Jeder Ordner hat eine eigene Seite, die erklärt, was darin liegt.

### In zwei Minuten loslegen

1. Öffnet agent/moby/Moby_Faktencheck.md (Datei Skills_zum_Kopieren/Moby_Faktencheck.txt).
2. Klickt oben rechts über dem Text auf das Kopier-Symbol („Copy raw file“).
3. Fügt alles in einen KI-Chat mit Websuche ein und schickt es ab.
4. Nächste Nachricht: „Prüfe diesen Text:“ und darunter euer Text.

**Eigenes Thema?** Genauso mit dem Prompthelfer (Datei Skills_zum_Kopieren/Prompthelfer.txt): einfügen, abschicken, Thema nennen. Er fragt nach und schreibt mit euch den Prompt.

Habt ihr ein Konto bei Claude oder Gemini, könnt ihr die Skills auch hochladen. Dann starten sie in jedem Chat von selbst, sobald eure Frage passt. Wie das geht, auch für Projekte und Agenten, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

**Herunterladen:** das Gesamtpaket zum Lesen und Weitergeben. Oder die Dateien so, wie sie hier liegen: grüner Knopf „Code“, dann „Download ZIP“.

### Spielregeln für KI

1. Ein Konto ist freiwillig. Jede Übung geht auch ohne.
2. Keine Namen, Telefonnummern oder anderen persönlichen Daten in Prompts.
3. Nur Dokumente hochladen, die schon öffentlich zugänglich sind.
4. Wo es geht: Verlauf aus, Training abwählen.
5. Jeder Link wird geöffnet. Was nicht geöffnet wurde, gilt als nicht verifiziert.
6. KI-Text, den ihr übernehmt, kennzeichnet ihr.

### Prüfstufen

Wie im Seminar trägt jeder Link eine Prüfstufe:

- **geöffnet (mit Datum):** Die Seite wurde aufgerufen und die Angabe dort gesehen.
- **übernommen:** aus den Seminarfolien oder dem Spickzettel übernommen, für dieses Repo nicht erneut geöffnet.
- **zu prüfen:** nicht verifiziert.

Zugänge und Preise ändern sich schnell. Alle Angaben stehen mit Datum und ohne Gewähr. Findet ihr einen toten Link oder eine veraltete Angabe, schreibt Florian.

### Kleines Wörterbuch

- **Prompt:** die Frage oder Anweisung, die ihr einer KI schreibt.
- **Skill:** ein langer Prompt mit festen Regeln für eine Aufgabe, die immer wiederkommt. Manche Tools laden ihn von selbst, sobald eure Frage passt.
- **Assistent (Projekt, GPT, Agent):** ein eingerichteter Raum in einem KI-Tool, der eure Anweisungen für jeden neuen Chat behält.
- **Websuche und Seitenabruf:** ob eine KI im Netz suchen kann und ob sie gefundene Seiten auch öffnet. „Snippet“ heißt: Sie kennt nur den kurzen Ausschnitt aus dem Suchtreffer, nicht die Seite.
- **Repo (Repository):** diese Sammlung auf GitHub, ein öffentlicher Ordner mit Dateien und ihrem Änderungsverlauf.
- **.md (Markdown):** einfache Textdateien mit wenigen Zeichen für die Formatierung, etwa `#` für Überschriften. GitHub zeigt sie formatiert an, jedes Textprogramm öffnet sie.
- **ZIP:** ein gepackter Ordner. Entpacken: am Mac per Doppelklick, unter Windows mit Rechtsklick und „Alle extrahieren“.

### Lizenz

Texte und Skills in diesem Repo stehen unter [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.de): Ihr dürft sie teilen und verändern, auch für eure Arbeit, wenn ihr die Quelle nennt und angebt, was ihr geändert habt. Für verlinkte Angebote Dritter gelten deren Bedingungen.

Die Skills beruhen auf Assistenten, die Florian in der Redaktion nutzt, und sind für dieses Seminar umgebaut.

Für die Pflege des Repos: wartung/.

---

<!-- Datei im Repo: skills/README.md -->

## Skills und Moby: Überblick und Anleitung

Ein Skill ist ein Text mit Anweisungen und Regeln für eine Aufgabe, die immer wiederkommt, etwa einen Text auf Fakten prüfen. Jeder Skill liegt in einem eigenen Ordner, in der Datei `SKILL.md`. Oben in der Datei steht, wofür der Skill zuständig ist. Tools, die Skills kennen, laden ihn dann von selbst, sobald eure Frage passt. Alle anderen Tools bekommen denselben Text zum Einfügen. Programmieren müsst ihr dafür nichts.

Moby (siehe Abschnitt „Moby zum Mitnehmen“) ist kein Skill, sondern ein Assistent mit eigenem Raum: ein Projekt, ein GPT oder ein Le-Chat-Agent, in dem jede Nachricht ein Text zum Prüfen ist. Wie ihr ihn einrichtet, steht bei Moby.

### Die sechs Skills und Moby

| | Was er tut | Braucht Websuche? | Kapitel |
|---|---|---|---|
| Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) | prüft einen Text oder eine einzelne Behauptung, trennt widerlegt und nicht belegt | ja | 5b |
| Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) | verfolgt ein Zitat, eine Zahl oder Behauptung bis zum Ursprung | ja, am besten mit Seitenabruf | 5b |
| Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) | recherchiert ein Thema mit Belegen, Gegenprobe und Quellenkritik | ja | 2, 4 |
| Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“) | sortiert eine Debatte: Lager, Stimmen, Konsens und Streit, jede Position belegt | ja, am besten mit Seitenabruf | 4 |
| PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) | baut Suchstrings für SZ, F.A.Z., Genios/WISO und LexisNexis | hilfreich, nicht nötig | 3 |
| Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) | schreibt mit euch Prompts, Agenten-Aufträge und eigene Skills für ein selbst gewähltes Thema | nein | 4 |
| Moby (siehe Abschnitt „Moby zum Mitnehmen“) (Assistent) | prüft einen ganzen Text, in einem eigenen Projekt, GPT oder Agenten | ja | 5b |

Faktencheck und Moby prüfen nach derselben Methode. Den Unterschied erklärt die Seite zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).

### Welche Datei wofür

In jedem Skill-Ordner liegen die `SKILL.md` und eine README, die erklärt, was der Skill kann und wie ihr ihn fragt. Die Pakete zum Hochladen liegen gesammelt im Ordner `zum-hochladen` (siehe Abschnitt „Pakete zum Hochladen“).

Die `SKILL.md` ist die Langfassung: zum Einfügen in einen Chat, als Datei für ein Projekt und als Inhalt des Pakets zum Hochladen. Der Kopf oben mit `name` und `description` stört beim Einfügen nicht.

| | Langfassung | Kurzfassung | Paket zum Hochladen |
|---|---|---|---|
| Faktencheck | `SKILL.md` (Datei Skills_zum_Kopieren/Faktencheck.txt), 20.500 Zeichen | – (nehmt Moby kurz (Datei Skills_zum_Kopieren/Moby_kurz.txt)) | `faktencheck.zip` (Datei Skills_zum_Hochladen/faktencheck.zip) |
| Herkunftscheck | `SKILL.md` (Datei Skills_zum_Kopieren/Herkunftscheck.txt), 16.700 Zeichen | 3.600 Zeichen (Datei Skills_zum_Kopieren/Herkunftscheck_kurz.txt) | `herkunftscheck.zip` (Datei Skills_zum_Hochladen/herkunftscheck.zip) |
| Themenrecherche | `SKILL.md` (Datei Skills_zum_Kopieren/Themenrecherche.txt), 16.000 Zeichen | 3.600 Zeichen (Datei Skills_zum_Kopieren/Themenrecherche_kurz.txt) | `themenrecherche.zip` (Datei Skills_zum_Hochladen/themenrecherche.zip) |
| Expertenmeinungen | `SKILL.md` (Datei Skills_zum_Kopieren/Expertenmeinungen.txt), 22.000 Zeichen | 4.100 Zeichen (Datei Skills_zum_Kopieren/Expertenmeinungen_kurz.txt) | `expertenmeinungen.zip` (Datei Skills_zum_Hochladen/expertenmeinungen.zip) |
| PDB-Helfer | `SKILL.md` (Datei Skills_zum_Kopieren/PDB-Helfer.txt), 9.900 Zeichen | – | `pdb-helfer.zip` (Datei Skills_zum_Hochladen/pdb-helfer.zip) |
| Prompthelfer | `SKILL.md` (Datei Skills_zum_Kopieren/Prompthelfer.txt), 17.000 Zeichen | 5.200 Zeichen (Datei Skills_zum_Kopieren/Prompthelfer_kurz.txt) | `prompthelfer.zip` (Datei Skills_zum_Hochladen/prompthelfer.zip) |
| Moby | `Moby_Faktencheck.md` (Datei Skills_zum_Kopieren/Moby_Faktencheck.txt), 23.100 Zeichen | 4.600 Zeichen (Datei Skills_zum_Kopieren/Moby_kurz.txt) | – |

Nehmt, wenn möglich, die Langfassung: Nur sie enthält die Quellenregeln mit Beispielen und alle Sonderfälle. Die Kurzfassung ist für Anweisungsfelder mit Zeichenlimit.

### Kopieren und herunterladen ohne GitHub-Konto

1. Datei anklicken, etwa `herkunftscheck/SKILL.md`.
2. Oben rechts über dem Text auf das Symbol mit den zwei Rechtecken klicken („Copy raw file“). Der ganze Text liegt jetzt in der Zwischenablage.
3. Alternativ „Raw“ klicken, dann alles markieren und kopieren.

Ein Paket herunterladen: im Ordner `zum-hochladen/` (siehe Abschnitt „Pakete zum Hochladen“) die ZIP-Datei anklicken, dann oben rechts auf den Pfeil nach unten („Download raw file“).

Alles auf einmal: auf der Startseite des Repos grüner Knopf „Code“, dann „Download ZIP“.

### So geht's

**Überall, ohne Einrichtung**
1. Neuen Chat öffnen, Websuche einschalten, falls es dafür einen Schalter gibt.
2. Den ganzen Inhalt der `SKILL.md` einfügen und abschicken.
3. In der nächsten Nachricht euren Auftrag: den Text zum Prüfen, das Thema, das Zitat oder die Suchanfrage.

Der Skill gilt nur in diesem Chat. Für den nächsten Auftrag öffnet ihr einen neuen Chat und fügt ihn wieder ein, oder ihr richtet ihn dauerhaft ein (siehe unten).

**Als Skill in Claude** (Konto nötig, geht auch gratis)
1. Code-Ausführung einschalten: in den Einstellungen unter „Capabilities“. Skills brauchen sie, auch wenn diese Skills selbst keinen Code ausführen.
2. Das Paket herunterladen, etwa `herkunftscheck.zip`. Nicht entpacken.
3. In Claude: „Customize“, dann „Skills“, auf „+“ klicken, „Create skill“, „Upload a skill“, die ZIP-Datei wählen.
4. Den Skill eingeschaltet lassen. Ab jetzt startet er in jedem Chat von selbst, wenn eure Frage passt. Ihr könnt ihn auch beim Namen rufen: „Nutze den Herkunftscheck.“

**Als Skill in Gemini** (Google-Konto ab 18, in der Web-App oder der Mac-App)

Gems werden am 17.11.2026 schreibgeschützt und am 17.12.2026 gelöscht. An ihre Stelle treten Skills.
1. In Gemini in der Seitenleiste „Customize“, dann „Skills“, dann „Create“ und „Create manually“.
2. Name: der `name` aus dem Kopf der `SKILL.md`, etwa `herkunftscheck`. Beschreibung: der Text hinter `description`. Anweisungen: alles unter dem Kopf.
3. Speichern und im Chat loslegen.

Statt von Hand könnt ihr den Skill auch hochladen: Paket herunterladen und entpacken, dann bei einem angelegten Skill über „More options“ und „Replace skill“ den entpackten Ordner wählen. Der Ordner muss genauso heißen wie der Skill. Die Menünamen stammen aus der englischen Google-Hilfe, in der deutschen Oberfläche können sie anders heißen.

**Als Projekt in Claude oder ChatGPT**
1. Neues Projekt anlegen, etwa „Herkunftscheck“.
2. Die `SKILL.md` als Datei hochladen oder den Inhalt in die Projektanweisungen kopieren.
3. Falls ihr die Datei hochgeladen habt, in die Anweisungen schreiben: „Arbeite immer nach der Datei SKILL.md. Jede Nachricht ist ein neuer Auftrag.“
4. Im Projekt einen Chat starten und loslegen. Jeder neue Chat im Projekt kennt die Regeln.

**Als Agent in Le Chat**
1. Neuen Agenten anlegen.
2. Kurz- oder Langfassung in die Anweisungen kopieren, Websuche aktivieren.
3. Agent im Chat aufrufen und loslegen.

**Als GPT in ChatGPT:** Das Anweisungsfeld ist auf 8.000 Zeichen begrenzt, also die Kurzfassung nehmen, beim Faktencheck und beim PDB-Helfer die Datei hochladen. Ob ihr ohne Abo eigene GPTs anlegen könnt, ist nicht geprüft. Skills zum Hochladen gibt es in ChatGPT laut OpenAI bisher nur in Business, Enterprise und Edu.

**In Programmier-Werkzeugen** wie Claude Code, Gemini CLI oder GitHub Copilot: Diese Werkzeuge lesen Skill-Ordner mit `SKILL.md` direkt. Den entpackten Ordner in den Skill-Ordner des Werkzeugs legen.

Für Claude, ChatGPT, Gemini und Le Chat braucht ihr ein Konto. Ein Konto ist freiwillig. Welche Tools ohne Konto eine Websuche haben, steht in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“).

### Skills sind Text: erst lesen, dann hochladen

- Die Skills in diesem Repo sind reiner Text, ohne Skripte oder Programme. In jeder ZIP-Datei liegt nur die `SKILL.md`, die ihr hier lesen könnt.
- Fremde Skills lest ihr vor dem Hochladen. Ein Skill kann Anweisungen und Skripte enthalten, die euer Assistent dann befolgt oder ausführt. Im Juli 2026 zählte die Sicherheitsfirma Island über 800 gefälschte GitHub-Repos, die sich als KI-Skills oder MCP-Server tarnten und Schadsoftware verbreiteten. Mehr dazu in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

### Für alle Skills gilt

- **Öffnet die Links selbst.** Steht „Snippet“ oder „Snippet-Basis“ dabei, hat der Assistent nur den Suchtreffer gesehen, nicht die Seite.
- **Ein ✅ oder 🟢 heißt nicht, dass ihr nicht mehr nachschauen müsst.** Es heißt, dass der Assistent Belege gefunden hat.
- **Keine persönlichen Daten** und nur öffentliches Material in die Prompts (Spielregeln 2 und 3).
- **Die Verantwortung für euren Text bleibt bei euch.**

### Das würde die Skills noch besser machen

- **Eine eigene Quellenliste:** welche Quellen ihr zuerst nehmt, welche nie. Baut sie für euer Fachgebiet und hängt sie als Datei an.
- **Euer eigenes Material:** Rechercheordner, Protokolle, Dokumente als Dateien ins Projekt.
- **Pressedatenbanken:** Was die Skills hinter Bezahlschranken nicht finden, sucht ihr mit dem PDB-Helfer in den Datenbanken eurer Bibliothek.
- **Daten direkt:** Über MCP (Model Context Protocol) lassen sich Datenbanken und Dienste an KI-Assistenten anbinden. Mehr dazu in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).
- **Ein Ablauf statt eines einzelnen Prompts:** feste Schritte mit je eigenem Auftrag, etwa wichtige Fakten gründlich und Nebensachen schnell prüfen. Das braucht eine Plattform für solche Abläufe (Workflows).
- **Euer eigener Skill:** Was ihr zum zweiten Mal genauso macht, ist ein Skill. Ordner anlegen, darin eine `SKILL.md` mit `name` und `description` im Kopf und euren Regeln darunter. Die Skills hier sind Vorlagen dafür, ein leeres Gerüst liegt beim Prompthelfer (siehe Abschnitt „Vorlage: einen Skill selbst schreiben“), und der Prompthelfer baut einen Skill auch mit euch.

### Erst testen, dann nutzen

Nicht jeder Skill läuft in jedem Tool gleich gut. Probiert einen Skill zuerst mit einer Aufgabe aus, deren Ergebnis ihr kennt, etwa aus dem Seminar:

- **Moby und Faktencheck:** der Übungstext aus Kapitel 5b. Finden sie alle Fehler, und wo kommen sie ohne PDF nicht weiter?
- **Herkunftscheck:** die zentrale Zahl aus dem Übungstext. Kommt er bis zum Originaldokument?
- **Themenrecherche:** die Leitfrage aus Kapitel 4. Nennt er Primärquellen und markiert Unbelegtes?
- **Expertenmeinungen:** eine Kulturdebatte, etwa KI in der Musikproduktion. Leitet er die Lager aus den Treffern ab, hat jede Stimme eine Fundstelle, sind Snippets markiert?
- **PDB-Helfer:** eine Suche nach Interviews mit einer Person im SZ-Archiv und dieselbe Suche für WISO. Läuft der String ohne Fehlermeldung?
- **Prompthelfer:** ein selbst gewähltes Thema. Fragt er nach, bevor er schreibt? Steht der Prompt kopierfertig im Kasten, und läuft er in einem neuen Chat?
- **Hochladen:** Nimmt euer Tool das Paket an, und startet der Skill von selbst, ohne dass ihr ihn nennt?

Notiert euch pro Tool: läuft, läuft mit Einschränkung oder läuft nicht, und ein Stichwort, warum.

Ob Skills in Gemini den gespeicherten Verlauf voraussetzen, ist nicht geklärt. Das stünde gegen Spielregel 4 („Verlauf aus“). Ein Blog behauptet es, die Google-Hilfe sagt dazu nichts.

### Belege für die Angaben zu den Tools

- Claude Free: Websuche und bis zu fünf Projekte, laut [claude.com/pricing](https://claude.com/pricing), geöffnet am 31.10.2026.
- Skills in Claude für Free, Pro, Max, Ultra, Team und Enterprise, Code-Ausführung nötig, Hochladen als ZIP unter Customize > Skills, laut [Claude-Hilfe](https://support.claude.com/en/articles/12512180-use-skills-in-claude), geöffnet am 03.11.2026.
- Gems ab 17.11.2026 schreibgeschützt, ab 17.12.2026 entfernt; Skills für Personen ab 18 mit privatem Google-Konto; Hochladen nur in der Web-App und der Mac-App; Ordnername gleich Skillname, klein mit Bindestrich; höchstens 100 MB, laut [Gemini-Hilfe](https://support.google.com/gemini/answer/18560919?hl=en), geöffnet am 03.11.2026.
- Skills in ChatGPT für Business, Enterprise, Healthcare und Edu, laut [OpenAI-Hilfe](https://help.openai.com/en/articles/20001066-skills-in-chatgpt), übernommen aus dem Suchtreffer; die Seite war am 03.11.2026 nicht abrufbar.
- ChatGPT-Projekte für Free-Nutzer seit September 2025, laut [promptoptimizer.tools, 23.07.2026](https://promptoptimizer.tools/blog/how-to-use-chatgpt-projects), Drittquelle, geöffnet am 01.11.2026.
- GPT-Anweisungen höchstens 8.000 Zeichen, laut [OpenAI Developer Community, 04.06.2024](https://community.openai.com/t/how-can-i-increase-the-ceiling-for-gpt-instructions-beyond-8000-characters/801867), geöffnet am 01.11.2026. Ein neuerer Stand ist zu prüfen.
- Agents in Le Chat ohne Abo, aber mit Konto, laut Mistral-Hilfe, geprüft am 31.10.2026. Skills im Ordnerformat: in einer Websuche am 03.11.2026 kein Beleg gefunden.
- Programmier-Werkzeuge mit Skill-Ordnern, etwa die [Gemini CLI](https://geminicli.com/docs/cli/skills): übernommen, nicht geöffnet.

---

<!-- Datei im Repo: skills/faktencheck/README.md -->

## Faktencheck zum Mitnehmen

Der Faktencheck prüft einen Text oder eine einzelne Behauptung auf Faktentreue. Er zieht die prüfbaren Fakten heraus, sucht Belege und unterscheidet genau: **widerlegt** (❌) ist etwas anderes als **nicht belegt** (⭕) oder **nicht prüfbar** (❓). Bevor er „nicht belegt“ sagen darf, muss er sechs Rechercherouten durchlaufen. Jede Abweichung bewertet er mit dem Schadentest: Wie sehr schadet sie dem Text? Passt zu Kapitel 5b des Seminars.

Stand: 03.11.2026

### Faktencheck oder Moby?

Beide prüfen nach derselben Methode wie im Seminar. Der Unterschied liegt darin, wie ihr sie einsetzt:

| | Moby (siehe Abschnitt „Moby zum Mitnehmen“) | Faktencheck |
|---|---|---|
| Was es ist | ein Assistent mit eigenem Raum: Projekt, GPT oder Le-Chat-Agent | ein Skill, der in einem normalen Chat von selbst startet, wenn ihr um eine Prüfung bittet |
| Was ihr schickt | jede Nachricht ist der Prüftext | „Prüfe diesen Text: …“ oder „Stimmt es, dass …?“ |
| Einzelne Behauptung | prüft sie wie einen Text | eigener Kurzcheck mit kompakter Antwort |
| Status | ❌ heißt falsch oder nicht belegt | ❌ widerlegt und ⭕ nicht belegt sind getrennt |
| Am besten in | Claude-Projekt, ChatGPT-Projekt, GPT, Le-Chat-Agent | Claude und Gemini als hochgeladener Skill, sonst überall zum Einfügen |

In Gemini gibt es ab dem 17.11.2026 keine neuen Gems mehr. Dort nehmt ihr den Faktencheck als Skill.

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.800 Wörter, 20.500 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `faktencheck.zip` (Datei Skills_zum_Hochladen/faktencheck.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Eine Kurzfassung gibt es nicht. Für Anweisungsfelder mit Zeichenlimit nehmt die Kurzfassung von Moby (Datei Skills_zum_Kopieren/Moby_kurz.txt). Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann, am besten auch Seiten **öffnen und lesen**. Ohne Websuche liefert der Faktencheck nur die Liste der Fakten, die zu prüfen wären, und vergibt keinen Status.

### So fragt ihr

- „Prüfe diesen Text:“ und darunter euer Text
- „Faktencheck für diesen Artikel“ und darunter der Link
- „Stimmt es, dass Theater in Deutschland mehr Zuschauer haben als die Fußball-Bundesliga?“ (Kurzcheck)

### Das Ergebnis lesen

| Symbol | heißt |
|---|---|
| ✅ | zwei unabhängige Quellen gefunden, bei wichtigen Fakten eine davon gelesen |
| ⚠️ | Abweichung im Detail |
| ❌ | widerlegt: Eine belastbare Quelle zeigt das Gegenteil |
| ⭕ | nicht belegt: kein Beleg und kein Gegenbeleg, nach allen Rechercherouten |
| ❓ | nicht prüfbar, etwa weil Fachwissen oder ein Archivzugang fehlt |
| ⏰ | veraltet: stimmte zum Textdatum, hat sich seither geändert |
| ⏸️ | noch nicht geprüft. Schreibt „weiter“ |
| 🔴S / 🟡N | schwerwiegend / nicht gravierend, laut Schadentest |

- Fangt bei den **kritischen Befunden** an.
- **Öffnet die Links selbst.** „Snippet-Basis“ heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite.
- Ein ✅ heißt nicht, dass ihr nicht mehr nachschauen müsst. Die Verantwortung für euren Text bleibt bei euch.

### Grenzen

- **Keine Bezahlschranken:** Er umgeht sie nicht, sondern sucht frei zugängliche Fassungen oder bittet euch um den Text. Was nur in Pressedatenbanken steht, sucht ihr mit dem PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) und euren Bibliothekszugängen.
- **Einzelne Zitate und Zahlen:** Woher sie ursprünglich stammen, verfolgt der Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) gründlicher.
- **Nicht prüfbar:** Braucht eine Prüfung Fachwissen, interne Unterlagen oder einen Archivzugang, vergibt er ❓. Dann seid ihr dran.

### Herkunft

Diese Fassung beruht auf dem Faktencheck-Skill, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Quellenregeln eingebaut** als Kurzfassung, wie bei Moby. In der Redaktion hängt ein eigenes Regelwerk als Datei an.
- **Kein Plattformbezug:** keine Werkzeugnamen, keine festen Abrufzahlen, keine Übergabe an andere Assistenten.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind, die Hinweise zu Zuschreibungen, Bezugsgrößen und absoluten Aussagen aus Moby, Korrekturvorschläge und Zählprobe.

---

<!-- Datei im Repo: skills/herkunftscheck/README.md -->

## Herkunftscheck zum Mitnehmen

Der Herkunftscheck verfolgt **ein** Zitat, **eine** Zahl oder **eine** Behauptung rückwärts bis zum Ursprung: Wer hat das zuerst gesagt oder veröffentlicht, wann, wo und in welchem Wortlaut? Er läuft als Skill in einem KI-Assistenten mit Websuche und liefert eine Herkunftskette mit Belegen und einer Konfidenz.

Die Abgrenzung zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und zu Moby (siehe Abschnitt „Moby zum Mitnehmen“): Die prüfen, ob etwas stimmt, der Herkunftscheck fragt, woher es stammt, und geht bei einer einzelnen Aussage in die Tiefe. Passt zu Kapitel 5b des Seminars.

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.200 Wörter, 16.700 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Herkunftscheck_kurz.md` | rund 3.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `herkunftscheck.zip` (Datei Skills_zum_Hochladen/herkunftscheck.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

### Voraussetzung

Ein KI-Assistent mit **Websuche**, der Seiten auch **öffnen** kann. Nur dann kann er die Primärquelle selbst lesen und 🟢 vergeben. Kann er nur suchen, bittet er euch, die Quelle zu öffnen und den Absatz einzufügen. Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### So fragt ihr

Das Item möglichst wortgenau eingeben, mit der angeblichen Herkunft, wenn ihr sie kennt:

- „Woher stammt das Zitat ‚Kunst ist schön, macht aber viel Arbeit‘? Angeblich Karl Valentin.“
- „Woher kommt die Zahl, dass jede dritte Bühne in Deutschland Besucher verloren hat?“
- „In diesem Artikel steht eine Zahl zu den Besucherzahlen. Woher stammt sie?“ und darunter den Link

### Das Ergebnis lesen

| Symbol | heißt |
|---|---|
| 🟢 | Original im Volltext gelesen, Wortlaut oder Wert stimmt |
| 🟡 | stimmige Kette, aber das Original war nicht lesbar |
| 🟡ˢ | wie 🟡, nur aus Suchtreffer-Ausschnitten |
| 🟠 | widersprüchliche Zuschreibungen oder Wortlaute |
| 🔴 | Ursprung nicht belegbar |
| ⏸️ | unfertig: Primärquelle gefunden, aber noch nicht geöffnet. Schreibt „weiter“ |

- Die **Herkunftskette** steht mit dem jüngsten Beleg oben und dem Erstbeleg unten.
- Öffnet mindestens die unterste Station selbst. Erst dann zitiert ihr.
- Viele Treffer heißen nicht viele Belege: Medien, die sich aufeinander beziehen, sind eine Quelle.

### Grenzen

- **Ein Item pro Auftrag:** ein Zitat, eine Zahl oder eine Behauptung. Einen ganzen Text prüft der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Keine Bilder:** Woher ein Foto stammt, klärt eine Bild-Rückwärtssuche, nicht dieser Skill.
- **Keine Bezahlschranken:** Er umgeht sie nicht, sondern sucht frei zugängliche Fassungen oder bittet euch, die Quelle zu öffnen und den Absatz einzufügen.

### Herkunft

Diese Fassung beruht auf dem Herkunftscheck, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Kein Plattformbezug.** „Seite öffnen“ statt eines bestimmten Werkzeugs, keine Verweise auf andere Skills.
- **Quellenregeln eingebaut** als Kurzfassung, ohne Ausschlussliste mit Namen.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind. Beispiele ohne Redaktionsbezug. Als Skill-Ordner mit `SKILL.md`, damit er sich in Claude und Gemini hochladen lässt.

---

<!-- Datei im Repo: skills/themenrecherche/README.md -->

## Themenrecherche zum Mitnehmen

Die Themenrecherche ist ein Recherche-Skill, der in einem KI-Assistenten mit Websuche läuft. Ihr gebt ein Thema oder eine Frage ein, er sucht zuerst bei Primärquellen, belegt jeden Fakt mit Link, macht bei Streitthemen die Gegenprobe und schließt mit Quellenverzeichnis und Quellenkritik. Das ist die Arbeitsweise aus den Kapiteln 2 und 4 des Seminars.

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.100 Wörter, 16.000 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Themenrecherche_kurz.md` | rund 3.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `themenrecherche.zip` (Datei Skills_zum_Hochladen/themenrecherche.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Wenn ihr die Wahl habt, nehmt die Langfassung.

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann, am besten auch Seiten **öffnen und lesen**. Ohne Websuche liefert der Assistent nur einen Rechercheplan und keine Fakten. Wie ihr den Skill in Chat, Projekt, als hochgeladenen Skill oder als Agent einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### So fragt ihr

Einfach das Thema oder die Frage schreiben. Beispiele:

- „Recherchiere: Wie werden freie Theater in Bayern gefördert?“
- „Kurz: Wer leitet ab 2027 das Filmfest München?“
- „Deep Dive zur Debatte um Rückgaben von Kolonialobjekten aus Münchner Museen“
- „Was ist gerade los bei [Ereignis]?“ (News-Modus)
- „Gib mir eine kommentierte Quellenliste zu [Thema]“

„Kurz“ heißt 2–3 Suchen, „Deep Dive“ 8–15, ohne Angabe 4–7.

### Das Ergebnis lesen

- Der **Kernbefund** steht oben. Darunter steht, wie belastbar er ist.
- „Eingeschränkt belegt“ heißt: nur ein Quellentyp. Das ist eine Spur, kein Fakt.
- **Öffnet die Links selbst**, vor allem bei Zahlen und Zitaten. „Snippet-Basis“ heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite.
- Die **Quellenkritik** am Ende sagt, wo die Lücken sind und was ihr als Nächstes prüfen solltet.
- ⏸️ heißt: unfertig. Schreibt „weiter“, dann recherchiert er die offenen Punkte.

### Grenzen

- Sie kommt nicht hinter Bezahlschranken und nicht in Pressedatenbanken. Dafür gibt es den PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) und eure Bibliothekszugänge.
- Sie ersetzt keinen Anruf. Die Quellenkritik sagt euch, welcher Anruf am meisten absichert.
- Sie prüft keinen fertigen Text. Dafür gibt es den Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und Moby (siehe Abschnitt „Moby zum Mitnehmen“).
- Sie sortiert keine Debatte nach Stimmen und Lagern. Dafür gibt es Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“).

### Herkunft

Diese Fassung beruht auf dem Recherche-Assistenten, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Kein Plattformbezug** und keine Verweise auf andere Skills oder Zusatzdateien.
- **Quellenregeln eingebaut**, als Kurzfassung wie bei Moby, ohne Ausschlussliste mit Namen und ohne politische Einordnung einzelner Medien.
- **Neu:** der Check zu Beginn, ob Websuche und Datum verfügbar sind, und der Hinweis auf die Pressedatenbanken der Bibliothek bei Bezahlschranken.

---

<!-- Datei im Repo: skills/expertenmeinungen/README.md -->

## Expertenmeinungen zum Mitnehmen

Expertenmeinungen sortiert eine Debatte, statt sie zusammenzufassen: Welche Lager gibt es zu einem Thema, wer sind die wichtigsten Stimmen je Lager, wo sind sich alle einig und worüber wird gestritten? Jede Position ist mit einer Aussage und ihrer Fundstelle belegt. Der Skill läuft in einem KI-Assistenten mit Websuche.

Die Abgrenzung: Die Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) fragt „Was ist belegt?“, Expertenmeinungen fragt „Wer sagt was?“. Den Text, den ihr daraus schreibt, prüft der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) oder Moby (siehe Abschnitt „Moby zum Mitnehmen“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 3.000 Wörter, 22.000 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Expertenmeinungen_kurz.md` | rund 4.100 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `expertenmeinungen.zip` (Datei Skills_zum_Hochladen/expertenmeinungen.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Voraussetzung

Ein KI-Assistent mit **Websuche**, am besten einer, der Seiten auch **öffnen** kann. Nur dann darf er wörtlich zitieren. Kann er nur suchen, gibt er die Positionen mit eigenen Worten wieder und schreibt „Snippet-Basis“ dazu. Ohne Websuche nennt er keine Namen, sondern liefert einen Suchplan.

### So fragt ihr

- „Wie schätzen Fachleute KI in der Musikproduktion ein?“ (Themen-Dossier, Standard)
- „Welche Lager gibt es in der Debatte um die Rückgabe von Kolonialobjekten?“
- „Wen kann ich zur Förderung freier Theater in Bayern anfragen?“ (Expertenliste)
- „Was sagt [Name] zur Zukunft des Stadttheaters?“ (Kurzprofil einer Person)
- „Mach daraus ein Kompakt-Briefing“ oder „eine Zitat-Tabelle“

### Das Ergebnis lesen

- Oben steht die **Kurzantwort**, darunter die **Lage**, dann die **Debattenstränge** mit den Stimmen.
- Jede Person hat eine Nummer (E01, E02 …). Damit könnt ihr nachfragen: „E03 vertiefen“.
- **„Snippet-Basis“** heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite. Ein Zitat mit diesem Vermerk ist nicht wörtlich geprüft.
- Die **Einordnung** am Ende sagt, wessen Stimmen fehlen und welches Gespräch am meisten absichern würde.
- **Öffnet die Fundstelle**, bevor ihr jemanden zitiert. Prüft auch, ob die Funktion der Person noch stimmt.

### Grenzen

- **Wer etwas sagt, belegt nur, dass er es sagt.** Ob es stimmt, ist eine eigene Prüfung, etwa mit dem Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Nur öffentliche Stimmen** und ihre öffentlichen Aussagen. Private Angaben über Personen gehören nicht in den Prompt (Spielregel 2).
- **Keine Bezahlschranken:** Er umgeht sie nicht, vermerkt sie und sucht eine andere Quelle.
- **Drei Modi:** Themen-Dossier, Expertenliste und Kurzprofil. Eine Person über Jahre verfolgen kann er nicht (siehe Herkunft).

### Herkunft

Diese Fassung beruht auf dem Skill „Expertenmeinungen“, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Drei Modi statt sechs:** Themen-Dossier, Expertenliste, Positions-Kurzprofil. Das Voll-Tracking einer Person über Jahre und der Faktencheck einer Position fallen weg. Sie brauchen viele geöffnete Seiten und ein Belegregister, das in Gratis-Tools selten durchhält.
- **Eine Datei statt sieben:** Die sechs Zusatzdateien der Redaktionsfassung stehen als Text im Skill.
- **Dieselben Quellenregeln** wie in den anderen Skills dieses Repos, ergänzt um Regeln für Zitate, Mediatheken und Interessen.
- **Kein Plattformbezug:** keine Werkzeugnamen. HTML-Dossier und CSV nur, wenn euer Tool Dateien erzeugen kann.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind, Beispiele aus der Kultur, die Regel zu Personen ohne öffentliche Rolle.

---

<!-- Datei im Repo: skills/pdb-helfer/README.md -->

## PDB-Helfer zum Mitnehmen

Der PDB-Helfer baut euch Suchstrings für Pressedatenbanken (PDB): zwei kopierfertige Strings, einen engen und einen weiten, und erklärt jeden Baustein. Standard ist das Archiv der Süddeutschen Zeitung über die Stabi (Bayerische Staatsbibliothek). Auf Wunsch schreibt er den String für F.A.Z., Genios/WISO oder LexisNexis um. Ihr kopiert den String in die Datenbank, meldet die Trefferzahl zurück, und er justiert nach.

Passt zu Kapitel 3 des Seminars. Zugänge und Syntax aller Datenbanken stehen in Datenbanken: Zugänge und Suchsyntax (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 1.400 Wörter, 9.900 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen. Für GPTs mit 8.000 Zeichen Limit zu lang: dort als Datei hochladen |
| `pdb-helfer.zip` (Datei Skills_zum_Hochladen/pdb-helfer.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

### Voraussetzung

Ein beliebiger KI-Chat. Websuche ist hilfreich, um Schreibweisen und passende Begriffe zu finden, aber nicht nötig. Ohne Websuche schreibt der Helfer dazu, dass ihr Schreibweisen selbst prüfen sollt. Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Für die Datenbank selbst braucht ihr euren Ausweis der Stabi oder der Stadtbibliothek.

### So fragt ihr

- „Suchstring für Artikel über die Akustik der Isarphilharmonie“
- „Interviews mit Kirill Petrenko, nur die letzten zwei Jahre“
- „Das gleiche bitte für WISO“
- „Eng hatte 3 Treffer, weit 850“
- „Fehlermeldung: unerwartetes Suchelement“

### Das Ergebnis lesen

Ihr bekommt:

1. eine Zeile, was er zu Schreibweisen und Begriffen gefunden hat
2. **String eng** und **String weit**, jeweils zum Kopieren
3. eine kleine Tabelle: welcher Baustein was bewirkt
4. was ihr in der Suchmaske einstellen solltet (Zeitraum, Ressort, Artikeltyp)

Dann meldet ihr die Trefferzahlen. Ziel sind etwa 20 bis 100 Treffer. Der Helfer ändert pro Runde nur eine Stellschraube, damit ihr seht, was wirkt.

### Die wichtigsten Operatoren im SZ-Archiv

| Syntax | Bedeutung |
|---|---|
| `ATLEAST.5(Petrenko*)` | Wort kommt mindestens fünfmal vor |
| `NEAR.10(Petrenko, Philharmoniker)` | höchstens zehn Wörter Abstand |
| `ONEAR.3(Zauberflöte, Inszenierung)` | wie NEAR, in dieser Reihenfolge |
| `*philharmonie` | Linkstrunkierung, findet auch Isarphilharmonie |

Häufigster Fehler: mehrere Wörter in einer ATLEAST-Klammer. `ATLEAST.3(Oper* AND Intendant*)` geht nicht, richtig ist `ATLEAST.3(Oper*) AND ATLEAST.3(Intendant*)`.

### Grenzen

- **Er fragt die Datenbanken nicht selbst ab.** Die Suche macht ihr, er baut nur die Strings.

Nicht gesichert ist bisher:

- Ob `begriff#N` (F.A.Z., WISO) und `atleastN(…)` (LexisNexis) zusammen mit `*` funktionieren.
- Ob Linkstrunkierung außerhalb des SZ-Archivs geht.
- Ob die Suchmaske im SZ-Archiv einen Artikeltyp „Interview“ anbietet.

Testet das mit einer Suche, deren Treffer ihr ungefähr kennt. Mehr dazu in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Herkunft

Diese Fassung beruht auf dem Suchstring-Assistenten, den Florian in der Redaktion nutzt, umgebaut für den Bibliothekszugang. Was anders ist:

- **Nur die Operatoren von der Seminarfolie.** Die Redaktion arbeitet mit einem internen System und weiteren Feldcodes, etwa für Titel, Publikation oder Datum. Ob die im Bibliothekszugang funktionieren, ist nicht geprüft. Zeitraum, Ressort und Artikeltyp stellt ihr deshalb in der Suchmaske ein.
- **Keine Quellenlisten und Publikationscodes** der Redaktion.
- **Neu:** Umrechnung für F.A.Z., Genios/WISO und LexisNexis, Erklärung jedes Bausteins, funktioniert auch ohne Websuche.

---

<!-- Datei im Repo: skills/prompthelfer/README.md -->

## Prompthelfer zum Mitnehmen

Der Prompthelfer schreibt mit euch einen Prompt für ein Thema, das ihr euch selbst aussucht, egal welches. Er fragt nach, was ihr vorhabt, schlägt die passende Form vor und liefert einen fertigen Prompt zum Kopieren, dazu kurz, warum er so gebaut ist. Den Prompt setzt ihr dann in einem neuen Chat ein.

Stand: 05.11.2026

### Was er kann

| Ihr wollt … | Er liefert |
|---|---|
| einmal eine Antwort auf eine Frage | eine Einzelfrage: Zweck, Kontext, Frage, Quellen, Output |
| ein Tool selbst suchen lassen (Deep Research, Agent) | einen Agenten-Auftrag: Ziel, erst der Plan, Grenzen, Belege, Format |
| dieselbe Aufgabe öfter erledigen | einen eigenen Skill, kurz genug für jedes Anweisungsfeld |
| euren eigenen Prompt besser machen | eine Rückmeldung mit ✓ ~ ✗ und eine verbesserte Fassung |
| einen Skill aus dem Netz in eurem Chat nutzen | eine Fassung ohne Skripte und Befehle |

Habt ihr erst ein Thema und noch keine Frage, schlägt er euch drei mögliche Zugänge vor.

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.700 Wörter, 17.000 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Prompthelfer_kurz.md` | rund 5.200 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) oder Chats, in die die Langfassung nicht passt |
| `prompthelfer.zip` (Datei Skills_zum_Hochladen/prompthelfer.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |
| `Vorlage_Skill.md` | rund 2.000 Zeichen | leeres Gerüst, um einen Skill ohne KI selbst zu schreiben |

### Voraussetzung

Ein KI-Chat, egal welcher. Der Prompthelfer braucht **keine Websuche**, weil er nur Prompts schreibt und nicht recherchiert. Er läuft also auch in Tools ohne Konto (siehe Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“)). Wie ihr ihn einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Den fertigen Prompt setzt ihr in einem **neuen** Chat ein. Geht es um Fakten, in einem mit Websuche.

### So fragt ihr

Nach dem Einfügen fragt er: „Was ist dein Thema, und was soll die KI für dich tun?“ Dann zum Beispiel:

- „Mein Thema: Dirigentinnen in Deutschland. Ich will einen Überblick für ein Referat.“
- „schnell: Ich brauche Interviewfragen für ein Gespräch mit einer Bühnenbildnerin.“
- „Verbessere meinen Prompt:“ und darunter euren Prompt
- „Ich will mit Deep Research herausfinden, wie sich die Förderung freier Theater in Bayern seit 2020 entwickelt hat.“
- „Ich schreibe jede Woche eine Konzertankündigung. Bau mir einen Skill dafür.“
- „Bau diesen Skill so um, dass er in Gemini läuft:“ und darunter den Text der Datei

Mit „schnell“ bekommt ihr sofort einen Entwurf. Ohne fragt er erst kurz nach, höchstens drei Fragen auf einmal.

### Das Ergebnis lesen

- **Der Prompt steht im Kasten.** Oben rechts am Kasten ist meist ein Kopier-Symbol.
- **[Eckige Klammern]** sind Platzhalter. Ersetzt sie, bevor ihr den Prompt abschickt.
- **„Warum so“** erklärt in zwei, drei Punkten, welcher Baustein was bewirkt. Das ist der Teil, aus dem ihr lernt, wie ihr es beim nächsten Mal selbst macht.
- **Passt die Antwort nicht,** bringt sie zurück: „Die Antwort war zu lang“ oder „Da sind keine Quellen drin“. Er sagt, welcher Baustein gefehlt hat, und schärft den Prompt nach.

### Grenzen

- **Ein guter Prompt macht gute Antworten wahrscheinlicher, nicht sicher.** Öffnet die Quellen selbst, bevor ihr etwas übernehmt. Wie, steht in KI-Antworten prüfen (siehe Abschnitt „KI-Antworten prüfen“).
- **Keine persönlichen Daten** in Prompts, nur öffentliches Material (Spielregeln 2 und 3).
- **Der Prompthelfer ist selbst eine KI.** Was er über Funktionen einzelner Tools sagt, kann veraltet sein.

### Herkunft

Neu für dieses Seminar, nicht aus der Redaktion. Der Prompthelfer baut auf den Checklisten aus Kapitel 4 auf: Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“) und ROMANE.

---

<!-- Datei im Repo: skills/prompthelfer/Vorlage_Skill.md -->

## Vorlage: einen Skill selbst schreiben

Ein leeres Gerüst für einen eigenen Skill, zum Ausfüllen von Hand, ohne KI und ohne Konto. Es hat denselben Aufbau, den auch der Prompthelfer (Datei Skills_zum_Kopieren/Prompthelfer.txt) im Modus „Skill bauen“ nutzt. Stand: 05.11.2026.

### So geht's

1. Den Kasten unten kopieren.
2. Alles in [eckigen Klammern] ersetzen. Abschnitte, die ihr nicht braucht, streichen.
3. Unter rund 7.500 Zeichen bleiben, dann passt der Skill in jedes Anweisungsfeld.
4. Einsetzen wie die anderen Skills, siehe Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).
5. Ausprobieren, Antwort ansehen, nachschärfen. Das ist das E in ROMANE.

```
# [Name]: [was er tut, in einem Halbsatz]

Du [Rolle und Aufgabe in ein, zwei Sätzen]. Für [wen]. Sprache: [Sprache].

## Auftrag und wann er erfüllt ist
[Woran man ein fertiges Ergebnis erkennt.]

## Bevor du anfängst
[Nur wenn nötig, etwa: Prüfe, ob du im Web suchen kannst. Wenn nicht, sag das im ersten Satz. Kennst du das heutige Datum nicht sicher, frag danach.]

## Feste Regeln
1. [...]
2. [...]

## Vorgehen
1. [...]
2. [...]

## Ausgabe
[Format, bei jedem Lauf gleich, mit einem kurzen Beispiel.]

## Wenn etwas fehlt
[Was er tut, wenn Angaben fehlen oder etwas nicht zu finden ist: nachfragen, kennzeichnen, nichts erfinden.]

## Nach der Antwort
[Zwei, drei Angebote für den nächsten Schritt.]
```

### Zeilen, die oft passen

Sucht der Skill im Netz, gehören diese Regeln hinein:

```
Belege jede Zahl und jedes Zitat mit Link und dem wörtlichen Satz aus der Quelle. Schreib dazu, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst. Markiere, was du nicht belegen kannst.
Links nur aus Suchergebnissen, geöffneten Seiten oder meinem Material, nie aus dem Gedächtnis.
Primärquellen vor Presseberichten. Wikipedia und KI-Zusammenfassungen sind keine Belege.
```

Arbeitet er mit eurem Material:

```
Arbeite nur mit den Dateien und Texten, die ich dir gebe. Sag, wenn etwas darin nicht steht.
```

Weitere Bausteine stehen in Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“).

---

<!-- Datei im Repo: skills/zum-hochladen/README.md -->

## Pakete zum Hochladen

Hier liegt jeder Skill als ZIP-Datei, also als gepackter Ordner. In dieser Form nehmen Claude und Gemini Skills an. In jedem Paket liegt nur die `SKILL.md` aus dem Ordner des Skills. Ihr könnt sie vorher dort lesen.

| Paket | Skill |
|---|---|
| faktencheck.zip (Datei Skills_zum_Hochladen/faktencheck.zip) | Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) |
| herkunftscheck.zip (Datei Skills_zum_Hochladen/herkunftscheck.zip) | Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) |
| themenrecherche.zip (Datei Skills_zum_Hochladen/themenrecherche.zip) | Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) |
| expertenmeinungen.zip (Datei Skills_zum_Hochladen/expertenmeinungen.zip) | Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“) |
| pdb-helfer.zip (Datei Skills_zum_Hochladen/pdb-helfer.zip) | PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) |
| prompthelfer.zip (Datei Skills_zum_Hochladen/prompthelfer.zip) | Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) |

### So geht's

1. Paket anklicken, dann oben rechts auf den Pfeil nach unten („Download raw file“).
2. **Claude:** nicht entpacken, die ZIP-Datei so hochladen. **Gemini:** erst entpacken, dann den Ordner hochladen.

Schritt für Schritt steht es in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

---

<!-- Datei im Repo: agent/moby/README.md -->

## Moby zum Mitnehmen

Moby ist ein Faktencheck-Assistent. Er prüft einen Text in vier Schritten (Fakten herausziehen, in Aspekte zerlegen, prüfen, Bericht) und liefert einen Bericht mit Status, Quellen und Korrekturvorschlägen. Das ist dieselbe Methode wie im Seminar, Kapitel 5b.

Moby ist kein Skill, sondern ein Assistent mit eigenem Raum. Ihr richtet ihn einmal als Projekt, GPT oder Le-Chat-Agent ein, und dort ist jede Nachricht ein Text zum Prüfen. Wollt ihr dieselbe Prüfung in einem normalen Chat, der von selbst erkennt, wann geprüft werden soll, nehmt den Skill Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“). Den Unterschied erklärt die Seite zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `Moby_Faktencheck.md` | rund 3.200 Wörter, 23.100 Zeichen | Langfassung: in einen Chat einfügen oder als Datei in ein Projekt legen |
| `Moby_kurz.md` | rund 4.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit |

Wenn ihr die Wahl habt, nehmt die Langfassung. Sie enthält die Quellenregeln und Beispiele, die Kurzfassung nur das Gerüst.

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann. Ohne Websuche erfindet ein Modell im schlimmsten Fall Quellen. Moby ist so gebaut, dass er dann ablehnt und nur die Prüfliste liefert. Noch besser ist ein Tool, das gefundene Seiten auch **öffnen und lesen** kann, nicht nur die Suchtreffer.

Ein Konto anzulegen ist freiwillig. Ohne Konto: Langfassung in einen Chat kopieren, der eine Websuche hat (welche das sind, steht in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“)).

### So richtet ihr Moby ein

**Überall, ohne Einrichtung**
1. Neuen Chat öffnen, Websuche einschalten, falls es dafür einen Schalter gibt.
2. Den ganzen Inhalt von `Moby_Faktencheck.md` einfügen und abschicken.
3. In der nächsten Nachricht: „Prüfe diesen Text:“ und darunter euren Text.

**Als Projekt in Claude oder ChatGPT**
1. Neues Projekt anlegen.
2. `Moby_Faktencheck.md` als Datei hochladen, oder den Inhalt in die Projektanweisungen kopieren.
3. Falls ihr die Datei hochgeladen habt, in die Anweisungen schreiben: „Arbeite immer nach der Datei Moby_Faktencheck.md. Jede Nachricht ist der zu prüfende Text.“
4. Im Projekt einen Chat starten und den Text einfügen.

**Als Agent in Le Chat**
1. Neuen Agenten anlegen.
2. Kurz- oder Langfassung in die Anweisungen kopieren, Websuche aktivieren.
3. Agent im Chat aufrufen und den Text einfügen.

**Als GPT in ChatGPT:** Das Anweisungsfeld ist auf 8.000 Zeichen begrenzt, also die Kurzfassung nehmen. Ob ihr ohne Abo eigene GPTs anlegen könnt, ist nicht geprüft.

**In Gemini:** Gems werden am 17.11.2026 schreibgeschützt und am 17.12.2026 gelöscht. Einen festen Raum wie ein Gem gibt es dann nicht mehr. Nehmt in Gemini den Skill Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“), wie ihr ihn einrichtet, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Woher die Angaben zu den Tools stammen, steht unter Belege für die Angaben zu den Tools (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Das Ergebnis lesen

- Fangt bei den kritischen Befunden an.
- Öffnet die Links selbst. Steht „Snippet“ oder „Nur Snippet-Basis“ dabei, hat Moby nur den Suchtreffer gesehen, nicht die Seite.
- Ein ✅ heißt: zwei unabhängige Quellen gefunden. Es heißt nicht, dass ihr nicht mehr nachschauen müsst.
- Die Verantwortung für euren Text bleibt bei euch.

### Grenzen

- **Erst testen:** Moby läuft nicht in jedem Tool gleich gut. Probiert ihn zuerst mit einem Text aus, dessen Fehler ihr kennt, etwa dem Übungstext aus Kapitel 5b. Mehr dazu unter Erst testen, dann nutzen (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).
- **Ein Status für zwei Fälle:** ❌ heißt bei Moby falsch oder nicht belegt. Wer das getrennt braucht, nimmt den Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Keine Bezahlschranken:** Moby umgeht sie nicht. Was er nicht findet, sucht ihr in der Pressedatenbank eurer Bibliothek, Suchstrings dafür baut der PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“).
- **Besser machen:** mit einer eigenen Quellenliste, eurem Material als Dateien im Projekt oder angebundenen Datenbanken. Wie, steht unter Das würde die Skills noch besser machen (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Herkunft

Diese Fassung beruht auf dem Moby, den Florian in der Redaktion nutzt, und ist so umgebaut, dass sie auf verschiedenen Plattformen läuft. Was anders ist:

- **Kein Plattformbezug.** Die Redaktionsfassung ist auf eine bestimmte KI-Plattform und deren Werkzeuge eingestellt (etwa wie viele Seiten pro Antwort geöffnet werden dürfen). Hier steht stattdessen: Wenn du Seiten öffnen kannst, öffne zuerst die Quellen der wichtigsten Fakten.
- **Quellenregeln eingebaut.** In der Redaktion hängt ein eigenes Quellenregelwerk als Datei an. Hier steht eine Kurzfassung direkt im Prompt.
- **Keine Ausschlussliste mit Namen.** Das Regelwerk der Redaktion nennt Medien, die nie als Quelle zählen. In dieser Fassung stehen nur die Muster, nach denen eine Quelle ausgeschlossen wird.
- **Neu:** ein Check zu Beginn, ob Websuche und Datum verfügbar sind, und ein Hinweis zu Grauzonen und absoluten Aussagen.

---

<!-- Datei im Repo: prompts/recherche-auftrag.md -->

## Prompten: von der Frage zum Auftrag

Aus Kapitel 4 des Seminars. Stand: 01.11.2026.

**Wichtigste Botschaft: Schreibt das, was ihr bekommen wollt.** Und übernehmt nur, was ihr in der Quelle selbst gesehen habt.

Hilfe beim Schreiben: Der Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) geht diese Checklisten mit euch durch und schreibt den Prompt für euer eigenes Thema.

### Zwei Arten zu fragen

| Einzelne Frage | Auftrag an einen Agenten oder Prozess |
|---|---|
| **Zweck:** wofür ihr die Antwort braucht | **Ziel:** Wann ist der Auftrag erledigt? |
| **Kontext:** was ihr schon wisst, für wen | **Erst der Plan:** zeigen lassen, dann starten |
| **Quellen:** welche zählen, mit Link und Zitat | **Grenzen:** welche Quellen, nichts senden, nichts kaufen |
| **Output:** Liste, Tabelle, Länge | **Belege:** Zwischenschritte und Quellen sichtbar |
| **Nachhaken** statt neu anfangen | **Format:** bei jedem Lauf gleich |

Links steht, was eine einzelne Frage an einen Chat besser macht. Rechts steht, was ein Tool zusätzlich braucht, das selbstständig in Schleifen sucht, etwa Deep Research: Es muss wissen, wann es fertig ist, was es nicht darf und wie das Ergebnis aussieht. Den Plan vorher anzusehen spart Fehlläufe.

### Vorlage: einzelne Frage

Ersetzt die eckigen Klammern. Das Beispiel ist erfunden und nicht geprüft.

```
Zweck: Ich schreibe [eine Meldung / ein Porträt / eine Vorrecherche] über [Thema].
Kontext: Ich weiß schon [was ihr wisst]. Der Text ist für [Publikum, Medium].
Frage: [eure Frage, so konkret wie möglich]
Quellen: Nutze vor allem [Primärquellen: Stadt, Ministerium, Veranstalter, Statistik]. Belege jede Zahl und jedes Zitat mit Link und dem wörtlichen Satz aus der Quelle. Wikipedia und KI-Zusammenfassungen sind keine Belege.
Output: [eine Tabelle mit Spalten ... / fünf Stichpunkte / höchstens 200 Wörter]. Markiere, was du nicht belegen kannst.
```

Beispiel:

```
Zweck: Ich schreibe eine kurze Meldung für ein Kulturmagazin.
Kontext: Ich weiß, dass die staatlichen Museen in Bayern ihre Eintrittspreise 2026 geändert haben sollen, kenne aber keine Details.
Frage: Was hat sich bei den Eintrittspreisen geändert, ab wann, und welche Häuser betrifft es?
Quellen: Nutze die Websites der Museen und des zuständigen Ministeriums zuerst. Belege jede Zahl mit Link und wörtlichem Satz.
Output: Tabelle mit Haus, Preis vorher, Preis nachher, gültig ab, Quelle. Darunter zwei Sätze zur Einordnung. Markiere, was du nicht belegen kannst.
```

**Nachhaken statt neu anfangen:** Im selben Chat weiterfragen. „Was spricht dagegen?“, „Welche Quelle davon hast du geöffnet?“, „Zeig mir den wörtlichen Satz zu Zahl 3.“

### Vorlage: Auftrag an einen Agenten

Für Deep Research, Claude Research oder andere Tools, die selbstständig suchen.

```
Ziel: Der Auftrag ist erledigt, wenn [die Frage beantwortet ist / jede der fünf Fragen einen Beleg hat / klar ist, was sich nicht belegen lässt].
Erst der Plan: Zeig mir zuerst deinen Suchplan in Stichpunkten und warte auf mein Okay.
Grenzen: Nutze nur [öffentliche Quellen / diese Websites / Quellen ab Jahr X]. Nichts senden, nichts kaufen, keine Formulare ausfüllen, keine Konten anlegen.
Belege: Nenne zu jeder Aussage die Quelle mit Link. Schreib dazu, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst.
Format: [Gliederung, die bei jedem Lauf gleich bleibt, etwa: Kurzbefund, Tabelle der Fakten, offene Fragen, Quellenverzeichnis].
```

### Regeln einmal aufschreiben: das Projekt

Gebt ihr denselben Auftrag öfter, speichert die Regeln. In Claude heißt das Projekt, in ChatGPT ebenfalls Projekt, in Le Chat Agent. In Gemini hieß es Gem; Gems werden ab dem 17.11.2026 durch Skills ersetzt. Ein Projekt bündelt Anweisungen und Dateien. Jeder neue Chat im Projekt kennt beide.

Vorlage für die Anweisungen eines Recherche-Projekts:

```
Belege jede Zahl mit Link und wörtlichem Zitat.
Primärquellen vor Presseberichten.
Markiere, was du nicht belegen kannst.
Nutze zuerst die Dateien in diesem Projekt, dann die Websuche.
Sag, wenn eine Frage mit den Dateien nicht zu beantworten ist.
```

Testet die dritte Regel mit einer Fangfrage, deren Antwort nicht in euren Dateien steht. Gute Antwort: „Dazu steht nichts in den Dokumenten.“

Fertige, längere Anweisungen für wiederkehrende Aufgaben findet ihr unter skills/ (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“). Wie ihr sie in Chat, Projekt, als Skill oder Agent einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Ein mögliches Regelwerk: ROMANE

Aus dem Seminar, als Gedächtnisstütze:

- **R**olle: in welcher Funktion, für wen
- **O**bjective: das Ziel
- **M**eta-Anweisungen: wie vorgehen, was beachten
- **A**nwendungsbeispiele: zeigen, wie das Ergebnis aussehen soll
- **N**icht zu lang
- **E**xperimentieren

„Schritt für Schritt denken“ müsst ihr Reasoning-Modellen nicht mehr sagen, sie tun es von selbst.

---

<!-- Datei im Repo: prompts/ki-antworten-pruefen.md -->

## KI-Antworten prüfen

Aus Kapitel 4 des Seminars und dem Spickzettel (Datei Spickzettel.pdf). Stand: 01.11.2026.

**Die Fußnote zeigt, wo gesucht wurde, nicht, was belegt ist.**

### Warum prüfen?

- **Tow Center, März 2025:** Acht KI-Suchen sollten zu Zitaten den Originalartikel finden. Über 60 % der Antworten waren falsch. Perplexity war am besten und lag trotzdem in 37 % daneben. Quelle: [Nieman Lab, 10.03.2025](https://www.niemanlab.org/2025/03/ai-search-engines-fail-to-produce-accurate-citations-in-over-60-of-tests/)
- **EBU und BBC, 2025:** 22 öffentlich-rechtliche Sender aus 18 Ländern prüften über 3.000 Antworten von KI-Assistenten auf Nachrichtenfragen. 45 % hatten mindestens einen erheblichen Fehler, 31 % Probleme mit den Quellen. Quelle: [journalism.co.uk, 14.11.2025](https://www.journalism.co.uk/nearly-half-of-ai-generated-answers-contain-an-error-ebu-bbc-report/)

Beide Quellen wurden für die Seminarfolien am 31.10.2026 geöffnet und hier übernommen.

### Prüfliste für KI-Antworten

1. **Quelle geöffnet?** Steht die Aussage dort wirklich, und an der Stelle, auf die die Fußnote zeigt?
2. **Primärquelle** (Dokument, Beschluss, Studie) oder nur ein Bericht über einen Bericht?
3. **Zahl:** Welcher Zeitraum, welche Einheit, gegenüber was?
4. **Wer hat entschieden, wer hat es gesagt?** Stimmen Funktion und Name heute noch?
5. **Wie alt ist die Quelle?** Gibt es eine neuere?
6. **Toter oder erfundener Link:** gilt als nicht verifiziert.
7. **Was fehlt?** Gegenfrage stellen: „Was spricht dagegen?“
8. **Zwei Tools, zwei Antworten?** Dann zählt nur die Quelle.

### Strichliste für einen KI-Bericht

So lief Übung 2 im Seminar: Öffnet drei der genannten Quellen und macht für jede Aussage einen Strich.

| belegt | falsch zugeordnet | Link tot oder Bezahlschranke |
|---|---|---|
| Die Quelle sagt genau das. | Die Quelle gibt es, aber sie sagt etwas anderes, oder es steht in einer anderen Quelle. | Ihr kommt nicht an den Text. Gilt als nicht verifiziert. |

### Wofür KI taugt und wofür nicht

| Taugt | Taugt nicht |
|---|---|
| lange Dokumente lesen und gliedern | Zahlen, Zitate und Angaben zu Personen ohne geöffnete Quelle |
| Suchstrings für Pressedatenbanken bauen | Aktuelles ohne Websuche |
| Interviews vorbereiten | |
| Gegenargumente sammeln | |

„Taugt nicht“ heißt nicht verboten, sondern: Diese Angaben nur übernehmen, wenn ihr die Quelle selbst geöffnet habt. Das gilt für alle Sprachmodelle.

### Nachfragen, die helfen

Im selben Chat, direkt nach der Antwort:

```
Welche der genannten Quellen hast du geöffnet, und welche kennst du nur als Suchtreffer?
```

```
Zeig mir für jede Zahl in deiner Antwort den wörtlichen Satz aus der Quelle und den Link.
```

```
Was spricht gegen deine Antwort? Such gezielt nach Quellen, die etwas anderes sagen.
```

```
Welche Aussagen in deiner Antwort stammen aus deinem Trainingswissen und nicht aus einer Quelle von heute?
```

Die Antworten darauf sind wieder KI-Antworten. Sie helfen euch, die Stellen zu finden, die ihr selbst prüfen müsst. Sie ersetzen das Öffnen der Quelle nicht.

Einen ganzen Text prüfen der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und der Assistent Moby (siehe Abschnitt „Moby zum Mitnehmen“), eine einzelne Zahl oder ein Zitat bis zum Ursprung der Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“).

---

<!-- Datei im Repo: ki-tools/tools.md -->

## KI-Tools für die Recherche: alle mit Link

Dieselben Tools wie auf dem Spickzettel (Datei Spickzettel.pdf) (Kapitel 4 und 6), hier als Linkliste. Stand der Angaben zu Zugang und Preisen: 01.11.2026, ohne Gewähr.

**Prüfstufe:** Zugang und Preise wurden für den Spickzettel am 31.10.2026 auf den Seiten der Anbieter oder in datierten Berichten geprüft. Die Adressen sind von dort übernommen. Was davon offen ist, steht als „zu prüfen“ dabei.

° Zugang ändert sich gerade, vor Ort ausprobieren.

### Spielregeln

1. Ein Konto ist freiwillig. Jede Übung geht auch ohne.
2. Keine Namen, Telefonnummern oder anderen persönlichen Daten in Prompts.
3. Nur Dokumente hochladen, die schon öffentlich zugänglich sind.
4. Wo es geht: Verlauf aus, Training abwählen.
5. Jeder Link wird geöffnet. Was nicht geöffnet wurde, gilt als nicht verifiziert.
6. KI-Text, den ihr übernehmt, kennzeichnet ihr.

### Welches Tool wofür

| Aufgabe | ohne Konto | mit Konto |
|---|---|---|
| schnell nachschlagen, mit Quellen | Perplexity, KI-Modus der Google-Suche°, Ask Brave | – |
| Überblick über ein Thema | – | Gemini Deep Research, Claude Research (Pro) |
| eigene Dokumente befragen | – | Gemini Notebook, Claude-Projekt |
| große Dokumentenstapel durchsuchen | öffentliche Pinpoint-Sammlungen° | Pinpoint |
| Interviews transkribieren | noScribe (läuft lokal), Whisper im Browser° | TurboScribe, Pinpoint |
| Studien finden | – | Scholar Labs, Consensus |
| fremdsprachige Quellen lesen | DeepL (mit Limit) | DeepL mit mehr Umfang |
| Gegenargumente, Interviewfragen | Duck.ai, Lumo | Claude, Le Chat, Euria |
| veröffentlichte Faktenchecks finden | Fact Check Explorer° | – |
| vertrauliches Material | noScribe, sonst nichts hochladen | – |

### Vier Fragen an jedes KI-Tool

Das Pult aus Kapitel 4: Mit diesen vier Fragen ordnet ihr jedes Tool ein, auch neue.

1. **Modell und Denkzeit:** Wie stark ist das Modell, wie lange denkt es nach?
2. **Zugriff:** Welche Quellen sind offen? Gedächtnis, offenes Web, eure Dateien, eure Dienste.
3. **Auftrag:** Wie strukturiert ist euer Input? Frage, Prompt oder Skill.
4. **Selbstständigkeit:** Wer bestimmt den nächsten Schritt, und verändert die KI etwas? Wenn sie handelt, nur mit eurer Freigabe.

### Alle Tools

#### Suchen mit KI-Antwort

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| KI-Modus (Google) | Antwort mit Fußnoten in der Google-Suche | ohne Konto°; ob ein Login nötig ist, zu prüfen | [google.com](https://www.google.com/), Reiter „KI-Modus“ |
| Perplexity | Suchmaschine, die mit nummerierten Quellen antwortet | Basissuche ohne Konto | [perplexity.ai](https://www.perplexity.ai/) |
| Ask Brave | KI-Antworten aus Braves eigenem Suchindex | kostenlos | [search.brave.com](https://search.brave.com/) |
| Ecosia | KI-Übersicht über den Treffern und KI-Chat | ohne Konto | [ecosia.org](https://www.ecosia.org/) |

#### Chat-Assistenten

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Duck.ai | mehrere Sprachmodelle im Vergleich, Verlauf nur im Browser | ohne Konto; ob mit Websuche, zu prüfen | [duck.ai](https://duck.ai/) |
| Lumo (Proton) | Chat mit Websuche, wirbt mit Datenschutz | ohne Konto | [lumo.proton.me](https://lumo.proton.me/) |
| Le Chat (Mistral) | französischer Anbieter, Daten in der EU, auch Deep Research | Konto für mehr Funktionen° | [chat.mistral.ai](https://chat.mistral.ai/) |
| Euria (Infomaniak) | Assistent aus der Schweiz, laut Anbieter kein Training mit euren Daten | kostenloses Konto | [infomaniak.com/de/euria](https://www.infomaniak.com/de/euria) |
| Claude | lange Dokumente, Projekte mit festen Regeln | Konto mit E-Mail; Pro 17–20 $ im Monat | [claude.ai](https://claude.ai/) |
| ChatGPT | Multitool mit Websuche | Konto; gratis mit Werbung | [chatgpt.com](https://chatgpt.com/) |
| Copilot | in Bing, Edge, Windows und Office eingebaut | nur mit Login | [copilot.microsoft.com](https://copilot.microsoft.com/) |

#### Recherche im Auftrag

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Gemini Deep Research | plant, sucht in Schleifen, schreibt einen Bericht mit Quellen | Google-Konto ab 18, mit Limit | [gemini.google.com](https://gemini.google.com/) |
| Claude Research | viele Suchen, ein Bericht mit Quellen | nur Pro | [claude.ai](https://claude.ai/), über „+“ |

#### Eigene Dokumente befragen

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Gemini Notebook (früher NotebookLM) | Gespräch mit wenigen Quellen, zeigt die Belegstelle | Google-Konto, 50 Quellen je Notebook | [notebooklm.google.com](https://notebooklm.google.com/) |
| Pinpoint | Archiv mit Suchmaschine für große Stapel, Index von Personen und Orten, transkribiert Audio | öffentliche Sammlungen ohne Konto°; eigene mit Google-Konto ab 18 | [journaliststudio.google.com/pinpoint](https://journaliststudio.google.com/pinpoint) |
| Claude-Projekt | Anweisungen und Dateien, die jeder Chat im Projekt kennt | Konto, 5 Projekte gratis | [claude.ai](https://claude.ai/) |

#### Transkription

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| noScribe | transkribiert auf dem eigenen Rechner, offline, Open Source | kostenlos, installieren | [github.com/kaixxx/noScribe](https://github.com/kaixxx/noScribe) |
| Whisper im Browser | transkribiert im Browser, Datei oder Mikrofon; eine Demo der webml-community auf Hugging Face. Ob lokal, ist ungeprüft: Vertrauliches nur mit noScribe | ohne Konto° | [huggingface.co/spaces/webml-community/whisper-large-v3-turbo-webgpu](https://huggingface.co/spaces/webml-community/whisper-large-v3-turbo-webgpu) |
| TurboScribe | Transkription im Browser, Freemium | Konto, kostenlos mit Limit | [turboscribe.ai](https://turboscribe.ai/) |

**Whisper im Browser:** Die Seite (geöffnet am 01.11.2026) sagt, die Spracherkennung laufe „directly in your browser“. Ob die Aufnahme dabei sicher auf eurem Rechner bleibt, steht dort nicht ausdrücklich: zu prüfen. Der Name verweist auf WebGPU, also braucht ihr vermutlich einen aktuellen Browser mit WebGPU-Unterstützung. Für vertrauliches Material bleibt noScribe die sichere Wahl.

**Achtung bei noScribe:** Die Seite noscribe.ai gehört nicht zum Projekt. Laut README des Projekts (geöffnet am 01.11.2026) ist die neue offizielle Website noscribe.de, die Downloads verlinkt die README. Ladet das Programm nur über diese Wege.

#### Studien und Übersetzen

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Scholar Labs | KI-Suche in Google Scholar, sagt, warum ein Aufsatz passt | Google-Konto, experimentell | [scholar.google.com](https://scholar.google.com/) |
| Consensus | fasst den Forschungsstand aus über 220 Mio. Fachartikeln zusammen | Konto, 10 Analysen im Monat | [consensus.app](https://consensus.app/) |
| DeepL | Übersetzer für fremdsprachige Quellen | ohne Konto mit Limit | [deepl.com](https://www.deepl.com/) |

#### Faktenchecks finden

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Fact Check Explorer (Google) | durchsucht veröffentlichte Faktenchecks vieler Redaktionen | Suche ohne Konto°, geöffnet am 01.11.2026 | [toolbox.google.com/factcheck/explorer](https://toolbox.google.com/factcheck/explorer) |

#### Vorsicht

| Tool | Was es kann | Zugang | Hinweis |
|---|---|---|---|
| DeepSeek | starke Modelle aus China; die Berliner Datenschutzbeauftragte hält die App für rechtswidrig | nur unkritische Fragen | chat.deepseek.com |
| KI-Browser (Comet, ChatGPT Atlas) | ein Agent klickt für euch; versteckte Anweisungen auf Webseiten können ihn fremdsteuern | nicht mit euren Konten | nur ansehen |

Auch eine Download-Adresse ist eine Quelle: Programme nur von der Seite des Projekts laden. Wie ihr neue Tools findet und prüft, steht in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

---

<!-- Datei im Repo: ki-tools/neue-tools-finden.md -->

## Neue KI-Tools finden und prüfen

Fast jede Woche kommt ein neues KI-Werkzeug dazu. Viele nützliche Recherche-Tools sind Open-Source-Projekte auf GitHub, etwa noScribe, OpenRefine oder Aleph, oder kleine Demos auf Hugging Face. Dort zu stöbern geht fast überall ohne Konto und ohne Programmieren. Ausprobieren oder installieren solltet ihr ein Tool aber erst nach der Prüfliste (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

Gehört zu Kapitel 6.2 des Seminars. Stand: 01.11.2026. Alle Links sind **geöffnet am 01.11.2026**, sofern nicht anders vermerkt. Zahlen wie Sterne und Repos sind Momentaufnahmen von diesem Tag.

### Wo neue KI-Tools auftauchen: fünf Wege

Vom einfachsten zum technischsten.

| Weg | Was ihr dort findet | Ohne Konto? | Einstieg |
|---|---|---|---|
| **1. Werkzeugkästen von Rechercheprofis** | Tools mit Einordnung: Kosten, Anforderungen, Grenzen, Ethik. Gepflegt von Menschen, die die Tools selbst nutzen | ja | [Bellingcat Online Investigations Toolkit](https://bellingcat.gitbook.io/toolkit): 12 Kategorien, jedes Tool als kostenlos, teilweise kostenlos oder bezahlt markiert. [awesome-osint](https://github.com/jivoi/awesome-osint) mit dem Abschnitt „Fact Checking“ |
| **2. GitHub stöbern** | **Trending:** was gerade Aufmerksamkeit bekommt, filterbar nach gesprochener Sprache, Programmiersprache und Zeitraum. **Topics:** Schlagwort-Seiten, sortierbar nach „Recently updated“ | ja | [Trending](https://github.com/trending); Topics [fact-checking](https://github.com/topics/fact-checking) (1.026 Repos), [journalism](https://github.com/topics/journalism) (968), [osint](https://github.com/topics/osint) |
| **3. awesome-Listen** | von Menschen gepflegte Linklisten zu einem Thema | ja | [sindresorhus/awesome](https://github.com/sindresorhus/awesome), die Liste aller Listen (rund 528.000 Sterne); durchsuchbar über [awesome.ecosyste.ms](https://awesome.ecosyste.ms/) |
| **4. Hugging Face Spaces** | KI-Demos direkt im Browser, nach Kategorien wie OCR, Document Analysis, Text Summarization, Speech Synthesis | ja, mit Limit: ohne Konto 2 Minuten Rechenzeit (GPU) am Tag, mit Gratis-Konto 5 Minuten | [Spaces](https://huggingface.co/spaces); [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space) mit einem AI Toolkit für Redaktionen |
| **5. Verzeichnisse für Skills und MCP-Server** (Ausblick) | Bausteine, die KI-Assistenten neue Fähigkeiten geben, etwa Zugriff auf Datenbanken | lesen ja, nutzen meist nur mit Entwickler-Werkzeugen | [skills.sh](https://skills.sh) (von Vercel); [offizielle MCP-Registry](https://registry.modelcontextprotocol.io) (seit 08.09.2025 in der Preview, ohne Vorabprüfung); [awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) (rund 97.000 Sterne) |

Dazu kommen Communitys, in denen Leute ihre Projekte selbst vorstellen, etwa [Show HN](https://news.ycombinator.com/show) auf Hacker News, ohne Konto lesbar.

**Merksatz: Trending heißt beliebt, nicht seriös.** Bei Hugging Face standen am 01.11.2026 unter den zehn meistbeachteten Spaces Bildgeneratoren mit dem Zusatz „uncensored“ und ein Face-Swap-Tool. Sucht lieber über Kategorien und Schlagworte.

**Was ohne Konto nicht geht:** die Code-Suche auf GitHub, etwa nach `path:SKILL.md faktencheck`. Dafür braucht ihr ein kostenloses GitHub-Konto ([GitHub Docs](https://docs.github.com/en/search-github/searching-on-github/searching-code)). Für den Anfang reichen Topics und Listen.

**Zu Weg 5:** Viele Skills, etwa die Sammlung [jamditis/claude-skills-journalism](https://github.com/jamditis/claude-skills-journalism) (MIT-Lizenz), sind für Entwickler-Umgebungen gebaut. In einem normalen Chat nutzt ihr davon nur den Text der Anweisungen: kopieren, Zeilen mit Skripten oder Befehlen streichen. So sind auch die Skills in diesem Repo (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“) gebaut.

### Bevor ihr etwas ausprobiert: die Prüfliste

Acht Fragen. Die ersten drei entscheiden.

1. **Wer steckt dahinter?** Eine Person oder Organisation mit Namen, ein echtes Profil, ein Impressum. Vorsicht bei Namen, die sich von einem bekannten Projekt nur in einem Zeichen unterscheiden.
2. **Läuft es im Browser, oder muss ich etwas installieren?** Was im Browser läuft, ist das kleinere Risiko. Ladet nie eine ZIP- oder EXE-Datei über einen „Download“-Knopf in einer README, sondern nur über die offizielle Releases-Seite oder Website des Projekts.
3. **Wohin gehen meine Daten?** Upload, Training, Serverstandort. Nur hochladen, was schon öffentlich ist (Spielregel 3).
4. **Konto, Kosten, Limits?** Mit Datum notieren. Freemium-Angebote ändern sich schnell.
5. **Lebt das Projekt?** Letztes Update, Releases, offene Issues mit Antworten.
6. **Gibt es eine offene Lizenz?** Bei Open Source steht sie im Repo.
7. **Sterne, Downloads, Trending:** nur schwache Signale. Sie lassen sich fälschen.
8. **Erst mit Bekanntem testen:** mit Material, dessen Ergebnis ihr kennt, zum Beispiel einer Übung aus dem Seminar. Erst dann mit eigenem Material.

#### Warum die Fragen 1, 2 und 7 zählen: der Fall FakeGit

- Die Kampagne „FakeGit“ hat laut [BleepingComputer vom 08.10.2026](https://bleepingcomputer.com/news/security/fakegit-malware-campaign-returns-with-17-610-malicious-github-repos) 17.610 gefälschte GitHub-Repos angelegt. Sie haben überzeugende READMEs mit einem Download-Knopf. Dahinter steckt eine ZIP-Datei mit Schadsoftware, die Zugangsdaten stiehlt.
- Schon im Juli hatte [Island (20.07.2026)](https://www.island.io/blog/agentbaiting-how-800-fake-ai-skills-and-mcp-servers-delivered-malware) rund 7.600 Repos derselben Kampagne gezählt. Über 800 davon gaben sich als KI-Skills oder MCP-Server aus und standen auch in öffentlichen Verzeichnissen, darunter eine nachgemachte awesome-Liste mit Claude-Skills. In Tests von Island haben KI-Assistenten diese Repos selbst gefunden und weiterempfohlen.

Daraus folgt: Ein Eintrag in einem Verzeichnis ist kein Gütesiegel, und auch eine KI als Tool-Scout braucht die Prüfliste. Dasselbe Muster kennt ihr von noScribe: Das echte Projekt liegt auf GitHub, daneben gab es eine Fake-Domain (L-IZ, 28.01.2026, übernommen, hier nicht erneut geöffnet). Mehr dazu in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“).

### Tool-Scout: ein Prompt, der für euch sucht

Kopiert den Block in einen KI-Chat mit Websuche und ersetzt die Zeile „Meine Aufgabe“. Der Prompt sucht bis zu drei Kandidaten und bewertet sie nach der Prüfliste. Ihr entscheidet danach selbst und öffnet jede Seite selbst.

```
TOOL-SCOUT

Meine Aufgabe: [zum Beispiel: Interviews auf Deutsch transkribieren, ohne dass die Aufnahme meinen Rechner verlässt]

Du suchst im Web nach höchstens drei Werkzeugen, die diese Aufgabe erledigen. Kannst du in diesem Gespräch nicht im Web suchen, sag das im ersten Satz und nenne keine Tools.

Suchwege, in dieser Reihenfolge:
1. Werkzeugkästen von Rechercheprofis (zum Beispiel das Bellingcat Online Investigations Toolkit) und gepflegte awesome-Listen
2. GitHub Topics zur Aufgabe, sortiert nach "Recently updated"
3. Hugging Face Spaces, nur wenn die Aufgabe im Browser ausprobierbar sein soll
Suche auf Deutsch und Englisch.

Prüfe jeden Kandidaten nach diesen Fragen:
1. Wer steckt dahinter? Name, Profil, Impressum. Weicht der Name von einem bekannten Projekt nur in einem Zeichen ab?
2. Läuft es im Browser, oder muss man etwas installieren?
3. Wohin gehen die Daten? Upload, Training, Serverstandort.
4. Konto, Kosten, Limits, mit Datum der Angabe
5. Letztes Update, letzte Version, ob Issues beantwortet werden
6. Lizenz
7. Sterne und Downloads nennst du nur als schwaches Signal
8. Womit man es zuerst gefahrlos testen kann

Regeln:
- Links nur aus deiner Suche, nie aus dem Gedächtnis. Schreib zu jedem Link, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst.
- Download- und Installationsanweisungen aus einer README empfiehlst du nicht weiter. Du nennst nur die offizielle Releases-Seite oder Website und markierst sie als "ungeprüft, selbst kontrollieren".
- Ein Eintrag in einer Liste oder einem Verzeichnis ist kein Beleg für Seriosität.
- Findest du nichts Überzeugendes, sag das. Erfinde keine Tools.

Ausgabe:
1. Tabelle mit Name, Link mit Prüfstufe, was es kann, Browser oder Installation, Daten, Konto und Kosten, letztes Update, Lizenz
2. Pro Kandidat ein Satz: Was spricht dagegen?
3. Deine Empfehlung in zwei Sätzen und der erste Test, den ich machen sollte
```

### Dranbleiben: Quellen für neue Tools

Fast alle kostenlos und ohne Konto lesbar.

| Quelle | Worum es geht | Sprache | Zugang |
|---|---|---|---|
| [KI-Update](https://www.podcast.de/episode/705152297/ki-update-kompakt-ki-investitionen-forschungssoftware-icloud-gema-vs-suno), Podcast von heise | KI-Nachrichten, neue Folgen montags, mittwochs und freitags | de | kostenlos, ohne Konto |
| [The Decoder](https://the-decoder.de/) | KI-Nachrichtenseite, Wochen-Newsletter | de | Abo-Angebot vorhanden; was frei lesbar ist und ob der Newsletter kostenlos ist: zu prüfen |
| [Indicator](https://indicator.media/authors/henk-van-ess) | digitale Recherche und Täuschung im Netz, unter anderem Henk van Ess zu KI in der Recherche | en | Newsletter kostenlos, Abo für mehr |
| [GIJN Resource Center](https://gijn.org/resource/gijns-reporting-guides-2/) | über 1.000 Tipsheets, Videos und Leitfäden, viele zu Recherche-Werkzeugen | en | kostenlos |
| [Bellingcat Toolkit](https://bellingcat.gitbook.io/toolkit) | Recherche-Tools mit Kosten, Anforderungen und Grenzen, von Freiwilligen gepflegt | en | kostenlos, ohne Konto |
| [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space) | Open-Source-KI für Redaktionen, mit AI Toolkit | en | lesen ohne Konto, Community mit Konto |
| [Simon Willison’s Weblog](https://simonwillison.net/about) | baut Datasette für Datenjournalismus und schreibt fast täglich über neue KI-Werkzeuge | en | kostenlos, Newsletter etwa wöchentlich, [Feed](https://simonwillison.net/atom/everything/) ohne Konto |
| [GitHub Topics](https://github.com/topics/journalism) und [Show HN](https://news.ycombinator.com/show) | neue Projekte, nach „Recently updated“ sortiert | en | ohne Konto |

**Tipp:** einmal im Monat 20 Minuten. Eine Topic-Seite durchklicken, das Bellingcat Toolkit ansehen, einen Newsletter lesen. Feeds wie der von Simon Willison lassen sich ohne Konto in einem Feed-Reader abonnieren.

### Quellen

Geöffnet am 01.11.2026, sofern nicht anders vermerkt.

- [GitHub Trending](https://github.com/trending): ohne Konto lesbar, Filter Spoken Language, Language, Date range
- [GitHub Topic fact-checking](https://github.com/topics/fact-checking): 1.026 Repos; [Topic journalism](https://github.com/topics/journalism): 968 Repos
- [GitHub Docs, Searching code](https://docs.github.com/en/search-github/searching-on-github/searching-code): Code-Suche nur angemeldet
- [sindresorhus/awesome](https://github.com/sindresorhus/awesome): rund 528.000 Sterne; [awesome.ecosyste.ms](https://awesome.ecosyste.ms/)
- [jivoi/awesome-osint](https://github.com/jivoi/awesome-osint): Abschnitt „Fact Checking“, rund 29.000 Sterne
- [Bellingcat Online Investigations Toolkit](https://bellingcat.gitbook.io/toolkit) und [Vorstellung bei Bellingcat, 24.09.2024](https://bellingcat.com/resources/2024/09/24/bellingcat-online-investigations-toolkit)
- [Hugging Face Spaces](https://huggingface.co/spaces) und [Hugging Face Docs, ZeroGPU](https://huggingface.co/docs/hub/spaces-zerogpu): Tageskontingent ohne Konto 2 Minuten, Gratis-Konto 5 Minuten
- [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space)
- [skills.sh](https://skills.sh): Verzeichnis von Vercel
- [MCP-Blog, 08.09.2025](https://blog.modelcontextprotocol.io/posts/2025-09-08-mcp-registry-preview/): offizielle Registry in der Preview, keine Vorabprüfung, Meldungen durch die Community
- [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers): rund 97.000 Sterne
- [jamditis/claude-skills-journalism](https://github.com/jamditis/claude-skills-journalism): MIT-Lizenz, Einrichtung vor allem über Entwickler-Werkzeuge
- [Show HN](https://news.ycombinator.com/show): ohne Konto lesbar
- [BleepingComputer, 08.10.2026](https://bleepingcomputer.com/news/security/fakegit-malware-campaign-returns-with-17-610-malicious-github-repos): FakeGit mit 17.610 Repos, Download-Knopf führt zu einer ZIP-Datei mit Schadsoftware
- [Island, 20.07.2026](https://www.island.io/blog/agentbaiting-how-800-fake-ai-skills-and-mcp-servers-delivered-malware): rund 7.600 Repos der Kampagne, über 800 als Skills oder MCP-Server getarnt, KI-Assistenten empfehlen sie in Tests
- [KI-Update bei podcast.de](https://www.podcast.de/episode/705152297/ki-update-kompakt-ki-investitionen-forschungssoftware-icloud-gema-vs-suno): Folge vom 03.08.2026, Erscheinungstage Mo, Mi, Fr
- [The Decoder](https://the-decoder.de/): Startseite, Meldungen vom 31.10.2026
- [Indicator, Autorenseite Henk van Ess](https://indicator.media/authors/henk-van-ess): Artikel vom 14.09.2026
- [GIJN Reporting Guides](https://gijn.org/resource/gijns-reporting-guides-2/)
- [Simon Willison, About](https://simonwillison.net/about) und [Atom-Feed](https://simonwillison.net/atom/everything/)
- noScribe und die Fake-Domain: L-IZ, 28.01.2026, übernommen, hier nicht erneut geöffnet; README des Projekts auf [GitHub](https://github.com/kaixxx/noScribe), geöffnet am 01.11.2026

---

<!-- Datei im Repo: suche/google-operatoren.md -->

## Suchen mit Google: Operatoren, erweiterte Suche, Web-Archiv

Aus Kapitel 2 der Seminarfolien, ergänzt um den Stand, welche Operatoren heute noch wirken. Stand: 01.11.2026.

Links aus den Folien haben die Prüfstufe **übernommen** (für dieses Repo nicht erneut geöffnet). Die beiden Quellen zum Operator-Stand sind **geöffnet am 01.11.2026**.

### Die Standardsuche

- Google ist nicht für objektive Recherche gebaut. Es rät, was für euch relevant sein könnte, und nutzt dafür auch Daten, die nicht in eurer Anfrage stehen, etwa Standort und frühere Suchen.
- Über der Trefferliste versucht Google, die Frage selbst zu beantworten, mit Inhalten aus Wikipedia und anderen Seiten. Wollt ihr nur die Trefferliste, klickt auf **Mehr**, dann **Web**.
- Gebt Schlüsselbegriffe ein statt ganzer Fragen: `Bergson Eröffnung` statt „Wann wurde das Bergson eröffnet?“
- Google sucht automatisch nach Wortstämmen und toleriert Tippfehler. Wollt ihr das nicht: **Suchfilter**, **Alle Ergebnisse**, **Wortwörtlich**.
- In den Suchfiltern legt ihr auch den Zeitraum fest (Format MM/DD/YYYY).
- Für Presse und Rundfunk: Reiter **News**, dann in den Suchfiltern Zeitraum wählen und von „Nach Relevanz sortiert“ auf „Nach Datum sortiert“ umstellen.

### Die erweiterte Suche

Direkt aufrufen: [google.com/advanced_search](https://www.google.com/advanced_search), oder auf der Startseite **Einstellungen**, dann **Erweiterte Suche**.

| Feld | Was es tut | Beispiel aus den Folien |
|---|---|---|
| genau dieses Wort oder diese Wortgruppe | genau diese Wörter in dieser Reihenfolge | „Wer reitet so spät durch Nacht und Wind“ |
| keines der folgenden Wörter | diese Wörter dürfen nicht vorkommen | „Oktoberfest“, aber ohne „München“ |
| Webseite oder Domain | nur Treffer auf dieser Website | „Frank Sinatra“ nur auf zeit.de |
| Dateityp | nur Dateien in diesem Format, keine Webseiten | nur PDF |

### Operatoren: was heute noch wirkt

Google dokumentiert offiziell nur sechs Operatoren. Andere wirken trotzdem, manche gar nicht mehr. Die Spalte „Stand“ folgt einem Test von SEOmator vom 13.07.2026 (Google USA, Englisch, Desktop). Ergebnisse können je nach Land, Sprache und Zeitpunkt abweichen.

| Operator | Was er tut | Beispiel | Stand |
|---|---|---|---|
| `"…"` | genau diese Wortfolge | `"Wer reitet so spät durch Nacht und Wind"` | offiziell |
| `-wort` | Wort darf nicht vorkommen, ohne Leerzeichen | `Bach -Vivaldi` | offiziell |
| `site:` | nur diese Website | `site:zeit.de "Rolling Stones"` | offiziell |
| `filetype:` | nur dieser Dateityp | `filetype:pdf Spielzeit Programmheft` | offiziell |
| `after:` / `before:` | zuletzt aktualisiert nach oder vor einem Datum | `Documenta after:2022-06-01 before:2022-09-30` | offiziell, siehe Hinweis |
| `intitle:` / `allintitle:` | Wort oder alle Wörter im Titel der Seite | `intitle:Uraufführung Oper` | wirkt, nicht offiziell |
| `intext:` / `allintext:` | Wort oder alle Wörter im Seitentext | `intext:Intendanz Theater` | wirkt, nicht offiziell |
| `AROUND(N)` | Begriffe höchstens N Wörter voneinander entfernt | `Brecht AROUND(5) Weill` | wirkt, nicht offiziell |
| `OR` | einer der Begriffe genügt, großschreiben | `Bach OR Vivaldi` | unklar |
| `*` | Platzhalter für ein beliebiges Wort | `"Wer * so * durch * und *"` | unklar |
| `inurl:` / `allinurl:` | Wort in der Internetadresse | `inurl:pressemitteilung` | gelockert, filtert nicht mehr streng |
| `cache:`, `related:`, `info:`, `link:`, `+`, `~` | | | wirken nicht mehr |

**Hinweis zu `after:` und `before:`:** Sie filtern nach dem Datum der letzten Aktualisierung, nicht nach dem Erscheinungsdatum. Ein alter Text, der gestern geändert wurde, taucht also auch bei `after:gestern` auf. Prüft das Datum immer auf der Seite selbst.

**Hinweis zu `*`:** Bei Google ist das Sternchen ein Platzhalter für ein ganzes Wort. Wortteile abschneiden („trunkieren“, etwa `Erlk*`) geht bei Google nicht, wohl aber in den Pressedatenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

**Kein Leerzeichen** zwischen Operator und Suchbegriff: `site:zeit.de`, nicht `site: zeit.de`.

#### Kombinieren

Operatoren lassen sich verbinden. Ein paar Muster zum Abwandeln (Beispiele, nicht für jedes Thema getestet):

| Ziel | Suchstring |
|---|---|
| Interviews einer Person auf einer Sender-Website | `site:br.de intitle:Interview "Anne-Sophie Mutter"` |
| Dokumente einer Stadt zu einem Thema | `site:berlin.de filetype:pdf Atelierförderung` |
| Berichte ohne Wikipedia und Online-Lexika | `"Gärtnerplatztheater" Sanierung -site:wikipedia.org` |
| eine Person, aber nicht eine gleichnamige | `"Thomas Mann" -Heinrich` |
| Pressemitteilungen eines Hauses | `site:pinakothek.de intitle:Pressemitteilung` |

Mehr Operatoren mit Beispielen: [ahrefs, Google Advanced Search Operators](https://ahrefs.com/blog/google-advanced-search-operators/) und [eine Sammlung als Google-Dokument](https://docs.google.com/document/d/1ydVaJJeL1EYbWtlfj9TPfBTE5IBADkQfZrQaBZxqXGs) (beide übernommen aus den Folien). Ob ein Operator noch wirkt, prüft ihr am besten selbst mit einer Suche, deren Ergebnis ihr kennt.

### Suche im Web-Archiv

Was tun, wenn eine Seite verschwunden ist oder sich verändert hat?

- Das [Internet Archive (Wayback Machine)](https://web.archive.org/) speichert Webseiten in Kopien mit Datum, sofern die Betreiber das nicht verhindern oder eine Löschung beantragen.
- Den Cache von Google gibt es nicht mehr. Andere Archive gibt es, zum Beispiel bei Bing.
- Archiv-Metasuche über mehrere Archive: [echo.archivarix.net](https://echo.archivarix.net/)
- Browser-Erweiterung für den direkten Zugriff auf viele Archive: [Web Archives](https://github.com/dessant/web-archives)
- Die Deutsche Nationalbibliothek archiviert das deutschsprachige Web: [Sammlung Websites der DNB](https://www.dnb.de/DE/Professionell/Sammeln/Sammlung_Websites/sammlung_websites_node.html)

Eine archivierte Seite belegt, was zu diesem Zeitpunkt dort stand. Gebt in eurem Text das Datum der Archivkopie an.

### Wikipedia

Wikipedia hat rund drei Millionen Artikel auf Deutsch, geschrieben von Freiwilligen. Sie gilt nicht als zitierfähige Quelle, weil die Autor:innen meist anonym sind und ihre Sachkenntnis nicht belegt ist. Nutzt sie als Sprungbrett: Die Einzelnachweise unten im Artikel führen zu Originalquellen, die ihr selbst öffnet und zitiert.

### Quellen

- Folien „Recherche im Web“, Seminar Recherche und Faktencheck, Stand 31.10.2026
- [Google-Suchhilfe, Refine Google searches](https://support.google.com/websearch/answer/2466433?hl=en): dokumentiert `"…"`, `site:`, `-`, `before:`, `after:`, `filetype:`; geöffnet am 01.11.2026
- [SEOmator, Google Search Operators Cheat Sheet](https://seomator.com/de/blog/google-search-operators-cheat-sheet-tabelle): Test aller Operatoren am 13.07.2026, aktualisiert 21.07.2026; geöffnet am 01.11.2026

---

<!-- Datei im Repo: suche/datenbanken.md -->

## Datenbanken: Zugänge und Suchsyntax

Aus Kapitel 3 der Seminarfolien. Stand: 01.11.2026.

**Prüfstufe aller Links: übernommen.** Sie stehen genau so auf Florians Folien und wurden für dieses Repo nicht erneut geöffnet. Zugänge über Bibliotheken ändern sich gelegentlich. Funktioniert ein Link nicht, findet ihr die Datenbank über DBIS (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

### Warum Datenbanken, wenn es Google gibt?

Datenbanken sind meist auf ein Thema spezialisiert. Ihre Inhalte sind ausgewählt und erschlossen, die Quellen durchlaufen zumindest eine gewisse Qualitätssicherung, und vieles davon findet keine Suchmaschine.

Manche Datenbanken sind kostenlos, manche Freemium, manche nur mit bezahltem Konto nutzbar. **Mit eurem Ausweis der Bayerischen Staatsbibliothek (Stabi) und der Münchner Stadtbibliothek kommt ihr kostenlos an viele Datenbanken, die sonst Geld kosten.** Die Links über `emedia1.bsb-muenchen.de/han/…` fragen nach dem Stabi-Login.

### Datenbanken finden: DBIS

[DBIS](https://dbis.ur.de/BSB/browse/subjects/), das Datenbank-Infosystem, ist ein Katalog von Datenbanken aus allen Fachgebieten, keineswegs nur wissenschaftlichen. Der Link führt zum Einstieg über die Stabi.

Ein Ampelsymbol zeigt den Zugang:

| Ampel | Zugang |
|---|---|
| grün | frei zugänglich |
| gelb | über den Stabi-Account |
| rot | nur kostenpflichtig oder mit besonderer Berechtigung |

### Pressedatenbanken

Die meisten Pressedatenbanken laufen intern in Verlagen und Sendern. F.A.Z. und SZ bieten auch externe Zugänge an, ebenso Genios, Munzinger, LexisNexis und Dow Jones Factiva. Über Stabi und Stadtbibliothek kommt ihr kostenlos an F.A.Z., SZ, Genios, Munzinger und LexisNexis.

#### Überblick: Zugang und Syntax

| Datenbank | Zugang | Nähe | Mindestens N-mal | Besonderheit |
|---|---|---|---|---|
| SZ | [Stabi](http://emedia1.bsb-muenchen.de/han/sz) | `NEAR.N(a,b)` · in Reihenfolge `ONEAR.N(a,b)` | `ATLEAST.N(begriff)` | Linkstrunkierung `*philharmonie`, Artikeltypen und Dossiers |
| F.A.Z. | [Stabi](http://emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/) | `"a b"~N` | `begriff#N` | bildet Wortstämme automatisch |
| Genios / WISO | [Stadtbibliothek](http://bib-muenchen.genios.de/), [Stabi](http://emedia1.bsb-muenchen.de/han/wiso/) | `"a b"~N` | `begriff#N` | Suche auf [genios.de](http://www.genios.de/) ohne Konto |
| LexisNexis (Nexis Uni) | [Stabi](http://emedia1.bsb-muenchen.de/han/nexisuni1) | `a near/N b` | `atleastN(begriff)` | internationale Presse; NOT heißt hier `AND NOT` |

In allen vier gehen `AND`, `OR`, `NOT`, `*` zum Trunkieren, `"Phrasensuche"` und `(Klammern)` zum Gruppieren.

Den Suchstring für SZ, F.A.Z. und WISO baut euch auf Wunsch der PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“).

#### Süddeutsche Zeitung

- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/sz](http://emedia1.bsb-muenchen.de/han/sz)
- Weitgehend alle SZ-Ausgaben und die Inhalte von sz.de.
- Großes Plus: Ihr könnt die Erschließung der SZ-Dokumentation nutzen, also die Zuordnung von Artikeln zu Dossiers, und nach Artikeltypen filtern.
- Unter „Ganzseiten“ blättert ihr durch die Ausgaben wie im E-Paper.
- Zeitraum, Ressort, Artikeltyp und mehr könnt ihr vor der Suche einschränken oder danach filtern.

Operatoren und Syntax (unter anderem):

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `NOT` | beide, einer davon, nicht |
| `Philharmonie*` | Trunkierung rechts |
| `*philharmonie` | Trunkierung links, findet auch Isarphilharmonie |
| `"Phrasensuche"` | genau diese Wortfolge |
| `( … )` | Gruppieren |
| `NEAR.N(begriff1,begriff2,…)` | Begriffe höchstens N Wörter voneinander entfernt |
| `ONEAR.N(begriff1,begriff2,…)` | wie NEAR, aber in dieser Reihenfolge |
| `ATLEAST.N(begriff)` | Begriff kommt mindestens N-mal im Text vor |

#### Frankfurter Allgemeine Zeitung

- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/](http://emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/)
- Die Suche bildet aus eurer Eingabe automatisch Wortstämme und Beugungsformen. Manchmal schießt sie dabei übers Ziel hinaus.

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `NOT`, `*`, `"Phrase"`, `( … )` | wie oben |
| `"suchbegriff1 suchbegriff2"~N` | Begriffe höchstens N Wörter voneinander entfernt |
| `suchbegriff#N` | Begriff kommt mindestens N-mal im Text vor |

#### Genios und WISO

Genios vermarktet dieselbe Datenbank unter zwei Namen. Sie enthält Zeitungen und Zeitschriften vieler Verlage.

- Genios über die Stadtbibliothek: [bib-muenchen.genios.de](http://bib-muenchen.genios.de/)
- WISO über die Stabi: [emedia1.bsb-muenchen.de/han/wiso](http://emedia1.bsb-muenchen.de/han/wiso/)
- Auf [genios.de](http://www.genios.de/) könnt ihr ohne Konto und kostenlos suchen. Erst das Abrufen von Artikeln kostet.
- Syntax wie bei der F.A.Z.: `"a b"~N` für Nähe, `begriff#N` für mindestens N-mal.

#### LexisNexis

- Sehr viele internationale Publikationen, unter anderem Guardian, New York Times, Le Figaro, El País.
- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/nexisuni1](http://emedia1.bsb-muenchen.de/han/nexisuni1)

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `AND NOT`, `*`, `"Phrase"`, `( … )` | wie oben, NOT heißt hier `AND NOT` |
| `begriff1 near/N begriff2` | Begriffe höchstens N Wörter voneinander entfernt |
| `atleastN(begriff)` | Begriff kommt mindestens N-mal im Text vor |

#### Artikel hinter der Bezahlschranke lesen

- Viele „Plus“-Artikel stehen auch in Genios oder WISO. Gebt den Titel oder einen Halbsatz aus dem sichtbaren Teil in das Suchfeld ein. Ist der Artikel in der Datenbank, könnt ihr ihn lesen.
- Bei manchen Quellen dauert es ein paar Tage, bis Artikel in der Datenbank stehen. Manche bleiben dauerhaft exklusiv.
- Tipp: Das Browser-Plugin [BibBot](https://stefanw.github.io/bibbot/) sucht beim Aufruf eines Paywall-Artikels im Hintergrund in Genios oder WISO und blendet den Text ein, wenn es ihn findet. Dafür hinterlegt ihr eure Zugangsdaten von Stabi oder Stadtbibliothek; mit der Stadtbibliothek gibt es mehr Quellen. Nur für Text, nicht für Bilder oder Grafiken.

#### Zeitschriften und E-Paper

| Angebot | Was | Zugang |
|---|---|---|
| [PressReader](https://online.munzinger.de/publikation/pressreader) | E-Paper von Zeitschriften und einzelnen Zeitungen | Stadtbibliothek, über Munzinger |
| [Onleihe München](https://www.onleihe.de/muenchen/frontend/welcome,51-0-0-100-0-0-1-0-0-0-0.html) | E-Paper von Zeitschriften suchen und digital ausleihen | Stadtbibliothek |
| [Elektronische Zeitschriftenbibliothek (EZB)](https://ezb.ur.de/searchres.phtml?bibid=BSB) | vor allem wissenschaftliche Zeitschriften, Ampel wie in DBIS | Stabi |

### Thematische Datenbanken

#### Munzinger

Munzinger vereint unter anderem Biografien, Pop-Lexikon, Sport-Lexikon, Gedenktage und Chronik, Filmdienst-Kritiken, die Kritischen Lexika zur deutsch- und fremdsprachigen Gegenwartsliteratur und Duden Sprachwissen.

- über die Stabi: [Munzinger via DBIS](https://dbis.ur.de/warpto?ubr_id=BSB&resource_id=2109&license_type=2&license_form=22&access_type=1&access_form=15&access_id=61265)
- über die Stadtbibliothek: [online.munzinger.de](https://online.munzinger.de/)
- Die enthaltenen Module unterscheiden sich je nach Zugang etwas.

#### Feltas

[Feltas](http://www.feltas.de/) ist eine Ereignis-Datenbank: Geburts- und Todestage bekannter Persönlichkeiten, Chronik politischer, kultureller und anderer Ereignisse. Eingeschränkt auch ohne Anmeldung nutzbar. Gut für Jahrestage als Anlass.

#### MediathekViewWeb

[MediathekViewWeb](https://mediathekviewweb.de/) durchsucht an einer Stelle die Mediatheken der öffentlich-rechtlichen Sender aus Deutschland sowie ORF und SRF. Die Beiträge laufen direkt im Browser. Bei ORF und SRF nicht mehr direkt: Dort öffnet ihr die URL des M3U8-Streams im VLC-Player.

| Syntax | sucht in |
|---|---|
| `!sendername` | Sender |
| `#thema` | Thema, meist der Name der Sendung |
| `+titel` | Titel des Beitrags |
| `*begriff` | überall |

---

<!-- Datei im Repo: links/kultur.md -->

## Recherche-Links zu Kulturthemen

Aus dem Anhang der Seminarfolien. Stand: 01.11.2026.

**Prüfstufe aller Links: übernommen.** Sie stehen genau so auf Florians Folien und wurden für dieses Repo nicht erneut geöffnet. Funktioniert ein Link nicht mehr, sucht die Seite über ihren Namen oder im [Internet Archive](https://web.archive.org/).

„via Munzinger“ heißt: Zugang über die Munzinger-Datenbank mit eurem Ausweis der Stadtbibliothek oder der Stabi, siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“). Die Module unterscheiden sich je nach Zugang etwas.

### Literatur und Text

#### Literatur-Klassiker

| Angebot | Was ihr dort findet |
|---|---|
| [Projekt Gutenberg-DE](http://www.projekt-gutenberg.org/) | deutschsprachige gemeinfreie Literatur |
| [Project Gutenberg](http://www.gutenberg.org/) | internationale gemeinfreie Literatur |
| [Deutsches Textarchiv](http://www.deutschestextarchiv.de/) | Texte vom 17. bis 20. Jahrhundert |
| [TextGrid Digitale Bibliothek](https://textgrid.de/digitale-bibliothek) | deutschsprachige Belletristik |

#### Germanistik

| Angebot | Was ihr dort findet |
|---|---|
| [Grimm'sches Wörterbuch](https://dwb.uni-trier.de/) | Deutsches Wörterbuch von Jacob und Wilhelm Grimm |
| [BDSL](http://www.bdsl-online.de/) | Bibliographie der deutschen Sprach- und Literaturwissenschaft |
| [DWDS](http://www.dwds.de/) | der deutsche Wortschatz von 1600 bis heute |
| [Voyant Tools](https://voyant-tools.org/) | Lese- und Analysewerkzeuge für Texte |
| [Duden Sprachwissen](https://online.munzinger.de/publikation/duden_sprachwissen) | via Munzinger |

#### Aktuelle Literatur

| Angebot | Was ihr dort findet |
|---|---|
| [Perlentaucher](http://www.perlentaucher.de/) | Kultur- und Literaturmagazin, mit Presseschau zu Rezensionen |
| [Arts & Letters Daily](http://www.aldaily.com/) | Auswahl von Essays und Rezensionen, englisch |
| [Kritisches Lexikon zur deutschsprachigen Gegenwartsliteratur](https://online.munzinger.de/publikation/klg) | via Munzinger |
| [Kritisches Lexikon zur fremdsprachigen Gegenwartsliteratur](https://online.munzinger.de/publikation/klfg) | via Munzinger |
| [Kindlers Literatur Lexikon](https://online.munzinger.de/publikation/kll) | via Munzinger |

#### Aphorismen, Sprichwörter und Zitate

| Angebot | Was ihr dort findet |
|---|---|
| [aphorismen.de](http://www.aphorismen.de/) | Aphorismen und Sprichwörter |
| [zitate.eu](http://www.zitate.eu/) | sehr umfangreiche Zitatesammlung |

Zitatsammlungen sind Findehilfen, keine Belege. Ein Zitat prüft ihr bis zur Originalstelle, zum Beispiel mit dem Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“).

#### Medien: Presse, Rundfunk, Online, PR

| Angebot | Was ihr dort findet |
|---|---|
| [turi2](http://www.turi2.de/) | Branchendienst Medien und Kommunikation |
| [Meedia](http://www.meedia.de/) | Branchendienst Medien |
| [CLAP](https://clap-club.de/) | Branchenmagazin Kommunikation und PR |

### Theater, Oper und Kino

| Angebot | Was ihr dort findet |
|---|---|
| [nachtkritik.de](https://nachtkritik.de/) | Besprechungen von Theaterproduktionen |
| [theapolis](https://www.theapolis.de/de/productions/list?page=1) | Verzeichnis von Theaterproduktionen |
| [Deutscher Bühnenverein](http://www.buehnenverein.de/) | Theaterverzeichnis |
| [Der Theaterverlag](http://www.der-theaterverlag.de/) | Magazine zu Theater und Oper, viele Artikel frei lesbar |
| [operone](https://operone.de/opern/) | Opernverzeichnis |
| [Opera Guide](https://opera-guide.ch/operas/) | Opernverzeichnis |
| [Musicallexikon](http://www.musicallexikon.eu/) | Musical-Verzeichnis |
| [IMDb](http://www.imdb.com/) | Filme, Serien, Besetzung und Team |
| [epd Film](http://www.epd-film.de/) | Filmbesprechungen des Evangelischen Pressedienstes |
| [artechock](http://www.artechock.de/) | Filmbesprechungen |
| [Filmdienst](https://online.munzinger.de/publikation/film) | Filmkritiken, via Munzinger |

### Kunst, Architektur, Design und Museen

| Angebot | Was ihr dort findet |
|---|---|
| [art – Das Kunstmagazin](http://www.art-magazin.de/) | Artikel lest ihr über WISO oder Genios, siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“) |
| [Art History Resources](http://arthistoryresources.net/) | Linksammlung Kunstgeschichte |
| [Getty Research Portal](https://portal.getty.edu/) | digitalisierte kunsthistorische Literatur |
| [archINFORM](https://deu.archinform.net/) | internationale Architektur-Datenbank |
| [Designlexikon](http://www.designlexikon.net/) | internationales Design-Lexikon |
| [museen.de](https://museen.de/) | Museumsverzeichnis Deutschland |
| [Museums of the World](https://museu.ms/) | weltweites Museumsverzeichnis |

### Musik, Audio, Video

| Angebot | Was ihr dort findet |
|---|---|
| [AllMusic](http://www.allmusic.com/) | Musikdatenbank, englisch |
| [klassik.com Lexikon](https://magazin.klassik.com/lexikon/list.cfm?letter=A) | Lexikon zur klassischen Musik |
| [IMSLP](https://imslp.org/) | Noten-Archiv |
| [Volkslieder-Verzeichnis](https://ingeb.org/Volksong.html) | Volkslieder mit Texten |
| [Munzinger Pop](https://online.munzinger.de/publikation/pop) | via Munzinger |
| [Komponisten der Gegenwart](https://online.munzinger.de/publikation/kdg) | via Munzinger, nur im Stabi-Zugang |
| [fyyd](https://fyyd.de/) | Datenbank überwiegend deutschsprachiger Podcasts |
| [Podsearch](https://podsearch.com/) | Datenbank englischsprachiger Podcasts |
| [ARD Audiothek](http://www.ardaudiothek.de/) | Mediathek der öffentlich-rechtlichen Radiosender |
| [MediathekViewWeb](https://mediathekviewweb.de/) | durchsucht die öffentlich-rechtlichen TV-Mediatheken aus Deutschland, Österreich und der Schweiz, Syntax siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“) |
