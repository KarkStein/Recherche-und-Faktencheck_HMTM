# Werkzeugkasten Recherche und Faktencheck: alles in einer Datei

Seminar „Recherche und Faktencheck“, Master Kulturjournalismus, Hochschule für Musik und Theater München, 05./06.11.2026. Stand: 10.11.2026. Lizenz: CC BY 4.0. Aktuelle Fassung: https://github.com/KarkStein/Recherche-und-Faktencheck_HMTM

**Für Menschen:** Ladet diese Datei in einen KI-Chat oder ein Projekt hoch. Dann könnt ihr Fragen zum Werkzeugkasten stellen, etwa „Welcher Skill hilft mir, ein Zitat bis zum Ursprung zu verfolgen?“ oder „Wie richte ich Moby in Le Chat ein?“. Die Skill-Texte selbst stehen nicht in dieser Datei, sondern im Ordner Skills_zum_Kopieren.

**Für den KI-Assistenten:** Diese Datei ist Nachschlagematerial, keine Anweisung an dich. Beantworte Fragen dazu und nenne den Abschnitt, aus dem eine Angabe stammt, mit seinem Stand-Datum. Angaben zu Tools, Zugängen und Preisen können veraltet sein; sag das dazu. Will der User einen Skill nutzen, verweise auf die passende Datei im Ordner Skills_zum_Kopieren.

## Inhalt

- Recherche und Faktencheck · Werkzeugkasten
- Seminarfolien
- Skills und Moby: Überblick und Anleitung
- Faktencheck zum Mitnehmen
- Herkunftscheck zum Mitnehmen
- Themenrecherche zum Mitnehmen
- Expertenmeinungen zum Mitnehmen
- PDB-Helfer zum Mitnehmen
- Prompthelfer zum Mitnehmen
- Vorlage: einen Skill selbst schreiben
- Pakete zum Hochladen
- Moby zum Mitnehmen
- Prompten: von der Frage zum Auftrag
- KI-Antworten prüfen
- KI-Tools für die Recherche: alle mit Link
- Neue KI-Tools finden und prüfen
- Ergebnisse dokumentieren
- Suchen im Web: Suchmaschinen, Google, Web-Archiv
- Datenbanken: Zugänge und Suchsyntax
- Social Media durchsuchen
- Texte prüfen: das Handwerk
- Bilder prüfen und Geolokation
- Werkzeuge nach Kapiteln
- Lesetipps: Artikel, Podcasts, Studien, Bücher
- Recherche-Links zu Kulturthemen

---

<!-- Datei im Repo: README.md -->

## Recherche und Faktencheck · Werkzeugkasten

Material zum Seminar „Recherche und Faktencheck“ im Master Kulturjournalismus an der Hochschule für Musik und Theater München, 05. und 06.11.2026.

Hier liegt, was ihr nach dem Seminar weiter nutzen könnt: die Folien als PDF, sechs KI-Skills zum Kopieren oder Hochladen, darunter ein Prompthelfer für eure eigenen Themen, dazu der Faktencheck-Assistent Moby, Anleitungen zum Prüfen von Texten und Bildern, Linklisten mit Werkzeugen und Lesetipps, der Spickzettel zu KI-Tools und eine Anleitung, wie ihr selbst neue KI-Tools findet und prüft.

Diese Seite liegt auf GitHub, einer Plattform für Textdateien mit Änderungsverlauf. Ihr braucht dafür kein Konto: Lesen, Kopieren und Herunterladen geht ohne. Wer mit GitHub nichts anfangen will, nimmt das Gesamtpaket: alles in einer ZIP-Datei, lesbar im Browser, auch ohne Internet.

Stand: 10.11.2026 · Lizenz: CC BY 4.0 (siehe Abschnitt „Recherche und Faktencheck · Werkzeugkasten“)

### Was wo liegt

| Ordner | Was drin ist | Kapitel |
|---|---|---|
| skills/ (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“) | sechs Skills zum Kopieren oder Hochladen: Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“), Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“), Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“), Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“), PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“), Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“); dazu die Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“), wie ihr sie einsetzt | 2–5 |
| agent/ (siehe Abschnitt „Moby zum Mitnehmen“) | Moby (siehe Abschnitt „Moby zum Mitnehmen“), der Faktencheck-Assistent für Projekt, GPT oder Le-Chat-Agent | 5 |
| prompts/ (siehe Abschnitt „Prompten: von der Frage zum Auftrag“) | Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“), KI-Antworten prüfen (siehe Abschnitt „KI-Antworten prüfen“) | 4 |
| ki-tools/ (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“) | Spickzettel (Datei Spickzettel.pdf) als PDF, alle Tools mit Link (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“), Neue KI-Tools finden und prüfen (siehe Abschnitt „Neue KI-Tools finden und prüfen“) | 4, 6 |
| suche/ (siehe Abschnitt „Ergebnisse dokumentieren“) | Ergebnisse dokumentieren, mit Rechercheprotokoll (siehe Abschnitt „Ergebnisse dokumentieren“); Suchen im Web: Suchmaschinen, Google, Web-Archiv (siehe Abschnitt „Suchen im Web: Suchmaschinen, Google, Web-Archiv“); Datenbanken mit Zugang und Syntax (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“); Social Media durchsuchen (siehe Abschnitt „Social Media durchsuchen“) | 1, 2, 3, 5 |
| faktencheck/ (siehe Abschnitt „Texte prüfen: das Handwerk“) | Texte prüfen: das Handwerk (siehe Abschnitt „Texte prüfen: das Handwerk“); Bilder prüfen und Geolokation (siehe Abschnitt „Bilder prüfen und Geolokation“) | 5 |
| links/ (siehe Abschnitt „Werkzeuge nach Kapiteln“) | Werkzeuge nach Kapiteln (siehe Abschnitt „Werkzeuge nach Kapiteln“), Lesetipps: Artikel, Podcasts, Studien, Bücher (siehe Abschnitt „Lesetipps: Artikel, Podcasts, Studien, Bücher“), Recherche-Links zu Kulturthemen (siehe Abschnitt „Recherche-Links zu Kulturthemen“) | alle |
| folien/ (siehe Abschnitt „Seminarfolien“) | die Seminarfolien als PDF (Datei Folien_Recherche_und_Faktencheck.pdf), korrigierte Fassung, ohne Sprechernotizen | alle |
| gesamtpaket/ | alles in einer ZIP-Datei zum Herunterladen und Weitergeben | – |

Die Kapitel sind die der Seminarfolien (siehe Abschnitt „Seminarfolien“). Jeder Ordner hat eine eigene Seite, die erklärt, was darin liegt.

### In zwei Minuten loslegen

1. Öffnet agent/moby/Moby_Faktencheck.md (Datei Skills_zum_Kopieren/Moby_Faktencheck.txt).
2. Klickt oben rechts über dem Text auf das Kopier-Symbol („Copy raw file“).
3. Fügt alles in einen KI-Chat mit Websuche ein und schickt es ab.
4. Nächste Nachricht: „Prüfe diesen Text:“ und darunter euer Text.

**Eigenes Thema?** Genauso mit dem Prompthelfer (Datei Skills_zum_Kopieren/Prompthelfer.txt): einfügen, abschicken, Thema nennen. Er fragt nach und schreibt mit euch den Prompt.

Habt ihr ein Konto bei Claude oder Gemini, könnt ihr die Skills auch hochladen. Dann starten sie in jedem Chat von selbst, sobald eure Frage passt. Wie das geht, auch für Projekte und Agenten, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

**Herunterladen:** das Gesamtpaket zum Lesen und Weitergeben. Oder die Dateien so, wie sie hier liegen: grüner Knopf „Code“, dann „Download ZIP“.

### Spielregeln für KI

1. Ein Konto ist freiwillig. Jede Übung geht auch ohne.
2. Keine Namen, Telefonnummern oder anderen persönlichen Daten in Prompts.
3. Nur Dokumente hochladen, die schon öffentlich zugänglich sind.
4. Wo es geht: Verlauf aus, Training abwählen.
5. Jeder Link wird geöffnet. Was nicht geöffnet wurde, gilt als nicht verifiziert.
6. KI-Text, den ihr übernehmt, kennzeichnet ihr.

### Prüfstufen

Wie im Seminar trägt jeder Link eine Prüfstufe:

- **geöffnet (mit Datum):** Die Seite wurde aufgerufen und die Angabe dort gesehen.
- **übernommen:** aus den Seminarfolien oder dem Spickzettel übernommen, für dieses Repo nicht erneut geöffnet.
- **zu prüfen:** nicht verifiziert.

Zugänge und Preise ändern sich schnell. Alle Angaben stehen mit Datum und ohne Gewähr. Findet ihr einen toten Link oder eine veraltete Angabe, schreibt Florian.

### Kleines Wörterbuch

- **Prompt:** die Frage oder Anweisung, die ihr einer KI schreibt.
- **Skill:** ein langer Prompt mit festen Regeln für eine Aufgabe, die immer wiederkommt. Manche Tools laden ihn von selbst, sobald eure Frage passt.
- **Assistent (Projekt, GPT, Agent):** ein eingerichteter Raum in einem KI-Tool, der eure Anweisungen für jeden neuen Chat behält.
- **Websuche und Seitenabruf:** ob eine KI im Netz suchen kann und ob sie gefundene Seiten auch öffnet. „Snippet“ heißt: Sie kennt nur den kurzen Ausschnitt aus dem Suchtreffer, nicht die Seite.
- **Repo (Repository):** diese Sammlung auf GitHub, ein öffentlicher Ordner mit Dateien und ihrem Änderungsverlauf.
- **.md (Markdown):** einfache Textdateien mit wenigen Zeichen für die Formatierung, etwa `#` für Überschriften. GitHub zeigt sie formatiert an, jedes Textprogramm öffnet sie.
- **ZIP:** ein gepackter Ordner. Entpacken: am Mac per Doppelklick, unter Windows mit Rechtsklick und „Alle extrahieren“.

### Lizenz

Texte und Skills in diesem Repo stehen unter [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.de): Ihr dürft sie teilen und verändern, auch für eure Arbeit, wenn ihr die Quelle nennt und angebt, was ihr geändert habt. Für verlinkte Angebote Dritter gelten deren Bedingungen.

Die Skills beruhen auf Assistenten, die Florian in der Redaktion nutzt, und sind für dieses Seminar umgebaut.

Für die Pflege des Repos: wartung/.

---

<!-- Datei im Repo: folien/README.md -->

## Seminarfolien

Die Folien zum Seminar „Recherche und Faktencheck“ als PDF, in der korrigierten Fassung vom 09.11.2026.

**Folien_Recherche_und_Faktencheck.pdf (Datei Folien_Recherche_und_Faktencheck.pdf)** · 157 Seiten, 6 MB · anklicken, dann oben rechts auf den Pfeil nach unten („Download raw file“)

Ohne Sprechernotizen. Die Klick-Animationen sind im PDF aufgelöst: Jede Seite zeigt den fertigen Zustand der Folie.

### Wo welches Kapitel beginnt

| Kapitel | Seiten |
|---|---|
| 1. Grundlagen: Recherchestrategie, Ergebnisse dokumentieren | 3–11 |
| 2. Recherche im Web: Suchmaschinen, Google, Web-Archiv, Wikipedia | 12–35 |
| 3. Recherche in Datenbanken: Pressedatenbanken, Munzinger, Mediatheken | 36–54 |
| 4. KI-unterstützte Recherche: das Pult, Prompts, Skills, Agenten | 55–86 |
| 5. Faktencheck: Grundlagen | 87–92 |
| 5. Faktencheck: Text | 93–102 |
| 5. Faktencheck: Bild und Video | 103–133 |
| 5. Exkurs: Social Media | 134–138 |
| 6. KI-Tools für die Arbeit | 139–150 |
| Anhang: Recherche-Links zu Kulturthemen | 151–156 |

Was auf den Folien steht, findet ihr im Repo zum Nachschlagen, mit Links und Stand: Suchen (siehe Abschnitt „Ergebnisse dokumentieren“) (Kapitel 1–3 und Social Media), Prompts (siehe Abschnitt „Prompten: von der Frage zum Auftrag“) und KI-Tools (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“) (Kapitel 4 und 6), Faktencheck (siehe Abschnitt „Texte prüfen: das Handwerk“) (Kapitel 5), Kultur-Links (siehe Abschnitt „Recherche-Links zu Kulturthemen“) (Anhang).

### Was ihr damit machen dürft

Die Folien stehen unter [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.de) wie das ganze Repo: teilen und verändern, wenn ihr die Quelle nennt. **Ausgenommen sind Fotos und Screenshots Dritter**, etwa Agenturfotos und Bildschirmfotos von Websites. Sie gehören ihren Rechteinhabern und sind nur zur Ansicht hier.

Die Angaben auf den Folien haben den Stand des Seminars. Zugänge und Preise ändern sich schnell: Im Zweifel gilt die Seite im Repo mit dem jüngeren Datum.

---

<!-- Datei im Repo: skills/README.md -->

## Skills und Moby: Überblick und Anleitung

Ein Skill ist ein Text mit Anweisungen und Regeln für eine Aufgabe, die immer wiederkommt, etwa einen Text auf Fakten prüfen. Jeder Skill liegt in einem eigenen Ordner, in der Datei `SKILL.md`. Oben in der Datei steht, wofür der Skill zuständig ist. Tools, die Skills kennen, laden ihn dann von selbst, sobald eure Frage passt. Alle anderen Tools bekommen denselben Text zum Einfügen. Programmieren müsst ihr dafür nichts.

Moby (siehe Abschnitt „Moby zum Mitnehmen“) ist kein Skill, sondern ein Assistent mit eigenem Raum: ein Projekt, ein GPT oder ein Le-Chat-Agent, in dem jede Nachricht ein Text zum Prüfen ist. Wie ihr ihn einrichtet, steht bei Moby.

### Die sechs Skills und Moby

| | Was er tut | Braucht Websuche? | Kapitel |
|---|---|---|---|
| Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) | prüft einen Text oder eine einzelne Behauptung, trennt widerlegt und nicht belegt | ja | 5 |
| Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) | verfolgt ein Zitat, eine Zahl oder Behauptung bis zum Ursprung | ja, am besten mit Seitenabruf | 5 |
| Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) | recherchiert ein Thema mit Belegen, Gegenprobe und Quellenkritik | ja | 2, 4 |
| Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“) | sortiert eine Debatte: Lager, Stimmen, Konsens und Streit, jede Position belegt | ja, am besten mit Seitenabruf | 4 |
| PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) | baut Suchstrings für SZ, F.A.Z., Genios/WISO und LexisNexis | hilfreich, nicht nötig | 3 |
| Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) | schreibt mit euch Prompts, Agenten-Aufträge und eigene Skills für ein selbst gewähltes Thema | nein | 4 |
| Moby (siehe Abschnitt „Moby zum Mitnehmen“) (Assistent) | prüft einen ganzen Text, in einem eigenen Projekt, GPT oder Agenten | ja | 5 |

Faktencheck und Moby prüfen nach derselben Methode. Den Unterschied erklärt die Seite zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).

### Welche Datei wofür

In jedem Skill-Ordner liegen die `SKILL.md` und eine README, die erklärt, was der Skill kann und wie ihr ihn fragt. Die Pakete zum Hochladen liegen gesammelt im Ordner `zum-hochladen` (siehe Abschnitt „Pakete zum Hochladen“).

Die `SKILL.md` ist die Langfassung: zum Einfügen in einen Chat, als Datei für ein Projekt und als Inhalt des Pakets zum Hochladen. Der Kopf oben mit `name` und `description` stört beim Einfügen nicht.

| | Langfassung | Kurzfassung | Paket zum Hochladen |
|---|---|---|---|
| Faktencheck | `SKILL.md` (Datei Skills_zum_Kopieren/Faktencheck.txt), 20.500 Zeichen | – (nehmt Moby kurz (Datei Skills_zum_Kopieren/Moby_kurz.txt)) | `faktencheck.zip` (Datei Skills_zum_Hochladen/faktencheck.zip) |
| Herkunftscheck | `SKILL.md` (Datei Skills_zum_Kopieren/Herkunftscheck.txt), 16.700 Zeichen | 3.600 Zeichen (Datei Skills_zum_Kopieren/Herkunftscheck_kurz.txt) | `herkunftscheck.zip` (Datei Skills_zum_Hochladen/herkunftscheck.zip) |
| Themenrecherche | `SKILL.md` (Datei Skills_zum_Kopieren/Themenrecherche.txt), 16.000 Zeichen | 3.600 Zeichen (Datei Skills_zum_Kopieren/Themenrecherche_kurz.txt) | `themenrecherche.zip` (Datei Skills_zum_Hochladen/themenrecherche.zip) |
| Expertenmeinungen | `SKILL.md` (Datei Skills_zum_Kopieren/Expertenmeinungen.txt), 22.000 Zeichen | 4.100 Zeichen (Datei Skills_zum_Kopieren/Expertenmeinungen_kurz.txt) | `expertenmeinungen.zip` (Datei Skills_zum_Hochladen/expertenmeinungen.zip) |
| PDB-Helfer | `SKILL.md` (Datei Skills_zum_Kopieren/PDB-Helfer.txt), 9.900 Zeichen | – | `pdb-helfer.zip` (Datei Skills_zum_Hochladen/pdb-helfer.zip) |
| Prompthelfer | `SKILL.md` (Datei Skills_zum_Kopieren/Prompthelfer.txt), 17.000 Zeichen | 5.200 Zeichen (Datei Skills_zum_Kopieren/Prompthelfer_kurz.txt) | `prompthelfer.zip` (Datei Skills_zum_Hochladen/prompthelfer.zip) |
| Moby | `Moby_Faktencheck.md` (Datei Skills_zum_Kopieren/Moby_Faktencheck.txt), 23.100 Zeichen | 4.600 Zeichen (Datei Skills_zum_Kopieren/Moby_kurz.txt) | – |

Nehmt, wenn möglich, die Langfassung: Nur sie enthält die Quellenregeln mit Beispielen und alle Sonderfälle. Die Kurzfassung ist für Anweisungsfelder mit Zeichenlimit.

### Kopieren und herunterladen ohne GitHub-Konto

1. Datei anklicken, etwa `herkunftscheck/SKILL.md`.
2. Oben rechts über dem Text auf das Symbol mit den zwei Rechtecken klicken („Copy raw file“). Der ganze Text liegt jetzt in der Zwischenablage.
3. Alternativ „Raw“ klicken, dann alles markieren und kopieren.

Ein Paket herunterladen: im Ordner `zum-hochladen/` (siehe Abschnitt „Pakete zum Hochladen“) die ZIP-Datei anklicken, dann oben rechts auf den Pfeil nach unten („Download raw file“).

Alles auf einmal: auf der Startseite des Repos grüner Knopf „Code“, dann „Download ZIP“.

### So geht's

**Überall, ohne Einrichtung**
1. Neuen Chat öffnen, Websuche einschalten, falls es dafür einen Schalter gibt.
2. Den ganzen Inhalt der `SKILL.md` einfügen und abschicken.
3. In der nächsten Nachricht euren Auftrag: den Text zum Prüfen, das Thema, das Zitat oder die Suchanfrage.

Der Skill gilt nur in diesem Chat. Für den nächsten Auftrag öffnet ihr einen neuen Chat und fügt ihn wieder ein, oder ihr richtet ihn dauerhaft ein (siehe unten).

**Als Skill in Claude** (Konto nötig, geht auch gratis)
1. Code-Ausführung einschalten: in den Einstellungen unter „Capabilities“. Skills brauchen sie, auch wenn diese Skills selbst keinen Code ausführen.
2. Das Paket herunterladen, etwa `herkunftscheck.zip`. Nicht entpacken.
3. In Claude: „Customize“, dann „Skills“, auf „+“ klicken, „Create skill“, „Upload a skill“, die ZIP-Datei wählen.
4. Den Skill eingeschaltet lassen. Ab jetzt startet er in jedem Chat von selbst, wenn eure Frage passt. Ihr könnt ihn auch beim Namen rufen: „Nutze den Herkunftscheck.“

**Als Skill in Gemini** (Google-Konto ab 18, in der Web-App oder der Mac-App)

Gems werden am 17.11.2026 schreibgeschützt und am 17.12.2026 gelöscht. An ihre Stelle treten Skills.
1. In Gemini in der Seitenleiste „Customize“, dann „Skills“, dann „Create“ und „Create manually“.
2. Name: der `name` aus dem Kopf der `SKILL.md`, etwa `herkunftscheck`. Beschreibung: der Text hinter `description`. Anweisungen: alles unter dem Kopf.
3. Speichern und im Chat loslegen.

Statt von Hand könnt ihr den Skill auch hochladen: Paket herunterladen und entpacken, dann bei einem angelegten Skill über „More options“ und „Replace skill“ den entpackten Ordner wählen. Der Ordner muss genauso heißen wie der Skill. Die Menünamen stammen aus der englischen Google-Hilfe, in der deutschen Oberfläche können sie anders heißen.

**Als Projekt in Claude oder ChatGPT**
1. Neues Projekt anlegen, etwa „Herkunftscheck“.
2. Die `SKILL.md` als Datei hochladen oder den Inhalt in die Projektanweisungen kopieren.
3. Falls ihr die Datei hochgeladen habt, in die Anweisungen schreiben: „Arbeite immer nach der Datei SKILL.md. Jede Nachricht ist ein neuer Auftrag.“
4. Im Projekt einen Chat starten und loslegen. Jeder neue Chat im Projekt kennt die Regeln.

**Als Agent in Le Chat**
1. Neuen Agenten anlegen.
2. Kurz- oder Langfassung in die Anweisungen kopieren, Websuche aktivieren.
3. Agent im Chat aufrufen und loslegen.

**Als GPT in ChatGPT:** Das Anweisungsfeld ist auf 8.000 Zeichen begrenzt, also die Kurzfassung nehmen, beim Faktencheck und beim PDB-Helfer die Datei hochladen. Ob ihr ohne Abo eigene GPTs anlegen könnt, ist nicht geprüft. Skills zum Hochladen gibt es in ChatGPT laut OpenAI bisher nur in Business, Enterprise und Edu.

**In Programmier-Werkzeugen** wie Claude Code, Gemini CLI oder GitHub Copilot: Diese Werkzeuge lesen Skill-Ordner mit `SKILL.md` direkt. Den entpackten Ordner in den Skill-Ordner des Werkzeugs legen.

Für Claude, ChatGPT, Gemini und Le Chat braucht ihr ein Konto. Ein Konto ist freiwillig. Welche Tools ohne Konto eine Websuche haben, steht in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“).

### Skills sind Text: erst lesen, dann hochladen

- Die Skills in diesem Repo sind reiner Text, ohne Skripte oder Programme. In jeder ZIP-Datei liegt nur die `SKILL.md`, die ihr hier lesen könnt.
- Fremde Skills lest ihr vor dem Hochladen. Ein Skill kann Anweisungen und Skripte enthalten, die euer Assistent dann befolgt oder ausführt. Im Juli 2026 zählte die Sicherheitsfirma Island über 800 gefälschte GitHub-Repos, die sich als KI-Skills oder MCP-Server tarnten und Schadsoftware verbreiteten. Mehr dazu in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

### Für alle Skills gilt

- **Öffnet die Links selbst.** Steht „Snippet“ oder „Snippet-Basis“ dabei, hat der Assistent nur den Suchtreffer gesehen, nicht die Seite.
- **Ein ✅ oder 🟢 heißt nicht, dass ihr nicht mehr nachschauen müsst.** Es heißt, dass der Assistent Belege gefunden hat.
- **Keine persönlichen Daten** und nur öffentliches Material in die Prompts (Spielregeln 2 und 3).
- **Die Verantwortung für euren Text bleibt bei euch.**

### Das würde die Skills noch besser machen

- **Eine eigene Quellenliste:** welche Quellen ihr zuerst nehmt, welche nie. Baut sie für euer Fachgebiet und hängt sie als Datei an.
- **Euer eigenes Material:** Rechercheordner, Protokolle, Dokumente als Dateien ins Projekt.
- **Pressedatenbanken:** Was die Skills hinter Bezahlschranken nicht finden, sucht ihr mit dem PDB-Helfer in den Datenbanken eurer Bibliothek.
- **Daten direkt:** Über MCP (Model Context Protocol) lassen sich Datenbanken und Dienste an KI-Assistenten anbinden. Mehr dazu in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).
- **Ein Ablauf statt eines einzelnen Prompts:** feste Schritte mit je eigenem Auftrag, etwa wichtige Fakten gründlich und Nebensachen schnell prüfen. Das braucht eine Plattform für solche Abläufe (Workflows).
- **Euer eigener Skill:** Was ihr zum zweiten Mal genauso macht, ist ein Skill. Ordner anlegen, darin eine `SKILL.md` mit `name` und `description` im Kopf und euren Regeln darunter. Die Skills hier sind Vorlagen dafür, ein leeres Gerüst liegt beim Prompthelfer (siehe Abschnitt „Vorlage: einen Skill selbst schreiben“), und der Prompthelfer baut einen Skill auch mit euch.

### Erst testen, dann nutzen

Nicht jeder Skill läuft in jedem Tool gleich gut. Probiert einen Skill zuerst mit einer Aufgabe aus, deren Ergebnis ihr kennt, etwa aus dem Seminar:

- **Moby und Faktencheck:** der Übungstext aus Kapitel 5. Finden sie alle Fehler, und wo kommen sie ohne PDF nicht weiter?
- **Herkunftscheck:** die zentrale Zahl aus dem Übungstext. Kommt er bis zum Originaldokument?
- **Themenrecherche:** die Leitfrage aus Kapitel 4. Nennt er Primärquellen und markiert Unbelegtes?
- **Expertenmeinungen:** eine Kulturdebatte, etwa KI in der Musikproduktion. Leitet er die Lager aus den Treffern ab, hat jede Stimme eine Fundstelle, sind Snippets markiert?
- **PDB-Helfer:** eine Suche nach Interviews mit einer Person im SZ-Archiv und dieselbe Suche für WISO. Läuft der String ohne Fehlermeldung?
- **Prompthelfer:** ein selbst gewähltes Thema. Fragt er nach, bevor er schreibt? Steht der Prompt kopierfertig im Kasten, und läuft er in einem neuen Chat?
- **Hochladen:** Nimmt euer Tool das Paket an, und startet der Skill von selbst, ohne dass ihr ihn nennt?

Notiert euch pro Tool: läuft, läuft mit Einschränkung oder läuft nicht, und ein Stichwort, warum.

Ob Skills in Gemini den gespeicherten Verlauf voraussetzen, ist nicht geklärt. Das stünde gegen Spielregel 4 („Verlauf aus“). Ein Blog behauptet es, die Google-Hilfe sagt dazu nichts.

### Belege für die Angaben zu den Tools

- Claude Free: Websuche und bis zu fünf Projekte, laut [claude.com/pricing](https://claude.com/pricing), geöffnet am 31.10.2026.
- Skills in Claude für Free, Pro, Max, Ultra, Team und Enterprise, Code-Ausführung nötig, Hochladen als ZIP unter Customize > Skills, laut [Claude-Hilfe](https://support.claude.com/en/articles/12512180-use-skills-in-claude), geöffnet am 03.11.2026.
- Gems ab 17.11.2026 schreibgeschützt, ab 17.12.2026 entfernt; Skills für Personen ab 18 mit privatem Google-Konto; Hochladen nur in der Web-App und der Mac-App; Ordnername gleich Skillname, klein mit Bindestrich; höchstens 100 MB, laut [Gemini-Hilfe](https://support.google.com/gemini/answer/18560919?hl=en), geöffnet am 03.11.2026.
- Skills in ChatGPT für Business, Enterprise, Healthcare und Edu, laut [OpenAI-Hilfe](https://help.openai.com/en/articles/20001066-skills-in-chatgpt), übernommen aus dem Suchtreffer; die Seite war am 03.11.2026 nicht abrufbar.
- ChatGPT-Projekte für Free-Nutzer seit September 2025, laut [promptoptimizer.tools, 23.07.2026](https://promptoptimizer.tools/blog/how-to-use-chatgpt-projects), Drittquelle, geöffnet am 01.11.2026.
- GPT-Anweisungen höchstens 8.000 Zeichen, laut [OpenAI Developer Community, 04.06.2024](https://community.openai.com/t/how-can-i-increase-the-ceiling-for-gpt-instructions-beyond-8000-characters/801867), geöffnet am 01.11.2026. Ein neuerer Stand ist zu prüfen.
- Agents in Le Chat ohne Abo, aber mit Konto, laut Mistral-Hilfe, geprüft am 31.10.2026. Skills im Ordnerformat: in einer Websuche am 03.11.2026 kein Beleg gefunden.
- Programmier-Werkzeuge mit Skill-Ordnern, etwa die [Gemini CLI](https://geminicli.com/docs/cli/skills): übernommen, nicht geöffnet.

---

<!-- Datei im Repo: skills/faktencheck/README.md -->

## Faktencheck zum Mitnehmen

Der Faktencheck prüft einen Text oder eine einzelne Behauptung auf Faktentreue. Er zieht die prüfbaren Fakten heraus, sucht Belege und unterscheidet genau: **widerlegt** (❌) ist etwas anderes als **nicht belegt** (⭕) oder **nicht prüfbar** (❓). Bevor er „nicht belegt“ sagen darf, muss er sechs Rechercherouten durchlaufen. Jede Abweichung bewertet er mit dem Schadentest: Wie sehr schadet sie dem Text? Passt zu Kapitel 5 des Seminars.

Stand: 03.11.2026

### Faktencheck oder Moby?

Beide prüfen nach derselben Methode wie im Seminar. Der Unterschied liegt darin, wie ihr sie einsetzt:

| | Moby (siehe Abschnitt „Moby zum Mitnehmen“) | Faktencheck |
|---|---|---|
| Was es ist | ein Assistent mit eigenem Raum: Projekt, GPT oder Le-Chat-Agent | ein Skill, der in einem normalen Chat von selbst startet, wenn ihr um eine Prüfung bittet |
| Was ihr schickt | jede Nachricht ist der Prüftext | „Prüfe diesen Text: …“ oder „Stimmt es, dass …?“ |
| Einzelne Behauptung | prüft sie wie einen Text | eigener Kurzcheck mit kompakter Antwort |
| Status | ❌ heißt falsch oder nicht belegt | ❌ widerlegt und ⭕ nicht belegt sind getrennt |
| Am besten in | Claude-Projekt, ChatGPT-Projekt, GPT, Le-Chat-Agent | Claude und Gemini als hochgeladener Skill, sonst überall zum Einfügen |

In Gemini gibt es ab dem 17.11.2026 keine neuen Gems mehr. Dort nehmt ihr den Faktencheck als Skill.

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.800 Wörter, 20.500 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `faktencheck.zip` (Datei Skills_zum_Hochladen/faktencheck.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Eine Kurzfassung gibt es nicht. Für Anweisungsfelder mit Zeichenlimit nehmt die Kurzfassung von Moby (Datei Skills_zum_Kopieren/Moby_kurz.txt). Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann, am besten auch Seiten **öffnen und lesen**. Ohne Websuche liefert der Faktencheck nur die Liste der Fakten, die zu prüfen wären, und vergibt keinen Status.

### So fragt ihr

- „Prüfe diesen Text:“ und darunter euer Text
- „Faktencheck für diesen Artikel“ und darunter der Link
- „Stimmt es, dass Theater in Deutschland mehr Zuschauer haben als die Fußball-Bundesliga?“ (Kurzcheck)

### Das Ergebnis lesen

| Symbol | heißt |
|---|---|
| ✅ | zwei unabhängige Quellen gefunden, bei wichtigen Fakten eine davon gelesen |
| ⚠️ | Abweichung im Detail |
| ❌ | widerlegt: Eine belastbare Quelle zeigt das Gegenteil |
| ⭕ | nicht belegt: kein Beleg und kein Gegenbeleg, nach allen Rechercherouten |
| ❓ | nicht prüfbar, etwa weil Fachwissen oder ein Archivzugang fehlt |
| ⏰ | veraltet: stimmte zum Textdatum, hat sich seither geändert |
| ⏸️ | noch nicht geprüft. Schreibt „weiter“ |
| 🔴S / 🟡N | schwerwiegend / nicht gravierend, laut Schadentest |

- Fangt bei den **kritischen Befunden** an.
- **Öffnet die Links selbst.** „Snippet-Basis“ heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite.
- Ein ✅ heißt nicht, dass ihr nicht mehr nachschauen müsst. Die Verantwortung für euren Text bleibt bei euch.

### Grenzen

- **Keine Bezahlschranken:** Er umgeht sie nicht, sondern sucht frei zugängliche Fassungen oder bittet euch um den Text. Was nur in Pressedatenbanken steht, sucht ihr mit dem PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) und euren Bibliothekszugängen.
- **Einzelne Zitate und Zahlen:** Woher sie ursprünglich stammen, verfolgt der Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) gründlicher.
- **Nicht prüfbar:** Braucht eine Prüfung Fachwissen, interne Unterlagen oder einen Archivzugang, vergibt er ❓. Dann seid ihr dran.

### Herkunft

Diese Fassung beruht auf dem Faktencheck-Skill, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Quellenregeln eingebaut** als Kurzfassung, wie bei Moby. In der Redaktion hängt ein eigenes Regelwerk als Datei an.
- **Kein Plattformbezug:** keine Werkzeugnamen, keine festen Abrufzahlen, keine Übergabe an andere Assistenten.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind, die Hinweise zu Zuschreibungen, Bezugsgrößen und absoluten Aussagen aus Moby, Korrekturvorschläge und Zählprobe.

---

<!-- Datei im Repo: skills/herkunftscheck/README.md -->

## Herkunftscheck zum Mitnehmen

Der Herkunftscheck verfolgt **ein** Zitat, **eine** Zahl oder **eine** Behauptung rückwärts bis zum Ursprung: Wer hat das zuerst gesagt oder veröffentlicht, wann, wo und in welchem Wortlaut? Er läuft als Skill in einem KI-Assistenten mit Websuche und liefert eine Herkunftskette mit Belegen und einer Konfidenz.

Die Abgrenzung zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und zu Moby (siehe Abschnitt „Moby zum Mitnehmen“): Die prüfen, ob etwas stimmt, der Herkunftscheck fragt, woher es stammt, und geht bei einer einzelnen Aussage in die Tiefe. Passt zu Kapitel 5 des Seminars.

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.200 Wörter, 16.700 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Herkunftscheck_kurz.md` | rund 3.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `herkunftscheck.zip` (Datei Skills_zum_Hochladen/herkunftscheck.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

### Voraussetzung

Ein KI-Assistent mit **Websuche**, der Seiten auch **öffnen** kann. Nur dann kann er die Primärquelle selbst lesen und 🟢 vergeben. Kann er nur suchen, bittet er euch, die Quelle zu öffnen und den Absatz einzufügen. Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### So fragt ihr

Das Item möglichst wortgenau eingeben, mit der angeblichen Herkunft, wenn ihr sie kennt:

- „Woher stammt das Zitat ‚Kunst ist schön, macht aber viel Arbeit‘? Angeblich Karl Valentin.“
- „Woher kommt die Zahl, dass jede dritte Bühne in Deutschland Besucher verloren hat?“
- „In diesem Artikel steht eine Zahl zu den Besucherzahlen. Woher stammt sie?“ und darunter den Link

### Das Ergebnis lesen

| Symbol | heißt |
|---|---|
| 🟢 | Original im Volltext gelesen, Wortlaut oder Wert stimmt |
| 🟡 | stimmige Kette, aber das Original war nicht lesbar |
| 🟡ˢ | wie 🟡, nur aus Suchtreffer-Ausschnitten |
| 🟠 | widersprüchliche Zuschreibungen oder Wortlaute |
| 🔴 | Ursprung nicht belegbar |
| ⏸️ | unfertig: Primärquelle gefunden, aber noch nicht geöffnet. Schreibt „weiter“ |

- Die **Herkunftskette** steht mit dem jüngsten Beleg oben und dem Erstbeleg unten.
- Öffnet mindestens die unterste Station selbst. Erst dann zitiert ihr.
- Viele Treffer heißen nicht viele Belege: Medien, die sich aufeinander beziehen, sind eine Quelle.

### Grenzen

- **Ein Item pro Auftrag:** ein Zitat, eine Zahl oder eine Behauptung. Einen ganzen Text prüft der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Keine Bilder:** Woher ein Foto stammt, klärt eine Bild-Rückwärtssuche, nicht dieser Skill.
- **Keine Bezahlschranken:** Er umgeht sie nicht, sondern sucht frei zugängliche Fassungen oder bittet euch, die Quelle zu öffnen und den Absatz einzufügen.

### Herkunft

Diese Fassung beruht auf dem Herkunftscheck, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Kein Plattformbezug.** „Seite öffnen“ statt eines bestimmten Werkzeugs, keine Verweise auf andere Skills.
- **Quellenregeln eingebaut** als Kurzfassung, ohne Ausschlussliste mit Namen.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind. Beispiele ohne Redaktionsbezug. Als Skill-Ordner mit `SKILL.md`, damit er sich in Claude und Gemini hochladen lässt.

---

<!-- Datei im Repo: skills/themenrecherche/README.md -->

## Themenrecherche zum Mitnehmen

Die Themenrecherche ist ein Recherche-Skill, der in einem KI-Assistenten mit Websuche läuft. Ihr gebt ein Thema oder eine Frage ein, er sucht zuerst bei Primärquellen, belegt jeden Fakt mit Link, macht bei Streitthemen die Gegenprobe und schließt mit Quellenverzeichnis und Quellenkritik. Das ist die Arbeitsweise aus den Kapiteln 2 und 4 des Seminars.

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.100 Wörter, 16.000 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Themenrecherche_kurz.md` | rund 3.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `themenrecherche.zip` (Datei Skills_zum_Hochladen/themenrecherche.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Wenn ihr die Wahl habt, nehmt die Langfassung.

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann, am besten auch Seiten **öffnen und lesen**. Ohne Websuche liefert der Assistent nur einen Rechercheplan und keine Fakten. Wie ihr den Skill in Chat, Projekt, als hochgeladenen Skill oder als Agent einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### So fragt ihr

Einfach das Thema oder die Frage schreiben. Beispiele:

- „Recherchiere: Wie werden freie Theater in Bayern gefördert?“
- „Kurz: Wer leitet ab 2027 das Filmfest München?“
- „Deep Dive zur Debatte um Rückgaben von Kolonialobjekten aus Münchner Museen“
- „Was ist gerade los bei [Ereignis]?“ (News-Modus)
- „Gib mir eine kommentierte Quellenliste zu [Thema]“

„Kurz“ heißt 2–3 Suchen, „Deep Dive“ 8–15, ohne Angabe 4–7.

### Das Ergebnis lesen

- Der **Kernbefund** steht oben. Darunter steht, wie belastbar er ist.
- „Eingeschränkt belegt“ heißt: nur ein Quellentyp. Das ist eine Spur, kein Fakt.
- **Öffnet die Links selbst**, vor allem bei Zahlen und Zitaten. „Snippet-Basis“ heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite.
- Die **Quellenkritik** am Ende sagt, wo die Lücken sind und was ihr als Nächstes prüfen solltet.
- ⏸️ heißt: unfertig. Schreibt „weiter“, dann recherchiert er die offenen Punkte.

### Grenzen

- Sie kommt nicht hinter Bezahlschranken und nicht in Pressedatenbanken. Dafür gibt es den PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) und eure Bibliothekszugänge.
- Sie ersetzt keinen Anruf. Die Quellenkritik sagt euch, welcher Anruf am meisten absichert.
- Sie prüft keinen fertigen Text. Dafür gibt es den Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und Moby (siehe Abschnitt „Moby zum Mitnehmen“).
- Sie sortiert keine Debatte nach Stimmen und Lagern. Dafür gibt es Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“).

### Herkunft

Diese Fassung beruht auf dem Recherche-Assistenten, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Kein Plattformbezug** und keine Verweise auf andere Skills oder Zusatzdateien.
- **Quellenregeln eingebaut**, als Kurzfassung wie bei Moby, ohne Ausschlussliste mit Namen und ohne politische Einordnung einzelner Medien.
- **Neu:** der Check zu Beginn, ob Websuche und Datum verfügbar sind, und der Hinweis auf die Pressedatenbanken der Bibliothek bei Bezahlschranken.

---

<!-- Datei im Repo: skills/expertenmeinungen/README.md -->

## Expertenmeinungen zum Mitnehmen

Expertenmeinungen sortiert eine Debatte, statt sie zusammenzufassen: Welche Lager gibt es zu einem Thema, wer sind die wichtigsten Stimmen je Lager, wo sind sich alle einig und worüber wird gestritten? Jede Position ist mit einer Aussage und ihrer Fundstelle belegt. Der Skill läuft in einem KI-Assistenten mit Websuche.

Die Abgrenzung: Die Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) fragt „Was ist belegt?“, Expertenmeinungen fragt „Wer sagt was?“. Den Text, den ihr daraus schreibt, prüft der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) oder Moby (siehe Abschnitt „Moby zum Mitnehmen“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 3.000 Wörter, 22.000 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Expertenmeinungen_kurz.md` | rund 4.100 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) |
| `expertenmeinungen.zip` (Datei Skills_zum_Hochladen/expertenmeinungen.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Voraussetzung

Ein KI-Assistent mit **Websuche**, am besten einer, der Seiten auch **öffnen** kann. Nur dann darf er wörtlich zitieren. Kann er nur suchen, gibt er die Positionen mit eigenen Worten wieder und schreibt „Snippet-Basis“ dazu. Ohne Websuche nennt er keine Namen, sondern liefert einen Suchplan.

### So fragt ihr

- „Wie schätzen Fachleute KI in der Musikproduktion ein?“ (Themen-Dossier, Standard)
- „Welche Lager gibt es in der Debatte um die Rückgabe von Kolonialobjekten?“
- „Wen kann ich zur Förderung freier Theater in Bayern anfragen?“ (Expertenliste)
- „Was sagt [Name] zur Zukunft des Stadttheaters?“ (Kurzprofil einer Person)
- „Mach daraus ein Kompakt-Briefing“ oder „eine Zitat-Tabelle“

### Das Ergebnis lesen

- Oben steht die **Kurzantwort**, darunter die **Lage**, dann die **Debattenstränge** mit den Stimmen.
- Jede Person hat eine Nummer (E01, E02 …). Damit könnt ihr nachfragen: „E03 vertiefen“.
- **„Snippet-Basis“** heißt: Der Assistent hat nur den Suchtreffer gesehen, nicht die Seite. Ein Zitat mit diesem Vermerk ist nicht wörtlich geprüft.
- Die **Einordnung** am Ende sagt, wessen Stimmen fehlen und welches Gespräch am meisten absichern würde.
- **Öffnet die Fundstelle**, bevor ihr jemanden zitiert. Prüft auch, ob die Funktion der Person noch stimmt.

### Grenzen

- **Wer etwas sagt, belegt nur, dass er es sagt.** Ob es stimmt, ist eine eigene Prüfung, etwa mit dem Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Nur öffentliche Stimmen** und ihre öffentlichen Aussagen. Private Angaben über Personen gehören nicht in den Prompt (Spielregel 2).
- **Keine Bezahlschranken:** Er umgeht sie nicht, vermerkt sie und sucht eine andere Quelle.
- **Drei Modi:** Themen-Dossier, Expertenliste und Kurzprofil. Eine Person über Jahre verfolgen kann er nicht (siehe Herkunft).

### Herkunft

Diese Fassung beruht auf dem Skill „Expertenmeinungen“, den Florian in der Redaktion nutzt, umgebaut für verschiedene Plattformen. Was anders ist:

- **Drei Modi statt sechs:** Themen-Dossier, Expertenliste, Positions-Kurzprofil. Das Voll-Tracking einer Person über Jahre und der Faktencheck einer Position fallen weg. Sie brauchen viele geöffnete Seiten und ein Belegregister, das in Gratis-Tools selten durchhält.
- **Eine Datei statt sieben:** Die sechs Zusatzdateien der Redaktionsfassung stehen als Text im Skill.
- **Dieselben Quellenregeln** wie in den anderen Skills dieses Repos, ergänzt um Regeln für Zitate, Mediatheken und Interessen.
- **Kein Plattformbezug:** keine Werkzeugnamen. HTML-Dossier und CSV nur, wenn euer Tool Dateien erzeugen kann.
- **Neu:** der Check zu Beginn, ob Websuche, Seitenabruf und Datum verfügbar sind, Beispiele aus der Kultur, die Regel zu Personen ohne öffentliche Rolle.

---

<!-- Datei im Repo: skills/pdb-helfer/README.md -->

## PDB-Helfer zum Mitnehmen

Der PDB-Helfer baut euch Suchstrings für Pressedatenbanken (PDB): zwei kopierfertige Strings, einen engen und einen weiten, und erklärt jeden Baustein. Standard ist das Archiv der Süddeutschen Zeitung über die Stabi (Bayerische Staatsbibliothek). Auf Wunsch schreibt er den String für F.A.Z., Genios/WISO oder LexisNexis um. Ihr kopiert den String in die Datenbank, meldet die Trefferzahl zurück, und er justiert nach.

Passt zu Kapitel 3 des Seminars. Zugänge und Syntax aller Datenbanken stehen in Datenbanken: Zugänge und Suchsyntax (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 1.400 Wörter, 9.900 Zeichen | in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen. Für GPTs mit 8.000 Zeichen Limit zu lang: dort als Datei hochladen |
| `pdb-helfer.zip` (Datei Skills_zum_Hochladen/pdb-helfer.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |

### Voraussetzung

Ein beliebiger KI-Chat. Websuche ist hilfreich, um Schreibweisen und passende Begriffe zu finden, aber nicht nötig. Ohne Websuche schreibt der Helfer dazu, dass ihr Schreibweisen selbst prüfen sollt. Wie ihr den Skill einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Für die Datenbank selbst braucht ihr euren Ausweis der Stabi oder der Stadtbibliothek.

### So fragt ihr

- „Suchstring für Artikel über die Akustik der Isarphilharmonie“
- „Interviews mit Kirill Petrenko, nur die letzten zwei Jahre“
- „Das gleiche bitte für WISO“
- „Eng hatte 3 Treffer, weit 850“
- „Fehlermeldung: unerwartetes Suchelement“

### Das Ergebnis lesen

Ihr bekommt:

1. eine Zeile, was er zu Schreibweisen und Begriffen gefunden hat
2. **String eng** und **String weit**, jeweils zum Kopieren
3. eine kleine Tabelle: welcher Baustein was bewirkt
4. was ihr in der Suchmaske einstellen solltet (Zeitraum, Ressort, Artikeltyp)

Dann meldet ihr die Trefferzahlen. Ziel sind etwa 20 bis 100 Treffer. Der Helfer ändert pro Runde nur eine Stellschraube, damit ihr seht, was wirkt.

### Die wichtigsten Operatoren im SZ-Archiv

| Syntax | Bedeutung |
|---|---|
| `ATLEAST.5(Petrenko*)` | Wort kommt mindestens fünfmal vor |
| `NEAR.10(Petrenko, Philharmoniker)` | höchstens zehn Wörter Abstand |
| `ONEAR.3(Zauberflöte, Inszenierung)` | wie NEAR, in dieser Reihenfolge |
| `*philharmonie` | Linkstrunkierung, findet auch Isarphilharmonie |

Häufigster Fehler: mehrere Wörter in einer ATLEAST-Klammer. `ATLEAST.3(Oper* AND Intendant*)` geht nicht, richtig ist `ATLEAST.3(Oper*) AND ATLEAST.3(Intendant*)`.

### Grenzen

- **Er fragt die Datenbanken nicht selbst ab.** Die Suche macht ihr, er baut nur die Strings.

Nicht gesichert ist bisher:

- Ob `begriff#N` (F.A.Z., WISO) und `atleastN(…)` (LexisNexis) zusammen mit `*` funktionieren.
- Ob Linkstrunkierung außerhalb des SZ-Archivs geht.
- Ob die Suchmaske im SZ-Archiv einen Artikeltyp „Interview“ anbietet.

Testet das mit einer Suche, deren Treffer ihr ungefähr kennt. Mehr dazu in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Herkunft

Diese Fassung beruht auf dem Suchstring-Assistenten, den Florian in der Redaktion nutzt, umgebaut für den Bibliothekszugang. Was anders ist:

- **Nur die Operatoren von der Seminarfolie.** Die Redaktion arbeitet mit einem internen System und weiteren Feldcodes, etwa für Titel, Publikation oder Datum. Ob die im Bibliothekszugang funktionieren, ist nicht geprüft. Zeitraum, Ressort und Artikeltyp stellt ihr deshalb in der Suchmaske ein.
- **Keine Quellenlisten und Publikationscodes** der Redaktion.
- **Neu:** Umrechnung für F.A.Z., Genios/WISO und LexisNexis, Erklärung jedes Bausteins, funktioniert auch ohne Websuche.

---

<!-- Datei im Repo: skills/prompthelfer/README.md -->

## Prompthelfer zum Mitnehmen

Der Prompthelfer schreibt mit euch einen Prompt für ein Thema, das ihr euch selbst aussucht, egal welches. Er fragt nach, was ihr vorhabt, schlägt die passende Form vor und liefert einen fertigen Prompt zum Kopieren, dazu kurz, warum er so gebaut ist. Den Prompt setzt ihr dann in einem neuen Chat ein.

Stand: 05.11.2026

### Was er kann

| Ihr wollt … | Er liefert |
|---|---|
| einmal eine Antwort auf eine Frage | eine Einzelfrage: Zweck, Kontext, Frage, Quellen, Output |
| ein Tool selbst suchen lassen (Deep Research, Agent) | einen Agenten-Auftrag: Ziel, erst der Plan, Grenzen, Belege, Format |
| dieselbe Aufgabe öfter erledigen | einen eigenen Skill, kurz genug für jedes Anweisungsfeld |
| euren eigenen Prompt besser machen | eine Rückmeldung mit ✓ ~ ✗ und eine verbesserte Fassung |
| einen Skill aus dem Netz in eurem Chat nutzen | eine Fassung ohne Skripte und Befehle |

Habt ihr erst ein Thema und noch keine Frage, schlägt er euch drei mögliche Zugänge vor.

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `SKILL.md` | rund 2.700 Wörter, 17.000 Zeichen | Langfassung: in einen Chat einfügen, in ein Projekt legen oder als Skill hochladen |
| `Prompthelfer_kurz.md` | rund 5.200 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit (GPT, Le-Chat-Agent) oder Chats, in die die Langfassung nicht passt |
| `prompthelfer.zip` (Datei Skills_zum_Hochladen/prompthelfer.zip) im Ordner `zum-hochladen` | – | Paket zum Hochladen in Claude und Gemini |
| `Vorlage_Skill.md` | rund 2.000 Zeichen | leeres Gerüst, um einen Skill ohne KI selbst zu schreiben |

### Voraussetzung

Ein KI-Chat, egal welcher. Der Prompthelfer braucht **keine Websuche**, weil er nur Prompts schreibt und nicht recherchiert. Er läuft also auch in Tools ohne Konto (siehe Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“)). Wie ihr ihn einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Den fertigen Prompt setzt ihr in einem **neuen** Chat ein. Geht es um Fakten, in einem mit Websuche.

### So fragt ihr

Nach dem Einfügen fragt er: „Was ist dein Thema, und was soll die KI für dich tun?“ Dann zum Beispiel:

- „Mein Thema: Dirigentinnen in Deutschland. Ich will einen Überblick für ein Referat.“
- „schnell: Ich brauche Interviewfragen für ein Gespräch mit einer Bühnenbildnerin.“
- „Verbessere meinen Prompt:“ und darunter euren Prompt
- „Ich will mit Deep Research herausfinden, wie sich die Förderung freier Theater in Bayern seit 2020 entwickelt hat.“
- „Ich schreibe jede Woche eine Konzertankündigung. Bau mir einen Skill dafür.“
- „Bau diesen Skill so um, dass er in Gemini läuft:“ und darunter den Text der Datei

Mit „schnell“ bekommt ihr sofort einen Entwurf. Ohne fragt er erst kurz nach, höchstens drei Fragen auf einmal.

### Das Ergebnis lesen

- **Der Prompt steht im Kasten.** Oben rechts am Kasten ist meist ein Kopier-Symbol.
- **[Eckige Klammern]** sind Platzhalter. Ersetzt sie, bevor ihr den Prompt abschickt.
- **„Warum so“** erklärt in zwei, drei Punkten, welcher Baustein was bewirkt. Das ist der Teil, aus dem ihr lernt, wie ihr es beim nächsten Mal selbst macht.
- **Passt die Antwort nicht,** bringt sie zurück: „Die Antwort war zu lang“ oder „Da sind keine Quellen drin“. Er sagt, welcher Baustein gefehlt hat, und schärft den Prompt nach.

### Grenzen

- **Ein guter Prompt macht gute Antworten wahrscheinlicher, nicht sicher.** Öffnet die Quellen selbst, bevor ihr etwas übernehmt. Wie, steht in KI-Antworten prüfen (siehe Abschnitt „KI-Antworten prüfen“).
- **Keine persönlichen Daten** in Prompts, nur öffentliches Material (Spielregeln 2 und 3).
- **Der Prompthelfer ist selbst eine KI.** Was er über Funktionen einzelner Tools sagt, kann veraltet sein.

### Herkunft

Neu für dieses Seminar, nicht aus der Redaktion. Der Prompthelfer baut auf den Checklisten aus Kapitel 4 auf: Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“) und ROMANE.

---

<!-- Datei im Repo: skills/prompthelfer/Vorlage_Skill.md -->

## Vorlage: einen Skill selbst schreiben

Ein leeres Gerüst für einen eigenen Skill, zum Ausfüllen von Hand, ohne KI und ohne Konto. Es hat denselben Aufbau, den auch der Prompthelfer (Datei Skills_zum_Kopieren/Prompthelfer.txt) im Modus „Skill bauen“ nutzt. Stand: 05.11.2026.

### So geht's

1. Den Kasten unten kopieren.
2. Alles in [eckigen Klammern] ersetzen. Abschnitte, die ihr nicht braucht, streichen.
3. Unter rund 7.500 Zeichen bleiben, dann passt der Skill in jedes Anweisungsfeld.
4. Einsetzen wie die anderen Skills, siehe Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).
5. Ausprobieren, Antwort ansehen, nachschärfen. Das ist das E in ROMANE.

```
# [Name]: [was er tut, in einem Halbsatz]

Du [Rolle und Aufgabe in ein, zwei Sätzen]. Für [wen]. Sprache: [Sprache].

## Auftrag und wann er erfüllt ist
[Woran man ein fertiges Ergebnis erkennt.]

## Bevor du anfängst
[Nur wenn nötig, etwa: Prüfe, ob du im Web suchen kannst. Wenn nicht, sag das im ersten Satz. Kennst du das heutige Datum nicht sicher, frag danach.]

## Feste Regeln
1. [...]
2. [...]

## Vorgehen
1. [...]
2. [...]

## Ausgabe
[Format, bei jedem Lauf gleich, mit einem kurzen Beispiel.]

## Wenn etwas fehlt
[Was er tut, wenn Angaben fehlen oder etwas nicht zu finden ist: nachfragen, kennzeichnen, nichts erfinden.]

## Nach der Antwort
[Zwei, drei Angebote für den nächsten Schritt.]
```

### Zeilen, die oft passen

Sucht der Skill im Netz, gehören diese Regeln hinein:

```
Belege jede Zahl und jedes Zitat mit Link und dem wörtlichen Satz aus der Quelle. Schreib dazu, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst. Markiere, was du nicht belegen kannst.
Links nur aus Suchergebnissen, geöffneten Seiten oder meinem Material, nie aus dem Gedächtnis.
Primärquellen vor Presseberichten. Wikipedia und KI-Zusammenfassungen sind keine Belege.
```

Arbeitet er mit eurem Material:

```
Arbeite nur mit den Dateien und Texten, die ich dir gebe. Sag, wenn etwas darin nicht steht.
```

Weitere Bausteine stehen in Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“).

---

<!-- Datei im Repo: skills/zum-hochladen/README.md -->

## Pakete zum Hochladen

Hier liegt jeder Skill als ZIP-Datei, also als gepackter Ordner. In dieser Form nehmen Claude und Gemini Skills an. In jedem Paket liegt nur die `SKILL.md` aus dem Ordner des Skills. Ihr könnt sie vorher dort lesen.

| Paket | Skill |
|---|---|
| faktencheck.zip (Datei Skills_zum_Hochladen/faktencheck.zip) | Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) |
| herkunftscheck.zip (Datei Skills_zum_Hochladen/herkunftscheck.zip) | Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“) |
| themenrecherche.zip (Datei Skills_zum_Hochladen/themenrecherche.zip) | Themenrecherche (siehe Abschnitt „Themenrecherche zum Mitnehmen“) |
| expertenmeinungen.zip (Datei Skills_zum_Hochladen/expertenmeinungen.zip) | Expertenmeinungen (siehe Abschnitt „Expertenmeinungen zum Mitnehmen“) |
| pdb-helfer.zip (Datei Skills_zum_Hochladen/pdb-helfer.zip) | PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“) |
| prompthelfer.zip (Datei Skills_zum_Hochladen/prompthelfer.zip) | Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) |

### So geht's

1. Paket anklicken, dann oben rechts auf den Pfeil nach unten („Download raw file“).
2. **Claude:** nicht entpacken, die ZIP-Datei so hochladen. **Gemini:** erst entpacken, dann den Ordner hochladen.

Schritt für Schritt steht es in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

---

<!-- Datei im Repo: agent/moby/README.md -->

## Moby zum Mitnehmen

Moby ist ein Faktencheck-Assistent. Er prüft einen Text in vier Schritten (Fakten herausziehen, in Aspekte zerlegen, prüfen, Bericht) und liefert einen Bericht mit Status, Quellen und Korrekturvorschlägen. Das ist dieselbe Methode wie im Seminar, Kapitel 5.

Moby ist kein Skill, sondern ein Assistent mit eigenem Raum. Ihr richtet ihn einmal als Projekt, GPT oder Le-Chat-Agent ein, und dort ist jede Nachricht ein Text zum Prüfen. Wollt ihr dieselbe Prüfung in einem normalen Chat, der von selbst erkennt, wann geprüft werden soll, nehmt den Skill Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“). Den Unterschied erklärt die Seite zum Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).

Stand: 03.11.2026

### Welche Datei wofür

| Datei | Länge | Wofür |
|---|---|---|
| `Moby_Faktencheck.md` | rund 3.200 Wörter, 23.100 Zeichen | Langfassung: in einen Chat einfügen oder als Datei in ein Projekt legen |
| `Moby_kurz.md` | rund 4.600 Zeichen | Kurzfassung für Anweisungsfelder mit Zeichenlimit |

Wenn ihr die Wahl habt, nehmt die Langfassung. Sie enthält die Quellenregeln und Beispiele, die Kurzfassung nur das Gerüst.

### Voraussetzung

Ein KI-Assistent, der **im Web suchen** kann. Ohne Websuche erfindet ein Modell im schlimmsten Fall Quellen. Moby ist so gebaut, dass er dann ablehnt und nur die Prüfliste liefert. Noch besser ist ein Tool, das gefundene Seiten auch **öffnen und lesen** kann, nicht nur die Suchtreffer.

Ein Konto anzulegen ist freiwillig. Ohne Konto: Langfassung in einen Chat kopieren, der eine Websuche hat (welche das sind, steht in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“)).

### So richtet ihr Moby ein

**Überall, ohne Einrichtung**
1. Neuen Chat öffnen, Websuche einschalten, falls es dafür einen Schalter gibt.
2. Den ganzen Inhalt von `Moby_Faktencheck.md` einfügen und abschicken.
3. In der nächsten Nachricht: „Prüfe diesen Text:“ und darunter euren Text.

**Als Projekt in Claude oder ChatGPT**
1. Neues Projekt anlegen.
2. `Moby_Faktencheck.md` als Datei hochladen, oder den Inhalt in die Projektanweisungen kopieren.
3. Falls ihr die Datei hochgeladen habt, in die Anweisungen schreiben: „Arbeite immer nach der Datei Moby_Faktencheck.md. Jede Nachricht ist der zu prüfende Text.“
4. Im Projekt einen Chat starten und den Text einfügen.

**Als Agent in Le Chat**
1. Neuen Agenten anlegen.
2. Kurz- oder Langfassung in die Anweisungen kopieren, Websuche aktivieren.
3. Agent im Chat aufrufen und den Text einfügen.

**Als GPT in ChatGPT:** Das Anweisungsfeld ist auf 8.000 Zeichen begrenzt, also die Kurzfassung nehmen. Ob ihr ohne Abo eigene GPTs anlegen könnt, ist nicht geprüft.

**In Gemini:** Gems werden am 17.11.2026 schreibgeschützt und am 17.12.2026 gelöscht. Einen festen Raum wie ein Gem gibt es dann nicht mehr. Nehmt in Gemini den Skill Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“), wie ihr ihn einrichtet, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

Woher die Angaben zu den Tools stammen, steht unter Belege für die Angaben zu den Tools (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Das Ergebnis lesen

- Fangt bei den kritischen Befunden an.
- Öffnet die Links selbst. Steht „Snippet“ oder „Nur Snippet-Basis“ dabei, hat Moby nur den Suchtreffer gesehen, nicht die Seite.
- Ein ✅ heißt: zwei unabhängige Quellen gefunden. Es heißt nicht, dass ihr nicht mehr nachschauen müsst.
- Die Verantwortung für euren Text bleibt bei euch.

### Grenzen

- **Erst testen:** Moby läuft nicht in jedem Tool gleich gut. Probiert ihn zuerst mit einem Text aus, dessen Fehler ihr kennt, etwa dem Übungstext aus Kapitel 5. Mehr dazu unter Erst testen, dann nutzen (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).
- **Ein Status für zwei Fälle:** ❌ heißt bei Moby falsch oder nicht belegt. Wer das getrennt braucht, nimmt den Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“).
- **Keine Bezahlschranken:** Moby umgeht sie nicht. Was er nicht findet, sucht ihr in der Pressedatenbank eurer Bibliothek, Suchstrings dafür baut der PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“).
- **Besser machen:** mit einer eigenen Quellenliste, eurem Material als Dateien im Projekt oder angebundenen Datenbanken. Wie, steht unter Das würde die Skills noch besser machen (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Herkunft

Diese Fassung beruht auf dem Moby, den Florian in der Redaktion nutzt, und ist so umgebaut, dass sie auf verschiedenen Plattformen läuft. Was anders ist:

- **Kein Plattformbezug.** Die Redaktionsfassung ist auf eine bestimmte KI-Plattform und deren Werkzeuge eingestellt (etwa wie viele Seiten pro Antwort geöffnet werden dürfen). Hier steht stattdessen: Wenn du Seiten öffnen kannst, öffne zuerst die Quellen der wichtigsten Fakten.
- **Quellenregeln eingebaut.** In der Redaktion hängt ein eigenes Quellenregelwerk als Datei an. Hier steht eine Kurzfassung direkt im Prompt.
- **Keine Ausschlussliste mit Namen.** Das Regelwerk der Redaktion nennt Medien, die nie als Quelle zählen. In dieser Fassung stehen nur die Muster, nach denen eine Quelle ausgeschlossen wird.
- **Neu:** ein Check zu Beginn, ob Websuche und Datum verfügbar sind, und ein Hinweis zu Grauzonen und absoluten Aussagen.

---

<!-- Datei im Repo: prompts/recherche-auftrag.md -->

## Prompten: von der Frage zum Auftrag

Aus Kapitel 4 des Seminars. Stand: 01.11.2026.

**Wichtigste Botschaft: Schreibt das, was ihr bekommen wollt.** Und übernehmt nur, was ihr in der Quelle selbst gesehen habt.

Hilfe beim Schreiben: Der Prompthelfer (siehe Abschnitt „Prompthelfer zum Mitnehmen“) geht diese Checklisten mit euch durch und schreibt den Prompt für euer eigenes Thema.

### Zwei Arten zu fragen

| Einzelne Frage | Auftrag an einen Agenten oder Prozess |
|---|---|
| **Zweck:** wofür ihr die Antwort braucht | **Ziel:** Wann ist der Auftrag erledigt? |
| **Kontext:** was ihr schon wisst, für wen | **Erst der Plan:** zeigen lassen, dann starten |
| **Quellen:** welche zählen, mit Link und Zitat | **Grenzen:** welche Quellen, nichts senden, nichts kaufen |
| **Output:** Liste, Tabelle, Länge | **Belege:** Zwischenschritte und Quellen sichtbar |
| **Nachhaken** statt neu anfangen | **Format:** bei jedem Lauf gleich |

Links steht, was eine einzelne Frage an einen Chat besser macht. Rechts steht, was ein Tool zusätzlich braucht, das selbstständig in Schleifen sucht, etwa Deep Research: Es muss wissen, wann es fertig ist, was es nicht darf und wie das Ergebnis aussieht. Den Plan vorher anzusehen spart Fehlläufe.

### Vorlage: einzelne Frage

Ersetzt die eckigen Klammern. Das Beispiel ist erfunden und nicht geprüft.

```
Zweck: Ich schreibe [eine Meldung / ein Porträt / eine Vorrecherche] über [Thema].
Kontext: Ich weiß schon [was ihr wisst]. Der Text ist für [Publikum, Medium].
Frage: [eure Frage, so konkret wie möglich]
Quellen: Nutze vor allem [Primärquellen: Stadt, Ministerium, Veranstalter, Statistik]. Belege jede Zahl und jedes Zitat mit Link und dem wörtlichen Satz aus der Quelle. Wikipedia und KI-Zusammenfassungen sind keine Belege.
Output: [eine Tabelle mit Spalten ... / fünf Stichpunkte / höchstens 200 Wörter]. Markiere, was du nicht belegen kannst.
```

Beispiel:

```
Zweck: Ich schreibe eine kurze Meldung für ein Kulturmagazin.
Kontext: Ich weiß, dass die staatlichen Museen in Bayern ihre Eintrittspreise 2026 geändert haben sollen, kenne aber keine Details.
Frage: Was hat sich bei den Eintrittspreisen geändert, ab wann, und welche Häuser betrifft es?
Quellen: Nutze die Websites der Museen und des zuständigen Ministeriums zuerst. Belege jede Zahl mit Link und wörtlichem Satz.
Output: Tabelle mit Haus, Preis vorher, Preis nachher, gültig ab, Quelle. Darunter zwei Sätze zur Einordnung. Markiere, was du nicht belegen kannst.
```

**Nachhaken statt neu anfangen:** Im selben Chat weiterfragen. „Was spricht dagegen?“, „Welche Quelle davon hast du geöffnet?“, „Zeig mir den wörtlichen Satz zu Zahl 3.“

### Vorlage: Auftrag an einen Agenten

Für Deep Research, Claude Research oder andere Tools, die selbstständig suchen.

```
Ziel: Der Auftrag ist erledigt, wenn [die Frage beantwortet ist / jede der fünf Fragen einen Beleg hat / klar ist, was sich nicht belegen lässt].
Erst der Plan: Zeig mir zuerst deinen Suchplan in Stichpunkten und warte auf mein Okay.
Grenzen: Nutze nur [öffentliche Quellen / diese Websites / Quellen ab Jahr X]. Nichts senden, nichts kaufen, keine Formulare ausfüllen, keine Konten anlegen.
Belege: Nenne zu jeder Aussage die Quelle mit Link. Schreib dazu, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst.
Format: [Gliederung, die bei jedem Lauf gleich bleibt, etwa: Kurzbefund, Tabelle der Fakten, offene Fragen, Quellenverzeichnis].
```

### Regeln einmal aufschreiben: das Projekt

Gebt ihr denselben Auftrag öfter, speichert die Regeln. In Claude heißt das Projekt, in ChatGPT ebenfalls Projekt, in Le Chat Agent. In Gemini hieß es Gem; Gems werden ab dem 17.11.2026 durch Skills ersetzt. Ein Projekt bündelt Anweisungen und Dateien. Jeder neue Chat im Projekt kennt beide.

Vorlage für die Anweisungen eines Recherche-Projekts:

```
Belege jede Zahl mit Link und wörtlichem Zitat.
Primärquellen vor Presseberichten.
Markiere, was du nicht belegen kannst.
Nutze zuerst die Dateien in diesem Projekt, dann die Websuche.
Sag, wenn eine Frage mit den Dateien nicht zu beantworten ist.
```

Testet die dritte Regel mit einer Fangfrage, deren Antwort nicht in euren Dateien steht. Gute Antwort: „Dazu steht nichts in den Dokumenten.“

Fertige, längere Anweisungen für wiederkehrende Aufgaben findet ihr unter skills/ (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“). Wie ihr sie in Chat, Projekt, als Skill oder Agent einsetzt, steht in der Anleitung (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“).

### Ein mögliches Regelwerk: ROMANE

Aus dem Seminar, als Gedächtnisstütze:

- **R**olle: in welcher Funktion, für wen
- **O**bjective: das Ziel
- **M**eta-Anweisungen: wie vorgehen, was beachten
- **A**nwendungsbeispiele: zeigen, wie das Ergebnis aussehen soll
- **N**icht zu lang
- **E**xperimentieren

„Schritt für Schritt denken“ müsst ihr Reasoning-Modellen nicht mehr sagen, sie tun es von selbst.

---

<!-- Datei im Repo: prompts/ki-antworten-pruefen.md -->

## KI-Antworten prüfen

Aus Kapitel 4 des Seminars und dem Spickzettel (Datei Spickzettel.pdf). Stand: 01.11.2026.

**Die Fußnote zeigt, wo gesucht wurde, nicht, was belegt ist.**

### Warum prüfen?

- **Tow Center, März 2025:** Acht KI-Suchen sollten zu Zitaten den Originalartikel finden. Über 60 % der Antworten waren falsch. Perplexity war am besten und lag trotzdem in 37 % daneben. Quelle: [Nieman Lab, 10.03.2025](https://www.niemanlab.org/2025/03/ai-search-engines-fail-to-produce-accurate-citations-in-over-60-of-tests/)
- **EBU und BBC, 2025:** 22 öffentlich-rechtliche Sender aus 18 Ländern prüften über 3.000 Antworten von KI-Assistenten auf Nachrichtenfragen. 45 % hatten mindestens einen erheblichen Fehler, 31 % Probleme mit den Quellen. Quelle: [journalism.co.uk, 14.11.2025](https://www.journalism.co.uk/nearly-half-of-ai-generated-answers-contain-an-error-ebu-bbc-report/)

Beide Quellen wurden für die Seminarfolien am 31.10.2026 geöffnet und hier übernommen.

### Prüfliste für KI-Antworten

1. **Quelle geöffnet?** Steht die Aussage dort wirklich, und an der Stelle, auf die die Fußnote zeigt?
2. **Primärquelle** (Dokument, Beschluss, Studie) oder nur ein Bericht über einen Bericht?
3. **Zahl:** Welcher Zeitraum, welche Einheit, gegenüber was?
4. **Wer hat entschieden, wer hat es gesagt?** Stimmen Funktion und Name heute noch?
5. **Wie alt ist die Quelle?** Gibt es eine neuere?
6. **Toter oder erfundener Link:** gilt als nicht verifiziert.
7. **Was fehlt?** Gegenfrage stellen: „Was spricht dagegen?“
8. **Zwei Tools, zwei Antworten?** Dann zählt nur die Quelle.

### Strichliste für einen KI-Bericht

So lief Übung 2 im Seminar: Öffnet drei der genannten Quellen und macht für jede Aussage einen Strich.

| belegt | falsch zugeordnet | Link tot oder Bezahlschranke |
|---|---|---|
| Die Quelle sagt genau das. | Die Quelle gibt es, aber sie sagt etwas anderes, oder es steht in einer anderen Quelle. | Ihr kommt nicht an den Text. Gilt als nicht verifiziert. |

### Wofür KI taugt und wofür nicht

| Taugt | Taugt nicht |
|---|---|
| lange Dokumente lesen und gliedern | Zahlen, Zitate und Angaben zu Personen ohne geöffnete Quelle |
| Suchstrings für Pressedatenbanken bauen | Aktuelles ohne Websuche |
| Interviews vorbereiten | |
| Gegenargumente sammeln | |

„Taugt nicht“ heißt nicht verboten, sondern: Diese Angaben nur übernehmen, wenn ihr die Quelle selbst geöffnet habt. Das gilt für alle Sprachmodelle.

### Nachfragen, die helfen

Im selben Chat, direkt nach der Antwort:

```
Welche der genannten Quellen hast du geöffnet, und welche kennst du nur als Suchtreffer?
```

```
Zeig mir für jede Zahl in deiner Antwort den wörtlichen Satz aus der Quelle und den Link.
```

```
Was spricht gegen deine Antwort? Such gezielt nach Quellen, die etwas anderes sagen.
```

```
Welche Aussagen in deiner Antwort stammen aus deinem Trainingswissen und nicht aus einer Quelle von heute?
```

Die Antworten darauf sind wieder KI-Antworten. Sie helfen euch, die Stellen zu finden, die ihr selbst prüfen müsst. Sie ersetzen das Öffnen der Quelle nicht.

Einen ganzen Text prüfen der Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“) und der Assistent Moby (siehe Abschnitt „Moby zum Mitnehmen“), eine einzelne Zahl oder ein Zitat bis zum Ursprung der Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“).

---

<!-- Datei im Repo: ki-tools/tools.md -->

## KI-Tools für die Recherche: alle mit Link

Dieselben Tools wie auf dem Spickzettel (Datei Spickzettel.pdf) (Kapitel 4 und 6), hier als Linkliste. Stand der Angaben zu Zugang und Preisen: 01.11.2026, ohne Gewähr.

**Prüfstufe:** Zugang und Preise wurden für den Spickzettel am 31.10.2026 auf den Seiten der Anbieter oder in datierten Berichten geprüft. Die Adressen sind von dort übernommen. Was davon offen ist, steht als „zu prüfen“ dabei.

° Zugang ändert sich gerade, vor Ort ausprobieren.

### Spielregeln

1. Ein Konto ist freiwillig. Jede Übung geht auch ohne.
2. Keine Namen, Telefonnummern oder anderen persönlichen Daten in Prompts.
3. Nur Dokumente hochladen, die schon öffentlich zugänglich sind.
4. Wo es geht: Verlauf aus, Training abwählen.
5. Jeder Link wird geöffnet. Was nicht geöffnet wurde, gilt als nicht verifiziert.
6. KI-Text, den ihr übernehmt, kennzeichnet ihr.

### Welches Tool wofür

| Aufgabe | ohne Konto | mit Konto |
|---|---|---|
| schnell nachschlagen, mit Quellen | Perplexity, KI-Modus der Google-Suche°, Ask Brave | – |
| Überblick über ein Thema | – | Gemini Deep Research, Claude Research (Pro) |
| eigene Dokumente befragen | – | Gemini Notebook, Claude-Projekt |
| große Dokumentenstapel durchsuchen | öffentliche Pinpoint-Sammlungen° | Pinpoint |
| Interviews transkribieren | noScribe (läuft lokal), Whisper im Browser° | TurboScribe, Pinpoint |
| Studien finden | – | Scholar Labs, Consensus |
| fremdsprachige Quellen lesen | DeepL (mit Limit) | DeepL mit mehr Umfang |
| Gegenargumente, Interviewfragen | Duck.ai, Lumo | Claude, Le Chat, Euria |
| veröffentlichte Faktenchecks finden | Fact Check Explorer° | – |
| vertrauliches Material | noScribe, sonst nichts hochladen | – |

### Vier Fragen an jedes KI-Tool

Das Pult aus Kapitel 4: Mit diesen vier Fragen ordnet ihr jedes Tool ein, auch neue.

1. **Modell und Denkzeit:** Wie stark ist das Modell, wie lange denkt es nach?
2. **Zugriff:** Welche Quellen sind offen? Gedächtnis, offenes Web, eure Dateien, eure Dienste.
3. **Auftrag:** Wie strukturiert ist euer Input? Frage, Prompt oder Skill.
4. **Selbstständigkeit:** Wer bestimmt den nächsten Schritt, und verändert die KI etwas? Wenn sie handelt, nur mit eurer Freigabe.

### Eigene Daten: hochladen oder verbinden

Aus Kapitel 4 der Seminarfolien, Prüfstufe **übernommen**.

- **Hochladen:** Eine Kopie geht an den Anbieter, etwa eine PDF im Chat, im Projekt oder im Gemini Notebook. Das Modell liest nur, was ihr hineingebt.
- **Verbinden:** Integrationen geben dem Modell Zugriff auf einen Dienst wie Google Drive, Mail, Kalender oder GitHub. Bei Claude heißen sie Konnektoren, bei ChatGPT Apps. Das geht schon im normalen Chat und braucht immer ein Konto. Vorsicht vor versteckten Anweisungen in Mails.
- **Für beides gilt:** Nur hochladen und verbinden, was auch öffentlich sein dürfte.

**MCP, der Stecker für KI:** ein offener Standard, mit dem KI-Anwendungen Daten, Werkzeuge und Abläufe anderer Systeme anschließen. Ein Dienst baut einmal einen MCP-Server, dann passt er in Claude, ChatGPT, Gemini, Copilot und andere. Im November 2024 von Anthropic vorgestellt, seit Dezember 2025 bei der Linux Foundation. Ein Beispiel: Mit einem MCP-Server für das Guardian-Archiv durchsucht ein KI-Modell 1,9 Millionen Artikel, ein Prototyp, nicht vom Guardian selbst ([Nieman Lab, 01.07.2025](https://www.niemanlab.org/2025/07/a-new-tool-lets-your-favorite-ai-model-talk-with-1-9-million-articles-in-the-guardian/)). **Vorsicht:** Ein MCP-Server ist fremder Code mit Zugang zu euren Daten, und in seinen Beschreibungen lassen sich Anweisungen verstecken. Wie gefälschte Server auftauchen, steht in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

**Website-Chatbots** bei Onlineshops, Banken oder Behörden suchen oft wie ein Notebook in einem festen Bestand: FAQ, Hilfeseiten, Merkblätter. Den Bestand wählt aber der Betreiber aus, nicht ihr. Ihr seht die Quellen meist nicht, und der Bot vertritt die Interessen des Betreibers.

### Alle Tools

#### Suchen mit KI-Antwort

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| KI-Modus (Google) | Antwort mit Fußnoten in der Google-Suche | ohne Konto°; ob ein Login nötig ist, zu prüfen | [google.com](https://www.google.com/), Reiter „KI-Modus“ |
| Perplexity | Suchmaschine, die mit nummerierten Quellen antwortet | Basissuche ohne Konto | [perplexity.ai](https://www.perplexity.ai/) |
| Ask Brave | KI-Antworten aus Braves eigenem Suchindex | kostenlos | [search.brave.com](https://search.brave.com/) |
| Ecosia | KI-Übersicht über den Treffern und KI-Chat | ohne Konto | [ecosia.org](https://www.ecosia.org/) |

#### Chat-Assistenten

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Duck.ai | mehrere Sprachmodelle im Vergleich, Verlauf nur im Browser | ohne Konto; ob mit Websuche, zu prüfen | [duck.ai](https://duck.ai/) |
| Lumo (Proton) | Chat mit Websuche, wirbt mit Datenschutz | ohne Konto | [lumo.proton.me](https://lumo.proton.me/) |
| Le Chat (Mistral) | französischer Anbieter, Daten in der EU, auch Deep Research | Konto für mehr Funktionen° | [chat.mistral.ai](https://chat.mistral.ai/) |
| Euria (Infomaniak) | Assistent aus der Schweiz, laut Anbieter kein Training mit euren Daten | kostenloses Konto | [infomaniak.com/de/euria](https://www.infomaniak.com/de/euria) |
| Claude | lange Dokumente, Projekte mit festen Regeln | Konto mit E-Mail; Pro 17–20 $ im Monat | [claude.ai](https://claude.ai/) |
| ChatGPT | Multitool mit Websuche | Konto; gratis mit Werbung | [chatgpt.com](https://chatgpt.com/) |
| Copilot | in Bing, Edge, Windows und Office eingebaut | nur mit Login | [copilot.microsoft.com](https://copilot.microsoft.com/) |

#### Recherche im Auftrag

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Gemini Deep Research | plant, sucht in Schleifen, schreibt einen Bericht mit Quellen | Google-Konto ab 18, mit Limit | [gemini.google.com](https://gemini.google.com/) |
| Claude Research | viele Suchen, ein Bericht mit Quellen | nur Pro | [claude.ai](https://claude.ai/), über „+“ |

#### Eigene Dokumente befragen

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Gemini Notebook (früher NotebookLM) | Gespräch mit wenigen Quellen, zeigt die Belegstelle | Google-Konto, 50 Quellen je Notebook | [notebooklm.google.com](https://notebooklm.google.com/) |
| Pinpoint | Archiv mit Suchmaschine für große Stapel, Index von Personen und Orten, transkribiert Audio | öffentliche Sammlungen ohne Konto°; eigene mit Google-Konto ab 18 | [journaliststudio.google.com/pinpoint](https://journaliststudio.google.com/pinpoint) |
| Claude-Projekt | Anweisungen und Dateien, die jeder Chat im Projekt kennt | Konto, 5 Projekte gratis | [claude.ai](https://claude.ai/) |

#### Transkription

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| noScribe | transkribiert auf dem eigenen Rechner, offline, Open Source | kostenlos, installieren | [github.com/kaixxx/noScribe](https://github.com/kaixxx/noScribe) |
| Whisper im Browser | transkribiert im Browser, Datei oder Mikrofon; eine Demo der webml-community auf Hugging Face. Ob lokal, ist ungeprüft: Vertrauliches nur mit noScribe | ohne Konto° | [huggingface.co/spaces/webml-community/whisper-large-v3-turbo-webgpu](https://huggingface.co/spaces/webml-community/whisper-large-v3-turbo-webgpu) |
| TurboScribe | Transkription im Browser, Freemium | Konto, kostenlos mit Limit | [turboscribe.ai](https://turboscribe.ai/) |

**Whisper im Browser:** Die Seite (geöffnet am 01.11.2026) sagt, die Spracherkennung laufe „directly in your browser“. Ob die Aufnahme dabei sicher auf eurem Rechner bleibt, steht dort nicht ausdrücklich: zu prüfen. Der Name verweist auf WebGPU, also braucht ihr vermutlich einen aktuellen Browser mit WebGPU-Unterstützung. Für vertrauliches Material bleibt noScribe die sichere Wahl.

**Achtung bei noScribe:** Die Seite noscribe.ai gehört nicht zum Projekt. Laut README des Projekts (geöffnet am 01.11.2026) ist die neue offizielle Website noscribe.de, die Downloads verlinkt die README. Ladet das Programm nur über diese Wege.

#### Studien und Übersetzen

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Scholar Labs | KI-Suche in Google Scholar, sagt, warum ein Aufsatz passt | Google-Konto, experimentell | [scholar.google.com](https://scholar.google.com/) |
| Consensus | fasst den Forschungsstand aus über 220 Mio. Fachartikeln zusammen | Konto, 10 Analysen im Monat | [consensus.app](https://consensus.app/) |
| DeepL | Übersetzer für fremdsprachige Quellen | ohne Konto mit Limit | [deepl.com](https://www.deepl.com/) |

#### Faktenchecks finden

| Tool | Was es kann | Zugang | Adresse |
|---|---|---|---|
| Fact Check Explorer (Google) | durchsucht veröffentlichte Faktenchecks vieler Redaktionen | Suche ohne Konto°, geöffnet am 01.11.2026 | [toolbox.google.com/factcheck/explorer](https://toolbox.google.com/factcheck/explorer) |

#### Vorsicht

| Tool | Was es kann | Zugang | Hinweis |
|---|---|---|---|
| DeepSeek | starke Modelle aus China; die Berliner Datenschutzbeauftragte hält die App für rechtswidrig | nur unkritische Fragen | chat.deepseek.com |
| KI-Browser (Comet, ChatGPT Atlas) | ein Agent klickt für euch; versteckte Anweisungen auf Webseiten können ihn fremdsteuern | nicht mit euren Konten | nur ansehen |

Auch eine Download-Adresse ist eine Quelle: Programme nur von der Seite des Projekts laden. Wie ihr neue Tools findet und prüft, steht in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

---

<!-- Datei im Repo: ki-tools/neue-tools-finden.md -->

## Neue KI-Tools finden und prüfen

Fast jede Woche kommt ein neues KI-Werkzeug dazu. Viele nützliche Recherche-Tools sind Open-Source-Projekte auf GitHub, etwa noScribe, OpenRefine oder Aleph, oder kleine Demos auf Hugging Face. Dort zu stöbern geht fast überall ohne Konto und ohne Programmieren. Ausprobieren oder installieren solltet ihr ein Tool aber erst nach der Prüfliste (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

Gehört zu Kapitel 6.2 des Seminars. Stand: 01.11.2026. Alle Links sind **geöffnet am 01.11.2026**, sofern nicht anders vermerkt. Zahlen wie Sterne und Repos sind Momentaufnahmen von diesem Tag.

### Wo neue KI-Tools auftauchen: fünf Wege

Vom einfachsten zum technischsten.

| Weg | Was ihr dort findet | Ohne Konto? | Einstieg |
|---|---|---|---|
| **1. Werkzeugkästen von Rechercheprofis** | Tools mit Einordnung: Kosten, Anforderungen, Grenzen, Ethik. Gepflegt von Menschen, die die Tools selbst nutzen | ja | [Bellingcat Online Investigations Toolkit](https://bellingcat.gitbook.io/toolkit): 12 Kategorien, jedes Tool als kostenlos, teilweise kostenlos oder bezahlt markiert. [awesome-osint](https://github.com/jivoi/awesome-osint) mit dem Abschnitt „Fact Checking“ |
| **2. GitHub stöbern** | **Trending:** was gerade Aufmerksamkeit bekommt, filterbar nach gesprochener Sprache, Programmiersprache und Zeitraum. **Topics:** Schlagwort-Seiten, sortierbar nach „Recently updated“ | ja | [Trending](https://github.com/trending); Topics [fact-checking](https://github.com/topics/fact-checking) (1.026 Repos), [journalism](https://github.com/topics/journalism) (968), [osint](https://github.com/topics/osint) |
| **3. awesome-Listen** | von Menschen gepflegte Linklisten zu einem Thema | ja | [sindresorhus/awesome](https://github.com/sindresorhus/awesome), die Liste aller Listen (rund 528.000 Sterne); durchsuchbar über [awesome.ecosyste.ms](https://awesome.ecosyste.ms/) |
| **4. Hugging Face Spaces** | KI-Demos direkt im Browser, nach Kategorien wie OCR, Document Analysis, Text Summarization, Speech Synthesis | ja, mit Limit: ohne Konto 2 Minuten Rechenzeit (GPU) am Tag, mit Gratis-Konto 5 Minuten | [Spaces](https://huggingface.co/spaces); [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space) mit einem AI Toolkit für Redaktionen |
| **5. Verzeichnisse für Skills und MCP-Server** (Ausblick) | Bausteine, die KI-Assistenten neue Fähigkeiten geben, etwa Zugriff auf Datenbanken | lesen ja, nutzen meist nur mit Entwickler-Werkzeugen | [skills.sh](https://skills.sh) (von Vercel); [offizielle MCP-Registry](https://registry.modelcontextprotocol.io) (seit 08.09.2025 in der Preview, ohne Vorabprüfung); [awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) (rund 97.000 Sterne) |

Dazu kommen Communitys, in denen Leute ihre Projekte selbst vorstellen, etwa [Show HN](https://news.ycombinator.com/show) auf Hacker News, ohne Konto lesbar.

**Merksatz: Trending heißt beliebt, nicht seriös.** Bei Hugging Face standen am 01.11.2026 unter den zehn meistbeachteten Spaces Bildgeneratoren mit dem Zusatz „uncensored“ und ein Face-Swap-Tool. Sucht lieber über Kategorien und Schlagworte.

**Was ohne Konto nicht geht:** die Code-Suche auf GitHub, etwa nach `path:SKILL.md faktencheck`. Dafür braucht ihr ein kostenloses GitHub-Konto ([GitHub Docs](https://docs.github.com/en/search-github/searching-on-github/searching-code)). Für den Anfang reichen Topics und Listen.

**Zu Weg 5:** Viele Skills, etwa die Sammlung [jamditis/claude-skills-journalism](https://github.com/jamditis/claude-skills-journalism) (MIT-Lizenz), sind für Entwickler-Umgebungen gebaut. In einem normalen Chat nutzt ihr davon nur den Text der Anweisungen: kopieren, Zeilen mit Skripten oder Befehlen streichen. So sind auch die Skills in diesem Repo (siehe Abschnitt „Skills und Moby: Überblick und Anleitung“) gebaut.

### Bevor ihr etwas ausprobiert: die Prüfliste

Acht Fragen. Die ersten drei entscheiden.

1. **Wer steckt dahinter?** Eine Person oder Organisation mit Namen, ein echtes Profil, ein Impressum. Vorsicht bei Namen, die sich von einem bekannten Projekt nur in einem Zeichen unterscheiden.
2. **Läuft es im Browser, oder muss ich etwas installieren?** Was im Browser läuft, ist das kleinere Risiko. Ladet nie eine ZIP- oder EXE-Datei über einen „Download“-Knopf in einer README, sondern nur über die offizielle Releases-Seite oder Website des Projekts.
3. **Wohin gehen meine Daten?** Upload, Training, Serverstandort. Nur hochladen, was schon öffentlich ist (Spielregel 3).
4. **Konto, Kosten, Limits?** Mit Datum notieren. Freemium-Angebote ändern sich schnell.
5. **Lebt das Projekt?** Letztes Update, Releases, offene Issues mit Antworten.
6. **Gibt es eine offene Lizenz?** Bei Open Source steht sie im Repo.
7. **Sterne, Downloads, Trending:** nur schwache Signale. Sie lassen sich fälschen.
8. **Erst mit Bekanntem testen:** mit Material, dessen Ergebnis ihr kennt, zum Beispiel einer Übung aus dem Seminar. Erst dann mit eigenem Material.

#### Warum die Fragen 1, 2 und 7 zählen: der Fall FakeGit

- Die Kampagne „FakeGit“ hat laut [BleepingComputer vom 08.10.2026](https://bleepingcomputer.com/news/security/fakegit-malware-campaign-returns-with-17-610-malicious-github-repos) 17.610 gefälschte GitHub-Repos angelegt. Sie haben überzeugende READMEs mit einem Download-Knopf. Dahinter steckt eine ZIP-Datei mit Schadsoftware, die Zugangsdaten stiehlt.
- Schon im Juli hatte [Island (20.07.2026)](https://www.island.io/blog/agentbaiting-how-800-fake-ai-skills-and-mcp-servers-delivered-malware) rund 7.600 Repos derselben Kampagne gezählt. Über 800 davon gaben sich als KI-Skills oder MCP-Server aus und standen auch in öffentlichen Verzeichnissen, darunter eine nachgemachte awesome-Liste mit Claude-Skills. In Tests von Island haben KI-Assistenten diese Repos selbst gefunden und weiterempfohlen.

Daraus folgt: Ein Eintrag in einem Verzeichnis ist kein Gütesiegel, und auch eine KI als Tool-Scout braucht die Prüfliste. Dasselbe Muster kennt ihr von noScribe: Das echte Projekt liegt auf GitHub, daneben gab es eine Fake-Domain (L-IZ, 28.01.2026, übernommen, hier nicht erneut geöffnet). Mehr dazu in der Tool-Liste (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“).

### Tool-Scout: ein Prompt, der für euch sucht

Kopiert den Block in einen KI-Chat mit Websuche und ersetzt die Zeile „Meine Aufgabe“. Der Prompt sucht bis zu drei Kandidaten und bewertet sie nach der Prüfliste. Ihr entscheidet danach selbst und öffnet jede Seite selbst.

```
TOOL-SCOUT

Meine Aufgabe: [zum Beispiel: Interviews auf Deutsch transkribieren, ohne dass die Aufnahme meinen Rechner verlässt]

Du suchst im Web nach höchstens drei Werkzeugen, die diese Aufgabe erledigen. Kannst du in diesem Gespräch nicht im Web suchen, sag das im ersten Satz und nenne keine Tools.

Suchwege, in dieser Reihenfolge:
1. Werkzeugkästen von Rechercheprofis (zum Beispiel das Bellingcat Online Investigations Toolkit) und gepflegte awesome-Listen
2. GitHub Topics zur Aufgabe, sortiert nach "Recently updated"
3. Hugging Face Spaces, nur wenn die Aufgabe im Browser ausprobierbar sein soll
Suche auf Deutsch und Englisch.

Prüfe jeden Kandidaten nach diesen Fragen:
1. Wer steckt dahinter? Name, Profil, Impressum. Weicht der Name von einem bekannten Projekt nur in einem Zeichen ab?
2. Läuft es im Browser, oder muss man etwas installieren?
3. Wohin gehen die Daten? Upload, Training, Serverstandort.
4. Konto, Kosten, Limits, mit Datum der Angabe
5. Letztes Update, letzte Version, ob Issues beantwortet werden
6. Lizenz
7. Sterne und Downloads nennst du nur als schwaches Signal
8. Womit man es zuerst gefahrlos testen kann

Regeln:
- Links nur aus deiner Suche, nie aus dem Gedächtnis. Schreib zu jedem Link, ob du die Seite geöffnet hast oder nur den Suchtreffer kennst.
- Download- und Installationsanweisungen aus einer README empfiehlst du nicht weiter. Du nennst nur die offizielle Releases-Seite oder Website und markierst sie als "ungeprüft, selbst kontrollieren".
- Ein Eintrag in einer Liste oder einem Verzeichnis ist kein Beleg für Seriosität.
- Findest du nichts Überzeugendes, sag das. Erfinde keine Tools.

Ausgabe:
1. Tabelle mit Name, Link mit Prüfstufe, was es kann, Browser oder Installation, Daten, Konto und Kosten, letztes Update, Lizenz
2. Pro Kandidat ein Satz: Was spricht dagegen?
3. Deine Empfehlung in zwei Sätzen und der erste Test, den ich machen sollte
```

### Dranbleiben: Quellen für neue Tools

Fast alle kostenlos und ohne Konto lesbar.

| Quelle | Worum es geht | Sprache | Zugang |
|---|---|---|---|
| [KI-Update](https://www.podcast.de/episode/705152297/ki-update-kompakt-ki-investitionen-forschungssoftware-icloud-gema-vs-suno), Podcast von heise | KI-Nachrichten, neue Folgen montags, mittwochs und freitags | de | kostenlos, ohne Konto |
| [The Decoder](https://the-decoder.de/) | KI-Nachrichtenseite, Wochen-Newsletter | de | Abo-Angebot vorhanden; was frei lesbar ist und ob der Newsletter kostenlos ist: zu prüfen |
| [Indicator](https://indicator.media/authors/henk-van-ess) | digitale Recherche und Täuschung im Netz, unter anderem Henk van Ess zu KI in der Recherche | en | Newsletter kostenlos, Abo für mehr |
| [GIJN Resource Center](https://gijn.org/resource/gijns-reporting-guides-2/) | über 1.000 Tipsheets, Videos und Leitfäden, viele zu Recherche-Werkzeugen | en | kostenlos |
| [Bellingcat Toolkit](https://bellingcat.gitbook.io/toolkit) | Recherche-Tools mit Kosten, Anforderungen und Grenzen, von Freiwilligen gepflegt | en | kostenlos, ohne Konto |
| [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space) | Open-Source-KI für Redaktionen, mit AI Toolkit | en | lesen ohne Konto, Community mit Konto |
| [Simon Willison’s Weblog](https://simonwillison.net/about) | baut Datasette für Datenjournalismus und schreibt fast täglich über neue KI-Werkzeuge | en | kostenlos, Newsletter etwa wöchentlich, [Feed](https://simonwillison.net/atom/everything/) ohne Konto |
| [GitHub Topics](https://github.com/topics/journalism) und [Show HN](https://news.ycombinator.com/show) | neue Projekte, nach „Recently updated“ sortiert | en | ohne Konto |

**Tipp:** einmal im Monat 20 Minuten. Eine Topic-Seite durchklicken, das Bellingcat Toolkit ansehen, einen Newsletter lesen. Feeds wie der von Simon Willison lassen sich ohne Konto in einem Feed-Reader abonnieren.

### Quellen

Geöffnet am 01.11.2026, sofern nicht anders vermerkt.

- [GitHub Trending](https://github.com/trending): ohne Konto lesbar, Filter Spoken Language, Language, Date range
- [GitHub Topic fact-checking](https://github.com/topics/fact-checking): 1.026 Repos; [Topic journalism](https://github.com/topics/journalism): 968 Repos
- [GitHub Docs, Searching code](https://docs.github.com/en/search-github/searching-on-github/searching-code): Code-Suche nur angemeldet
- [sindresorhus/awesome](https://github.com/sindresorhus/awesome): rund 528.000 Sterne; [awesome.ecosyste.ms](https://awesome.ecosyste.ms/)
- [jivoi/awesome-osint](https://github.com/jivoi/awesome-osint): Abschnitt „Fact Checking“, rund 29.000 Sterne
- [Bellingcat Online Investigations Toolkit](https://bellingcat.gitbook.io/toolkit) und [Vorstellung bei Bellingcat, 24.09.2024](https://bellingcat.com/resources/2024/09/24/bellingcat-online-investigations-toolkit)
- [Hugging Face Spaces](https://huggingface.co/spaces) und [Hugging Face Docs, ZeroGPU](https://huggingface.co/docs/hub/spaces-zerogpu): Tageskontingent ohne Konto 2 Minuten, Gratis-Konto 5 Minuten
- [Journalists on Hugging Face](https://journalistsonhf-readme.static.hf.space)
- [skills.sh](https://skills.sh): Verzeichnis von Vercel
- [MCP-Blog, 08.09.2025](https://blog.modelcontextprotocol.io/posts/2025-09-08-mcp-registry-preview/): offizielle Registry in der Preview, keine Vorabprüfung, Meldungen durch die Community
- [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers): rund 97.000 Sterne
- [jamditis/claude-skills-journalism](https://github.com/jamditis/claude-skills-journalism): MIT-Lizenz, Einrichtung vor allem über Entwickler-Werkzeuge
- [Show HN](https://news.ycombinator.com/show): ohne Konto lesbar
- [BleepingComputer, 08.10.2026](https://bleepingcomputer.com/news/security/fakegit-malware-campaign-returns-with-17-610-malicious-github-repos): FakeGit mit 17.610 Repos, Download-Knopf führt zu einer ZIP-Datei mit Schadsoftware
- [Island, 20.07.2026](https://www.island.io/blog/agentbaiting-how-800-fake-ai-skills-and-mcp-servers-delivered-malware): rund 7.600 Repos der Kampagne, über 800 als Skills oder MCP-Server getarnt, KI-Assistenten empfehlen sie in Tests
- [KI-Update bei podcast.de](https://www.podcast.de/episode/705152297/ki-update-kompakt-ki-investitionen-forschungssoftware-icloud-gema-vs-suno): Folge vom 03.08.2026, Erscheinungstage Mo, Mi, Fr
- [The Decoder](https://the-decoder.de/): Startseite, Meldungen vom 31.10.2026
- [Indicator, Autorenseite Henk van Ess](https://indicator.media/authors/henk-van-ess): Artikel vom 14.09.2026
- [GIJN Reporting Guides](https://gijn.org/resource/gijns-reporting-guides-2/)
- [Simon Willison, About](https://simonwillison.net/about) und [Atom-Feed](https://simonwillison.net/atom/everything/)
- noScribe und die Fake-Domain: L-IZ, 28.01.2026, übernommen, hier nicht erneut geöffnet; README des Projekts auf [GitHub](https://github.com/kaixxx/noScribe), geöffnet am 01.11.2026

---

<!-- Datei im Repo: suche/dokumentieren.md -->

## Ergebnisse dokumentieren

Aus Kapitel 1 der Seminarfolien. Stand: 01.11.2026.

**Prüfstufe aller Links: übernommen.** Sie stehen so auf den Folien und wurden für dieses Repo nicht erneut geöffnet.

### Warum dokumentieren?

Gute journalistische Arbeit heißt: Ergebnisse sammeln, ordnen und aufbewahren. Dann könnt ihr eure Quellen später belegen und habt die Ergebnisse schnell zur Hand.

Die Adresse einer Seite aufzuheben reicht leider nicht. Wer die Seite betreibt, kann sie jederzeit ändern oder löschen, und auch der Aufbau einer Website ändert sich. Speichert deshalb die Stelle selbst.

### Vier Wege, eine Seite zu sichern

| Weg | So geht es | Tipp |
|---|---|---|
| Kopieren | Textstellen kopieren und mit Adresse, Datum und Uhrzeit speichern, am besten in einem Programm für Notizen und Quellen | Browser-Erweiterung [Copy as Plain Text](https://chromewebstore.google.com/detail/copy-as-plain-text/eneajgkmdhmjmloiabgkpkiooaejmlpk); in [OneNote](https://www.onenote.com/) wird beim Einfügen die Adresse automatisch mitgespeichert |
| Als PDF speichern | im Druck-Dialog jedes Browsers „Als PDF speichern“ | Das Ergebnis hängt davon ab, wie druckfähig die Seite ist. |
| Screenshot der ganzen Seite | auch der Teil, den der Browser gerade nicht zeigt | Manche Browser können das selbst, mehr kann die Erweiterung [FireShot](https://chromewebstore.google.com/detail/nehmen-sie-vollst%C3%A4ndige-w/mcbpblocgmgfnpjjppndjkmgjaogfceg) |
| Archivieren | die Seite mit ihrer Struktur im Format WARC sichern, geeignet für die Langzeitarchivierung | Browser-Erweiterung [ArchiveWeb.page](https://archiveweb.page/guide); zum Einlesen: [nestor, Kurzartikel zu WARC (PDF)](https://files.dnb.de/nestor/kurzartikel/thema_15-WARC.pdf) |

Ist eine Seite schon weg, hilft oft das Web-Archiv, siehe Suchen im Web (siehe Abschnitt „Suchen im Web: Suchmaschinen, Google, Web-Archiv“).

### Rechercheprotokoll

Eine Zeile pro Fund. Prüfstufe wie in diesem Repo: „geöffnet“, wenn ihr die Seite selbst gelesen habt, sonst „nicht verifiziert“.

| Nr. | Was steht dort? | Quelle (Medium, Autor) | Adresse | Abrufdatum | Prüfstufe | Bemerkung |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |

**Was nicht ging** (Bezahlschranke, Seite gesperrt, nichts gefunden):

-

Zum Kopieren in ein eigenes Dokument:

```
| Nr. | Was steht dort? | Quelle (Medium, Autor) | Adresse | Abrufdatum | Prüfstufe | Bemerkung |
|---|---|---|---|---|---|---|
| 1 | | | | | | |

Was nicht ging:
-
```

---

<!-- Datei im Repo: suche/google-operatoren.md -->

## Suchen im Web: Suchmaschinen, Google, Web-Archiv

Aus Kapitel 2 der Seminarfolien, ergänzt um den Stand, welche Operatoren heute noch wirken. Stand: 01.11.2026.

Links aus den Folien haben die Prüfstufe **übernommen** (für dieses Repo nicht erneut geöffnet). Die beiden Quellen zum Operator-Stand sind **geöffnet am 01.11.2026**. Die Angaben zu Brave, Qwant und Ecosia sind auf den Seiten der Anbieter **geöffnet am 07.11.2026** und korrigiert.

### Welche Suchmaschine?

| Art | Anbieter | Was sie auszeichnet |
|---|---|---|
| eigener Index | [Google](https://www.google.de/), [Bing](https://www.bing.de/) | größter Index und höchste Marktanteile; finanziert über personalisierte Werbung, erfassen Daten der Nutzerinnen und Nutzer |
| eigener Index | [Brave Search](https://search.brave.com/) | ohne Tracking, Personalisierung einstellbar; Ergebnisse laut Brave standardmäßig ganz aus dem eigenen Index, Google-Ergebnisse nur, wenn man sie selbst einschaltet |
| eigener Index | [Kagi](https://kagi.com/welcome) | kostenpflichtig, dafür ohne Werbung und Tracking; Ranking anpassbar |
| eigener Index im Aufbau | [Qwant](https://www.qwant.com/), [Ecosia](https://www.ecosia.org/) | aus Frankreich und Deutschland, Server in der EU, ohne Personalisierung und Tracking; bauen über ihr Gemeinschaftsunternehmen EUSP einen europäischen Index auf (Staan), ergänzen ihn aber noch mit Google und Bing |
| Meta-Suchmaschine | [DuckDuckGo](https://duckduckgo.com/) | Datenschutz und kein Tracking; unklar, aus welchen Indizes die Ergebnisse stammen |
| Meta-Suchmaschine | [MetaGer](https://metager.de/) | seit September 2024 nur noch kostenpflichtig |
| Proxy-Suchmaschine | [Startpage](https://www.startpage.com/de) | Datenschutz und kein Tracking, nutzt den Index von Google |
| Proxy-Suchmaschine | [Ekoru](https://ekoru.org/), [Good Search](https://good-search.org/) | spenden einen Teil der Werbeerlöse an Umweltprojekte |

**Faustregeln:**

- Google und Bing haben derzeit den umfassendsten Index.
- Bei Proxy-Suchmaschinen wisst ihr, welchen Index sie nutzen, und könnt Personalisierung und Tracking weitgehend vermeiden.
- Erwartet ihr nur wenige Treffer, lohnt sich eine Meta-Suchmaschine.
- Oft lohnt eine zweite, kurze Suche mit einer Suchmaschine, die einen anderen Index nutzt.
- Bringt die Websuche nichts, gibt es weitere Wege, etwa die Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

### Die Standardsuche mit Google

- Google ist nicht für objektive Recherche gebaut. Es rät, was für euch relevant sein könnte, und nutzt dafür auch Daten, die nicht in eurer Anfrage stehen, etwa Standort und frühere Suchen.
- Über der Trefferliste bietet Google einen KI-Chat an, der versucht, die Frage selbst zu beantworten. Wollt ihr nur die Trefferliste, klickt auf **Mehr**, dann **Web**.
- Gebt Schlüsselbegriffe ein statt ganzer Fragen: `Bergson Eröffnung` statt „Wann wurde das Bergson eröffnet?“
- Google sucht automatisch nach Wortstämmen und toleriert Tippfehler. Wollt ihr das nicht: **Suchfilter**, **Alle Ergebnisse**, **Wortwörtlich**.
- In den Suchfiltern legt ihr auch den Zeitraum fest (Format MM/DD/YYYY).
- Für Presse und Rundfunk: Reiter **News**, dann in den Suchfiltern Zeitraum wählen und von „Nach Relevanz sortiert“ auf „Nach Datum sortiert“ umstellen.

### Die erweiterte Suche

Direkt aufrufen: [google.com/advanced_search](https://www.google.com/advanced_search), oder auf der Startseite **Einstellungen**, dann **Erweiterte Suche**.

| Feld | Was es tut | Beispiel aus den Folien |
|---|---|---|
| genau dieses Wort oder diese Wortgruppe | genau diese Wörter in dieser Reihenfolge | „Wer reitet so spät durch Nacht und Wind“ |
| keines der folgenden Wörter | diese Wörter dürfen nicht vorkommen | „Oktoberfest“, aber ohne „München“ |
| Webseite oder Domain | nur Treffer auf dieser Website | „Frank Sinatra“ nur auf zeit.de |
| Dateityp | nur Dateien in diesem Format, keine Webseiten | nur PDF |

### Operatoren: was heute noch wirkt

Google dokumentiert offiziell nur sechs Operatoren. Andere wirken trotzdem, manche gar nicht mehr. Die Spalte „Stand“ folgt einem Test von SEOmator vom 13.07.2026 (Google USA, Englisch, Desktop). Ergebnisse können je nach Land, Sprache und Zeitpunkt abweichen.

| Operator | Was er tut | Beispiel | Stand |
|---|---|---|---|
| `"…"` | genau diese Wortfolge | `"Wer reitet so spät durch Nacht und Wind"` | offiziell |
| `-wort` | Wort darf nicht vorkommen, ohne Leerzeichen | `Bach -Vivaldi` | offiziell |
| `site:` | nur diese Website | `site:zeit.de "Rolling Stones"` | offiziell |
| `filetype:` | nur dieser Dateityp | `filetype:pdf Spielzeit Programmheft` | offiziell |
| `after:` / `before:` | zuletzt aktualisiert nach oder vor einem Datum | `Documenta after:2022-06-01 before:2022-09-30` | offiziell, siehe Hinweis |
| `intitle:` / `allintitle:` | Wort oder alle Wörter im Titel der Seite | `intitle:Uraufführung Oper` | wirkt, nicht offiziell |
| `intext:` / `allintext:` | Wort oder alle Wörter im Seitentext | `intext:Intendanz Theater` | wirkt, nicht offiziell |
| `AROUND(N)` | Begriffe höchstens N Wörter voneinander entfernt | `Brecht AROUND(5) Weill` | wirkt, nicht offiziell |
| `OR` | einer der Begriffe genügt, großschreiben | `Bach OR Vivaldi` | unklar |
| `*` | Platzhalter für ein beliebiges Wort | `"Wer * so * durch * und *"` | unklar |
| `inurl:` / `allinurl:` | Wort in der Internetadresse | `inurl:pressemitteilung` | gelockert, filtert nicht mehr streng |
| `cache:`, `related:`, `info:`, `link:`, `+`, `~` | | | wirken nicht mehr |

**Hinweis zu `after:` und `before:`:** Sie filtern nach dem Datum der letzten Aktualisierung, nicht nach dem Erscheinungsdatum. Ein alter Text, der gestern geändert wurde, taucht also auch bei `after:gestern` auf. Prüft das Datum immer auf der Seite selbst.

**Hinweis zu `*`:** Bei Google ist das Sternchen ein Platzhalter für ein ganzes Wort. Wortteile abschneiden („trunkieren“, etwa `Erlk*`) geht bei Google nicht, wohl aber in den Pressedatenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

**Kein Leerzeichen** zwischen Operator und Suchbegriff: `site:zeit.de`, nicht `site: zeit.de`.

#### Kombinieren

Operatoren lassen sich verbinden. Ein paar Muster zum Abwandeln (Beispiele, nicht für jedes Thema getestet):

| Ziel | Suchstring |
|---|---|
| Interviews einer Person auf einer Sender-Website | `site:br.de intitle:Interview "Anne-Sophie Mutter"` |
| Dokumente einer Stadt zu einem Thema | `site:berlin.de filetype:pdf Atelierförderung` |
| Berichte ohne Wikipedia und Online-Lexika | `"Gärtnerplatztheater" Sanierung -site:wikipedia.org` |
| eine Person, aber nicht eine gleichnamige | `"Thomas Mann" -Heinrich` |
| Pressemitteilungen eines Hauses | `site:pinakothek.de intitle:Pressemitteilung` |

Mehr Operatoren mit Beispielen: [ahrefs, Google Advanced Search Operators](https://ahrefs.com/blog/google-advanced-search-operators/) und [eine Sammlung als Google-Dokument](https://docs.google.com/document/d/1ydVaJJeL1EYbWtlfj9TPfBTE5IBADkQfZrQaBZxqXGs) (beide übernommen aus den Folien). Ob ein Operator noch wirkt, prüft ihr am besten selbst mit einer Suche, deren Ergebnis ihr kennt.

### Suche im Web-Archiv

Was tun, wenn eine Seite verschwunden ist oder sich verändert hat?

- Das [Internet Archive (Wayback Machine)](https://web.archive.org/) speichert Webseiten in Kopien mit Datum, sofern die Betreiber das nicht verhindern oder eine Löschung beantragen.
- Den Cache von Google gibt es nicht mehr. Andere Archive gibt es, zum Beispiel bei Bing.
- Archiv-Metasuche über mehrere Archive: [echo.archivarix.net](https://echo.archivarix.net/)
- Browser-Erweiterung für den direkten Zugriff auf viele Archive: [Web Archives](https://github.com/dessant/web-archives)
- Die Deutsche Nationalbibliothek archiviert das deutschsprachige Web: [Sammlung Websites der DNB](https://www.dnb.de/DE/Professionell/Sammeln/Sammlung_Websites/sammlung_websites_node.html)

Eine archivierte Seite belegt, was zu diesem Zeitpunkt dort stand. Gebt in eurem Text das Datum der Archivkopie an.

### Wikipedia

Wikipedia hat rund drei Millionen Artikel auf Deutsch, geschrieben von Freiwilligen. Sie gilt nicht als zitierfähige Quelle, weil die Autor:innen meist anonym sind und ihre Sachkenntnis nicht belegt ist. Nutzt sie als Sprungbrett: Die Einzelnachweise unten im Artikel führen zu Originalquellen, die ihr selbst öffnet und zitiert.

### Quellen

- Folien „Recherche im Web“, Seminar Recherche und Faktencheck, Stand 31.10.2026
- [Google-Suchhilfe, Refine Google searches](https://support.google.com/websearch/answer/2466433?hl=en): dokumentiert `"…"`, `site:`, `-`, `before:`, `after:`, `filetype:`; geöffnet am 01.11.2026
- [SEOmator, Google Search Operators Cheat Sheet](https://seomator.com/de/blog/google-search-operators-cheat-sheet-tabelle): Test aller Operatoren am 13.07.2026, aktualisiert 21.07.2026; geöffnet am 01.11.2026

---

<!-- Datei im Repo: suche/datenbanken.md -->

## Datenbanken: Zugänge und Suchsyntax

Aus Kapitel 3 der Seminarfolien. Stand: 01.11.2026.

**Prüfstufe aller Links: übernommen.** Sie stehen genau so auf Florians Folien und wurden für dieses Repo nicht erneut geöffnet. Zugänge über Bibliotheken ändern sich gelegentlich. Funktioniert ein Link nicht, findet ihr die Datenbank über DBIS (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).

### Warum Datenbanken, wenn es Google gibt?

Datenbanken sind meist auf ein Thema spezialisiert. Ihre Inhalte sind ausgewählt und erschlossen, die Quellen durchlaufen zumindest eine gewisse Qualitätssicherung, und vieles davon findet keine Suchmaschine.

Manche Datenbanken sind kostenlos, manche Freemium, manche nur mit bezahltem Konto nutzbar. **Mit eurem Ausweis der Bayerischen Staatsbibliothek (Stabi) und der Münchner Stadtbibliothek kommt ihr kostenlos an viele Datenbanken, die sonst Geld kosten.** Die Links über `emedia1.bsb-muenchen.de/han/…` fragen nach dem Stabi-Login.

### Datenbanken finden: DBIS

[DBIS](https://dbis.ur.de/BSB/browse/subjects/), das Datenbank-Infosystem, ist ein Katalog von Datenbanken aus allen Fachgebieten, keineswegs nur wissenschaftlichen. Der Link führt zum Einstieg über die Stabi.

Ein Ampelsymbol zeigt den Zugang:

| Ampel | Zugang |
|---|---|
| grün | frei zugänglich |
| gelb | über den Stabi-Account |
| rot | nur kostenpflichtig oder mit besonderer Berechtigung |

### Pressedatenbanken

Die meisten Pressedatenbanken laufen intern in Verlagen und Sendern. F.A.Z. und SZ bieten auch externe Zugänge an, ebenso Genios, Munzinger, LexisNexis und Dow Jones Factiva. Über Stabi und Stadtbibliothek kommt ihr kostenlos an F.A.Z., SZ, Genios, Munzinger und LexisNexis.

#### Überblick: Zugang und Syntax

| Datenbank | Zugang | Nähe | Mindestens N-mal | Besonderheit |
|---|---|---|---|---|
| SZ | [Stabi](http://emedia1.bsb-muenchen.de/han/sz) | `NEAR.N(a,b)` · in Reihenfolge `ONEAR.N(a,b)` | `ATLEAST.N(begriff)` | Linkstrunkierung `*philharmonie`, Artikeltypen und Dossiers |
| F.A.Z. | [Stabi](http://emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/) | `"a b"~N` | `begriff#N` | bildet Wortstämme automatisch |
| Genios / WISO | [Stadtbibliothek](http://bib-muenchen.genios.de/), [Stabi](http://emedia1.bsb-muenchen.de/han/wiso/) | `"a b"~N` | `begriff#N` | Suche auf [genios.de](http://www.genios.de/) ohne Konto |
| LexisNexis (Nexis Uni) | [Stabi](http://emedia1.bsb-muenchen.de/han/nexisuni1) | `a near/N b` | `atleastN(begriff)` | internationale Presse; NOT heißt hier `AND NOT` |

In allen vier gehen `AND`, `OR`, `NOT`, `*` zum Trunkieren, `"Phrasensuche"` und `(Klammern)` zum Gruppieren.

Den Suchstring für SZ, F.A.Z. und WISO baut euch auf Wunsch der PDB-Helfer (siehe Abschnitt „PDB-Helfer zum Mitnehmen“).

#### Süddeutsche Zeitung

- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/sz](http://emedia1.bsb-muenchen.de/han/sz)
- Weitgehend alle SZ-Ausgaben und die Inhalte von sz.de.
- Großes Plus: Ihr könnt die Erschließung der SZ-Dokumentation nutzen, also die Zuordnung von Artikeln zu Dossiers, und nach Artikeltypen filtern.
- Unter „Ganzseiten“ blättert ihr durch die Ausgaben wie im E-Paper.
- Zeitraum, Ressort, Artikeltyp und mehr könnt ihr vor der Suche einschränken oder danach filtern.

Operatoren und Syntax (unter anderem):

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `NOT` | beide, einer davon, nicht |
| `Philharmonie*` | Trunkierung rechts |
| `*philharmonie` | Trunkierung links, findet auch Isarphilharmonie |
| `"Phrasensuche"` | genau diese Wortfolge |
| `( … )` | Gruppieren |
| `NEAR.N(begriff1,begriff2,…)` | Begriffe höchstens N Wörter voneinander entfernt |
| `ONEAR.N(begriff1,begriff2,…)` | wie NEAR, aber in dieser Reihenfolge |
| `ATLEAST.N(begriff)` | Begriff kommt mindestens N-mal im Text vor |

#### Frankfurter Allgemeine Zeitung

- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/](http://emedia1.bsb-muenchen.de/han/faz-bibliotheksportal/)
- Die Suche bildet aus eurer Eingabe automatisch Wortstämme und Beugungsformen. Manchmal schießt sie dabei übers Ziel hinaus.
- Alle Operatoren erklärt die [Suchhilfe des F.A.Z.-Archivs](https://fazarchiv.faz.net/suchhilfe).

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `NOT`, `*`, `"Phrase"`, `( … )` | wie oben |
| `"suchbegriff1 suchbegriff2"~N` | Begriffe höchstens N Wörter voneinander entfernt |
| `suchbegriff#N` | Begriff kommt mindestens N-mal im Text vor |

#### Genios und WISO

Genios vermarktet dieselbe Datenbank unter zwei Namen. Sie enthält Zeitungen und Zeitschriften vieler Verlage.

- Genios über die Stadtbibliothek: [bib-muenchen.genios.de](http://bib-muenchen.genios.de/)
- WISO über die Stabi: [emedia1.bsb-muenchen.de/han/wiso](http://emedia1.bsb-muenchen.de/han/wiso/)
- Auf [genios.de](http://www.genios.de/) könnt ihr ohne Konto und kostenlos suchen. Erst das Abrufen von Artikeln kostet.
- Syntax wie bei der F.A.Z.: `"a b"~N` für Nähe, `begriff#N` für mindestens N-mal. Alle Operatoren und Felder stehen in der [Genios-Hilfe](https://www.gbi-genios.de/de/hilfe/genios/operatoren-und-datenbank-felder).

#### LexisNexis (Nexis Uni)

- Sehr viele internationale Publikationen, unter anderem Guardian, New York Times, Le Figaro, El País.
- Zugang über den Stabi-Account: [emedia1.bsb-muenchen.de/han/nexisuni1](http://emedia1.bsb-muenchen.de/han/nexisuni1)
- Alle Operatoren erklärt die [Hilfe von LexisNexis](https://www.lexisnexis.com/Casemapsuitesupport/xm/xm9.0/xm_search_operators_using.htm) (englisch).

| Syntax | Bedeutung |
|---|---|
| `AND` / `OR` / `AND NOT`, `*`, `"Phrase"`, `( … )` | wie oben, NOT heißt hier `AND NOT` |
| `begriff1 near/N begriff2` | Begriffe höchstens N Wörter voneinander entfernt |
| `atleastN(begriff)` | Begriff kommt mindestens N-mal im Text vor |

#### Artikel hinter der Bezahlschranke lesen

- Viele „Plus“-Artikel stehen auch in Genios oder WISO. Gebt den Titel oder einen Halbsatz aus dem sichtbaren Teil in das Suchfeld ein. Ist der Artikel in der Datenbank, könnt ihr ihn lesen.
- Bei manchen Quellen dauert es ein paar Tage, bis Artikel in der Datenbank stehen. Manche bleiben dauerhaft exklusiv.
- Tipp: Das Browser-Plugin [BibBot](https://stefanw.github.io/bibbot/) sucht beim Aufruf eines Paywall-Artikels im Hintergrund in Genios oder WISO und blendet den Text ein, wenn es ihn findet. Dafür hinterlegt ihr eure Zugangsdaten von Stabi oder Stadtbibliothek; mit der Stadtbibliothek gibt es mehr Quellen. Nur für Text, nicht für Bilder oder Grafiken.

#### Zeitschriften und E-Paper

| Angebot | Was | Zugang |
|---|---|---|
| [PressReader](https://online.munzinger.de/publikation/pressreader) | E-Paper von Zeitschriften und einzelnen Zeitungen | Stadtbibliothek, über Munzinger |
| [Onleihe München](https://www.onleihe.de/muenchen/frontend/welcome,51-0-0-100-0-0-1-0-0-0-0.html) | E-Paper von Zeitschriften suchen und digital ausleihen | Stadtbibliothek |
| [Elektronische Zeitschriftenbibliothek (EZB)](https://ezb.ur.de/searchres.phtml?bibid=BSB) | vor allem wissenschaftliche Zeitschriften, Ampel wie in DBIS | Stabi |

### Thematische Datenbanken

#### Munzinger

Munzinger vereint unter anderem Biografien, Pop-Lexikon, Sport-Lexikon, Gedenktage und Chronik, Filmdienst-Kritiken, die Kritischen Lexika zur deutsch- und fremdsprachigen Gegenwartsliteratur und Duden Sprachwissen.

- über die Stabi: [Munzinger via DBIS](https://dbis.ur.de/warpto?ubr_id=BSB&resource_id=2109&license_type=2&license_form=22&access_type=1&access_form=15&access_id=61265)
- über die Stadtbibliothek: [online.munzinger.de](https://online.munzinger.de/)
- Die enthaltenen Module unterscheiden sich je nach Zugang etwas.

#### Feltas

[Feltas](http://www.feltas.de/) ist eine Ereignis-Datenbank: Geburts- und Todestage bekannter Persönlichkeiten, Chronik politischer, kultureller und anderer Ereignisse. Eingeschränkt auch ohne Anmeldung nutzbar. Gut für Jahrestage als Anlass.

#### MediathekViewWeb

[MediathekViewWeb](https://mediathekviewweb.de/) durchsucht an einer Stelle die Mediatheken der öffentlich-rechtlichen Sender aus Deutschland sowie ORF und SRF. Die Beiträge laufen direkt im Browser. Bei ORF und SRF nicht mehr direkt: Dort öffnet ihr die URL des M3U8-Streams im VLC-Player.

| Syntax | sucht in |
|---|---|
| `!sendername` | Sender |
| `#thema` | Thema, meist der Name der Sendung |
| `+titel` | Titel des Beitrags |
| `*begriff` | überall |

---

<!-- Datei im Repo: suche/social-media.md -->

## Social Media durchsuchen

Aus Kapitel 5 der Seminarfolien (Abschnitt Social Media). Stand: 05.11.2026.

**Prüfstufe:** Die Links stehen so auf den Folien und sind **übernommen**. Die Plattformen ändern ihre Suche und ihre Adressen oft. Was hier steht, gilt für den Stand oben. Was auf einer Plattform nicht mehr geht, prüft ihr selbst nach.

### Bevor ihr sucht

- **Sucht mit einem Recherche-Konto,** getrennt vom privaten, mit eigener E-Mail-Adresse.
- **Ihr hinterlasst Spuren.** Wer eine Instagram-Story ansieht, steht in der Zuschauerliste. TikTok zeigt Profilbesuche, wenn beide Seiten den Profilverlauf eingeschaltet haben.
- **Wer Kontakt aufnimmt, gibt sich zu erkennen.** Verdeckt recherchieren geht nur ausnahmsweise, bei besonderem öffentlichem Interesse (Pressekodex, Ziffer 4).

### Wie sucht man wo?

Drei Suchwege gehen überall:

| Suche | Findet |
|---|---|
| `@Name` | Personen und Gruppen |
| `#Hashtag` | Themen und Kampagnen |
| Stichwort | Posts und Profile |

Dazu von außen, ohne Konto: Google mit `site:`, etwa `site:tiktok.com Kammerspiele`.

Jede Plattform hat außerdem eine Besonderheit:

| Plattform | Was nur hier geht |
|---|---|
| X | echte Suchoperatoren wie `from:` und `since:` (siehe unten); suchen nur mit Login |
| Facebook | Filter „Neueste Beiträge“ und „Datum“, beim Datum aber nur nach Jahr |
| Instagram | Ortsseiten; im Profil „Info zu diesem Konto“: Beitritt, Land, wie oft der Name geändert wurde |
| Telegram | öffentliche Kanäle ohne Konto im Browser lesen und durchsuchen |
| TikTok | Filter Datum (bis drei Monate) und Sortieren nach Likes |

### X: suchen mit Operatoren

| Operator | Wirkung |
|---|---|
| `"Münchner Kammerspiele"` | genau diese Wortfolge |
| `-Kino` | Wort ausschließen |
| `OR` | eins von beiden |
| `from:konto` | nur Posts dieses Kontos |
| `to:konto`, `@konto` | Antworten an das Konto, Posts, die es erwähnen |
| `since:2026-07-16` | ab diesem Tag |
| `until:2026-07-20` | bis vor diesem Tag |
| `min_faves:20` | mindestens 20 Likes (`min_retweets:`, `min_replies:` entsprechend) |
| `filter:images` | nur Posts mit Bildern (`filter:videos`, `filter:media`, `filter:links` entsprechend) |
| `lang:de` | nur Posts auf Deutsch |
| `url:muenchen.de` | Posts mit einem Link auf diese Seite |

Alle Operatoren gibt es auch als Formular: [x.com/search-advanced](https://x.com/search-advanced). Ortssuchen wie `near:` sind unzuverlässig, weil nur wenige Posts Ortsdaten haben. Dienste, die X ohne Konto zeigten, sind seit September 2026 offline.

### Die Adresse verrät mehr

Oft kommt ihr weiter, wenn ihr eine Adresse direkt eintippt, statt die Suche der Plattform zu nehmen.

| Plattform | Adresse | Was ihr bekommt |
|---|---|---|
| Instagram | `instagram.com/NAME/tagged/` | Posts anderer, in denen das Konto markiert ist |
| Facebook | [facebook.com/ads/library](https://www.facebook.com/ads/library) | alle Anzeigen einer Seite, ohne Login |
| Facebook | Seite, dann „Seitentransparenz“ | Erstelldatum, frühere Namen, Land der Verwalter |
| X | die lange Zahl am Ende von `x.com/NAME/status/…` | in [TweetedAt](https://oduwsdl.github.io/tweetedat/) eingefügt: Datum und Uhrzeit des Posts, auch wenn er gelöscht ist |
| X | `x.com/NAME/media` | nur Bilder und Videos des Kontos |
| Telegram | `t.me/s/KANAL` | die letzten Posts eines öffentlichen Kanals, ohne Konto |
| Telegram | `t.me/s/KANAL?q=Wort` | Suche im Kanal, auch nach Hashtags und Wortteilen |
| Telegram | `t.me/KANAL/123?embed=1` | ein einzelner Post mit Datum, ohne Konto |
| TikTok | `tiktok.com/tag/HASHTAG` | alle öffentlichen Videos zum Hashtag, ohne Login |
| TikTok | `tiktok.com/@NAME` | das Profil, ohne Login |

**Google als Umweg:**

- `site:` mit Pfad: `site:instagram.com/p/ "Kammerspiele"`, `site:facebook.com/groups "Kammerspiele"`, `site:tiktok.com/@ "Kammerspiele"`, `site:t.me/s/ "Wort"`.
- Zeitraum: `after:2026-07-01 before:2026-08-01`.
- Wo ein Konto anderswo verlinkt ist, auf Websites, in der Presse, auf anderen Plattformen: `"instagram.com/NAME" -site:instagram.com`.

Mehr zu den Google-Operatoren steht in Suchen im Web (siehe Abschnitt „Suchen im Web: Suchmaschinen, Google, Web-Archiv“).

### Werkzeuge

| Werkzeug | Was es kann | Zugang |
|---|---|---|
| [InVID-WeVerify-Plugin](https://bellingcat.gitbook.io/toolkit/more/all-tools/invid) | zerlegt Videos aus Posts: Standbilder für die Rückwärtssuche, Metadaten, Lupe | kostenlos, Browser-Erweiterung für Chrome und Edge; die KI-Erkennung braucht eine Registrierung |
| [Who posted what?](https://bellingcat.gitbook.io/toolkit/more/all-tools/who-posted-what) | findet Facebook-Posts nach Stichwort und Tag, genauer als die Facebook-Suche | kostenlos, nur mit Facebook-Login |
| [TikTok Timestamp](https://bellingcat.github.io/tiktok-timestamp/) | Video-Adresse einfügen: Uploadzeit auf die Sekunde, auch bei gelöschten Videos | ohne Anmeldung |
| [Bellingcat-Toolkit](https://bellingcat.gitbook.io/toolkit) | Werkzeugsammlung nach Plattform, je Eintrag mit Kosten und Konto-Bedarf | ohne Anmeldung |

Was ihr findet, gehört ins Rechercheprotokoll (siehe Abschnitt „Ergebnisse dokumentieren“): Fund mit Adresse, Datum und Konto, und was nicht ging.

---

<!-- Datei im Repo: faktencheck/text-pruefen.md -->

## Texte prüfen: das Handwerk

Aus Kapitel 5 der Seminarfolien (Grundlagen und Text). Stand: 01.11.2026.

**Prüfstufe aller Links: übernommen.** Sie stehen so auf den Folien und wurden für dieses Repo nicht erneut geöffnet.

Hier steht, wie ihr von Hand prüft. Dieselbe Methode steckt in Moby (siehe Abschnitt „Moby zum Mitnehmen“) und im Skill Faktencheck (siehe Abschnitt „Faktencheck zum Mitnehmen“). Eine einzelne Zahl oder ein Zitat bis zum Ursprung verfolgt der Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“).

### Zwei Gründe für den Faktencheck

1. **Qualitätssicherung:** Fehler, Ungenauigkeiten und Zahlendreher im eigenen oder fremden Beitrag vor der Veröffentlichung finden.
2. **Desinformation bekämpfen:** Falschbehauptungen widerlegen, KI-generierte Texte, Fotos, Audios und Videos entlarven. Desinformation ist schneller und hat immer einen Vorsprung.

Für Bilder und Videos gibt es eine eigene Seite: Bilder prüfen und Geolokation (siehe Abschnitt „Bilder prüfen und Geolokation“).

### Aus einem Satz werden viele Fakten

„Der Stadtrat hat den Zuschuss der Kammerspiele für die nächste Spielzeit erhöht.“

| Aspekt | Frage |
|---|---|
| Wer? | Ausschuss oder Vollversammlung? |
| Was genau? | Zuschuss oder Etat? |
| Wie viel? | Betrag: Ziffern, Komma, Einheit |
| Für wann? | Spielzeit oder Haushaltsjahr? „Nächste“ von wann aus? |
| Erhöht? | Gegenüber was: Vorjahr oder Planung? |

Der Satz stimmt nur, wenn jeder Aspekt stimmt. Auch ein Zitat hat Aspekte: Wortlaut, Sprecher, Anlass, Datum, Sprache, Fundort.

### Die eigenen Fehler finden

**Typische Fehler:**

- Zahlendreher: aus 1.245 wird 1.425
- alter Wert: Vorjahreszahl, Amtsinhaber von gestern
- Leichtsinn: Namen, Funktionen, Schreibweisen
- Einheiten: Mio. und Mrd., Prozent und Prozentpunkte
- Rechenfehler: Stimmt „ein Drittel mehr“?
- Datum: Wochentag, Jahr, Stichtag
- Reste aus alten Fassungen und KI-Entwürfen

**Was hilft:** jede Zahl einzeln an der Quelle abhaken, Namen kopieren statt abtippen, nachrechnen, laut lesen oder ausdrucken, jemand anderen lesen lassen.

### Grauzonen: Fakt oder nicht?

| Formulierung | Die Frage dahinter |
|---|---|
| „gilt als wichtigste Regisseurin ihrer Generation“ | Wer sagt das? Beleg oder Werbetext? |
| „laut Veranstalter 50.000 Besucher“ | Belegt ist nur, dass der Veranstalter das sagt. |
| „die ausverkaufte Premiere“ | Laut wem? Wie viele Freikarten? |
| „umstritten“, „Kritiker bemängelten“ | Wer genau, und wie viele? |
| „rund“, „mehr als“, „fast“ | Passt die Rundung zur Zahl? |
| „Der Zuschuss wird gekürzt.“ | Gegenüber was: Vorjahr oder Planung? |

**So geht ihr damit um:** den Faktenkern herauslösen und prüfen, die Zuschreibung nennen („laut Veranstalter“), die Bezugsgröße dazuschreiben. Lieber genauer formulieren als streichen.

### Triggerwörter: absolute Aussagen

erste · erstmals · einzige · größte · älteste · Rekord · immer · nie · alle · keiner · weltweit · bekanntlich

Eine absolute Aussage gilt für alle Fälle. Ein Gegenbeispiel reicht, und sie ist falsch.

- **Prüfen:** ein Gegenbeispiel suchen, mit Zeitfilter, im Archiv, in der Pressedatenbank (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“).
- **Kein Beleg?** Einschränken: „seit Beginn der Zählung 2004“, „nach Angaben des Hauses“, „eine der ersten“.

### Zitate prüfen

- **Wo steht das Original?** Rede, Interview, Mediathek, Plenarprotokoll.
- **So sucht ihr:** Name plus markante Wörter, als Phrase in Anführungszeichen, auch in der Pressedatenbank. Weicht der Wortlaut ab, hilft eine semantische Suche: die Aussage in eigenen Worten beschreiben, mit Name und Anlass, etwa in einer KI-Suche mit Quellenangaben.
- **Stimmt der Zusammenhang?** Wann und bei welchem Anlass gesagt? Übersetzt? Dann das Original in der Ausgangssprache suchen.
- **Zitatsammlungen sind ein Hinweis, nie ein Beleg.**

### Zahlen, Daten, Namen, Orte

| Was | Wo prüfen |
|---|---|
| Zahlen | Primärquelle zuerst: Haushalt, Beschlussvorlage, Statistik, Jahresbericht. Einheit prüfen, nachrechnen. |
| Daten | Lebensdaten und Jahrestage in Lexika wie Munzinger (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“), am besten zwei unabhängige Quellen |
| Namen und Funktionen | Website der Institution, aktuelle Meldungen. Ist die Person noch im Amt? Schreibweise kopieren. |
| Orte | Google Maps und, teils detailreicher, OpenStreetMap: Straßen, Entfernungen, Gebäude |

Die Werkzeuge sind dieselben wie bei der Recherche.

### Belegt ist, was ihr gefunden habt

- **Primärquelle zuerst:** Beschluss, Statistik, Originalinterview.
- **Sonst zwei unabhängige Quellen.** Wer voneinander abschreibt, zählt als eine, etwa zwei Medien mit derselben Agenturmeldung.
- **Das Datum muss passen.** Eine Quelle von 2024 belegt keinen Stand von 2026.
- **Nicht belegt?** Umformulieren oder streichen.
- Wikipedia ist ein Sprungbrett zu Quellen, keine Quelle.

Alles kommt ins Rechercheprotokoll (siehe Abschnitt „Ergebnisse dokumentieren“): Fakt, Quelle, Datum, Link.

### Wer professionell prüft

| Wer | Was | Adresse |
|---|---|---|
| dpa-Faktencheck | rund 30 Leute, unter anderem in Berlin und Brüssel; über 5.000 Faktenchecks in drei Sprachen | [dpa.com/de/faktencheck](https://www.dpa.com/de/faktencheck) |
| GADMO | German-Austrian Digital Media Observatory: dpa, AFP, APA und Correctiv mit der TU Dortmund und dem AIT; über 3.800 Faktenchecks | [gadmo.eu/faktenchecks](https://gadmo.eu/faktenchecks/) |
| Correctiv.Faktenforum | Freiwillige prüfen zusammen mit der Redaktion | [faktenforum.org](https://faktenforum.org/) |

**Schon geprüft?** Der [Fact Check Explorer](https://toolbox.google.com/factcheck/explorer) von Google durchsucht veröffentlichte Faktenchecks vieler Redaktionen.

---

<!-- Datei im Repo: faktencheck/bilder-pruefen.md -->

## Bilder prüfen und Geolokation

Aus Kapitel 5 der Seminarfolien (Bild und Video). Stand: 07.11.2026.

**Prüfstufe:** Die verlinkten Adressen sind **geöffnet am 07.11.2026**. Ausnahmen: Image Whisperer, Wolfram Alpha und das InVID-Plugin sind von den Folien **übernommen**. Baidu und SynthID ließen sich nicht öffnen und stehen als **zu prüfen** dabei. Was die Werkzeuge können und was sie kosten, ist von den Folien übernommen.

### Die Checkliste

Drei Schritte, nicht zwingend in dieser Reihenfolge:

1. **Originalquelle finden**
2. **Innere und äußere Logik prüfen**
3. **Technische Hinweise auf KI ausschließen**

Euer Bauchgefühl ist oft gar nicht schlecht. Verlassen solltet ihr euch nicht darauf.

### Welchen Fotoquellen vertraut ihr wie sehr?

| Quelle | Vertrauen |
|---|---|
| Soziale Medien, Beteiligte, Unternehmen, Stockagenturen | alles hinterfragen; Bildunterschriften können von einer KI übersetzt oder ergänzt sein |
| Nachrichtenagenturen wie dpa, AFP, AP, Reuters | nicht komplett zurücklehnen |
| selbst fotografiert oder von eigenen Fotografinnen und Fotografen | sicher |

### 1. Originalquelle finden: Rückwärtssuche

| Werkzeug | Wofür | Adresse |
|---|---|---|
| Google Lens | Standard, auch für einzelne Gebäude oder Objekte im Bild, ohne Konto | in der Google-Suche das Kamera-Symbol |
| Yandex | Bilder aus Russland, der Ukraine und Osteuropa | [yandex.com/images](https://yandex.com/images/) |
| Baidu | Bilder aus China, Oberfläche chinesisch | graph.baidu.com, zu prüfen |
| TinEye | sortiert die Treffer besser, etwa nach dem ältesten Fund | [tineye.com](https://tineye.com/) |
| Bing | warum nicht mal probieren? | in der Bing-Bildersuche das Kamera-Symbol |
| PimEyes, Lenso.ai | Gesichtersuche, meist kostenpflichtig | [pimeyes.com](https://pimeyes.com/), [lenso.ai](https://lenso.ai/) |

**Gesichter** sind besonders geschützte Daten. Die Gesichtersuche nur mit gutem Grund nutzen und den Datenschutz beachten.

**Tipp:** Das [InVID-WeVerify-Plugin](https://bellingcat.gitbook.io/toolkit/more/all-tools/invid) für Chrome bündelt alle Suchen und zerlegt Videos in Standbilder.

**Die Treffer lesen:**

- **Genaue Übereinstimmungen** zeigen dasselbe Bild. Wann und wo wurde es zuerst gepostet? Klickt immer auf die Links. Wie verlässlich ist die Quelle?
- **Visuelle Übereinstimmungen** zeigen ähnliche Bilder. Die helfen bei der Geolokation, etwa derselbe Ort aus einem anderen Blickwinkel.

### 2. Innere und äußere Logik

**Innere Logik:** Hektisch generierte Fakes sind immer noch voller Fehler.

- Personen: Schmuck, Haare und Bart, Finger und Hände, Pupillen, fehlende Hautunreinheiten (oft wachsige Haut)
- Text: vor allem im Hintergrund und in Videos
- Licht und Schatten: Wo sind die Lichtquellen? Stimmen die Spiegelungen?
- Schärfe und Unschärfe: Ergibt der Fokus Sinn? Ist er überhaupt möglich?
- Videos: Bild für Bild anschauen, etwa im VLC-Player oder mit dem InVID-Plugin

**Äußere Logik:** Ist das Foto plausibel?

- Wo wurde es aufgenommen? Satellitenbilder, etwa in [Google Earth](https://earth.google.com/).
- Stimmt das Wetter? Historische Wetterdaten, etwa in [Wolfram Alpha](https://www.wolframalpha.com/) mit einer Abfrage wie `weather Munich June 12 2026`. Kahle Bäume im Juni passen nicht.
- Wer hat es gepostet, mit welcher Absicht? Kann sein, was gezeigt wird? Soll es Wut oder Angst auslösen?

### 3. Technische Hinweise auf KI

| Werkzeug | Was es kann | Zugang |
|---|---|---|
| SynthID Detector | erkennt das Wasserzeichen, das Google, OpenAI, NVIDIA, Kakao und Apple selbst einbauen; Bild, Video, Audio | auf synthid.com oder in der Gemini-App, nur mit Anmeldung, etwa 10 Prüfungen am Tag; Adresse zu prüfen |
| [Content Credentials (C2PA)](https://verify.contentauthenticity.org/) | zeigt signierte Herkunftsangaben, die mit der Datei reisen: Aufnahme, Bearbeitung, Veröffentlichung | Datei hochladen oder Bildadresse einfügen |
| [Image Whisperer](https://www.imagewhisperer.org/) | führt viele Erkennungsmodelle zusammen und legt offen, wie es urteilt | laut Website 1 € für 2 Prüfungen; übernommen |
| Hive AI Detector | prüft Bild, Video, Text und Audio auf KI | kostenlos, ohne Konto, Erweiterung im Chrome Web Store |
| [Forensically](https://29a.ch/photo-forensics/) | findet Bearbeitungsspuren, keine KI-Erkennung | kostenlos im Browser, die Bilder bleiben auf eurem Rechner |

**Was die Ergebnisse heißen:**

- **SynthID:** Ein gefundenes Wasserzeichen heißt, dass KI im Spiel war. Kein Wasserzeichen heißt nicht, dass das Foto echt ist. Das Wasserzeichen übersteht Screenshots und Bearbeitungen, lässt sich aber entfernen. Bilder von Flux, Anthropic und chinesischen Modellen tragen es nicht.
- **C2PA:** Viele Plattformen löschen die Herkunftsdaten beim Hochladen. Meistens fehlen sie deshalb.
- **KI-Detektoren:** In Tests sind die Ergebnisse unzuverlässig. Sie geben einen Hinweis, nie das letzte Wort.

### Ein möglicher Ablauf

Eine Faustregel, kein Automatismus:

1. Originalquelle gefunden, und ihr vertraut ihr? Dann ist das Bild verwendbar.
2. Sonst: Zeigt SynthID oder C2PA KI? Dann ist es ein KI-Fake.
3. Sonst: Gibt es sichtbare Fehler, oder ist es nicht plausibel? Dann ist es ein KI-Fake.
4. Sonst: Zeigt ein Detektor wie Image Whisperer KI? Dann ist es ein KI-Fake.
5. Sonst: verwendbar, aber ein Restrisiko bleibt immer, etwa ein echtes Foto in falschem Zusammenhang. Im Zweifel mit der Bildredaktion sprechen.

### Verifikation mit Sprachmodellen?

Sprachmodelle können helfen, verlassen könnt ihr euch nie darauf. Ein schwacher Prompt fragt nur: „Ist dieses Video echt oder KI-generiert?“ Ein starker Prompt hat fünf Teile, wie der Auftrag in Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“):

```
Rolle: Du bist eine erfahrene OSINT-Analystin.
Ziel: Dieses Foto soll [was, wo, wann] zeigen. Prüfe Ort und Zeitpunkt.
Quellen: Suche die früheste Veröffentlichung in sozialen Netzwerken und seriösen Quellen. Nenne direkte Links.
Grenzen: Trenne Beobachtung von Vermutung, sag klar, was du nicht prüfen konntest. Erfinde keine Belege, urteile nicht allein nach dem Aussehen.
Format: Tabelle mit Befund, Beleg mit Link, offen.
```

Nur Bilder hochladen, die schon öffentlich sind (Spielregel 3).

### Geolokation: Wo wurde das aufgenommen?

1. **Hinweise sammeln:** Schilder und Sprache, Architektur, Kennzeichen, Vegetation, markante Bauten.
2. **Grob eingrenzen:** Land, Stadt, Viertel.
3. **Abgleichen:** Satellitenbild, Street View, Fotos anderer vom selben Ort.
4. **Zeit prüfen:** Schatten, Wetter, Jahreszeit.

| Werkzeug | Was es kann | Adresse |
|---|---|---|
| Google Maps und Google Earth | Satellit, Street View, 3D-Ansicht | [earth.google.com](https://earth.google.com/) |
| OpenStreetMap | Karte, teils detailreicher als Google: Wege, Gebäude | [openstreetmap.org](https://www.openstreetmap.org/) |
| Mapillary | Straßenfotos von Nutzerinnen und Nutzern, auch wo Street View fehlt | [mapillary.com/app](https://www.mapillary.com/app) |
| Bellingcat OSM Search | Orte über Merkmale finden, etwa „Kirche neben Bahnlinie“ | [osm-search.bellingcat.com](https://osm-search.bellingcat.com/) |
| SunCalc, Sonnenverlauf | Sonnenstand und Schatten für Ort und Uhrzeit | [suncalc.org](https://www.suncalc.org/), [sonnenverlauf.de](https://www.sonnenverlauf.de/) |
| Wolfram Alpha | historisches Wetter an Ort und Tag | [wolframalpha.com](https://www.wolframalpha.com/) |
| Rückwärtssuche | visuelle Übereinstimmungen zeigen denselben Ort aus anderen Blickwinkeln | siehe oben |

Was ihr prüft, gehört ins Rechercheprotokoll (siehe Abschnitt „Ergebnisse dokumentieren“): Bild, Werkzeug, Ergebnis, Link.

---

<!-- Datei im Repo: links/werkzeuge.md -->

## Werkzeuge nach Kapiteln

Werkzeuge, die zu den sechs Kapiteln des Seminars passen und auf den anderen Seiten noch fehlen. Was schon dort steht, steht hier nicht noch einmal: Am Anfang jedes Kapitels steht, wo ihr es findet. Stand: 10.11.2026.

**Prüfstufe:** Alle Links sind **geöffnet am 07. oder 10.11.2026**. Zugang und Preise stehen so da, wie die Anbieter sie an diesem Tag angaben, ohne Gewähr.

Die Spielregeln (siehe Abschnitt „Recherche und Faktencheck · Werkzeugkasten“) gelten auch hier: keine persönlichen Daten hochladen, nur Material, das schon öffentlich ist. Für Vertrauliches gibt es in Kapitel 6 Programme, die nur auf eurem Rechner laufen.

### 1. Recherchestrategie: planen, sichern, wer steckt dahinter

Schon im Repo: Seiten sichern und das Rechercheprotokoll in Dokumentieren (siehe Abschnitt „Ergebnisse dokumentieren“).

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [Zotero](https://www.zotero.org/) | Quellen sammeln, Webseiten mit einem Klick als Kopie sichern, Literaturliste erstellen | frei, Open Source; Mac, Windows, Linux, iOS, Android |
| [SIFT](https://hapgood.us/2019/06/19/sift-the-four-moves/) | eine Methode, kein Programm: Stop, Investigate the source, Find better coverage, Trace claims. Wer hinter einer Seite steckt, erfahrt ihr von anderen Seiten, nicht von ihr selbst („lateral lesen“) | frei, englisch |
| [Handelsregister](https://www.handelsregister.de/) | Firmen, Vereine, Genossenschaften: wer sie vertritt, seit wann es sie gibt | Registerportal der Länder |
| [Unternehmensregister](https://www.unternehmensregister.de/) | Jahresabschlüsse und Bekanntmachungen, etwa einer Theater- oder Festival-GmbH | frei |
| [North Data](https://www.northdata.de/) | Firmen und Personen und ihre Verbindungen, als Netz dargestellt, aus öffentlichen Registern | Grundsuche frei, mehr gegen Geld |
| [Lobbyregister des Bundestags](https://www.lobbyregister.bundestag.de/) | wer beim Bund Lobbyarbeit macht, für wen und mit welchem Budget | frei, ohne Konto |
| [FragDenStaat](https://fragdenstaat.de/) | Anfragen an Behörden stellen und frühere Antworten durchsuchen. Laut FragDenStaat hat Bayern kein Informationsfreiheitsgesetz, für Bundesbehörden und viele Länder geht es | frei |

### 2. Suchmaschinen und Google

Schon im Repo: Suchmaschinen im Vergleich, Operatoren und Web-Archiv in Suchen im Web (siehe Abschnitt „Suchen im Web: Suchmaschinen, Google, Web-Archiv“).

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [Mojeek](https://www.mojeek.com/) | Suchmaschine mit eigenem Index aus Großbritannien, ohne Tracking. Zeigt oft andere Treffer als Google, gut als Gegenprobe | frei |
| [Marginalia Search](https://marginalia-search.com/) | unabhängige Suchmaschine aus Schweden. Findet kleine, nicht kommerzielle Seiten und Blogs, die bei Google untergehen | frei, Open Source |
| [Google Books](https://books.google.de/) | Volltextsuche in Büchern: Wo steht ein Zitat gedruckt, und seit wann? | frei, oft nur Ausschnitte |
| [Google Trends](https://trends.google.de/trends/) | wann und wo ein Thema oder Name gesucht wurde | frei |
| [Google Alerts](https://www.google.com/alerts) | schickt eine Mail, sobald ein Suchbegriff neu im Netz auftaucht. Für Themen, die ihr länger verfolgt | frei |
| [XTools](https://xtools.wmcloud.org/) | Statistik zu einem Wikipedia-Artikel: wer ihn angelegt und wer am meisten geändert hat. Seit wann eine Behauptung im Artikel steht, zeigt die Versionsgeschichte | frei |

### 3. Datenbanken: historische Presse, Archive, amtliche Quellen

Schon im Repo: Pressedatenbanken und Munzinger in Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“), Fachportale in Kulturthemen (siehe Abschnitt „Recherche-Links zu Kulturthemen“).

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [digiPress](https://digipress.digitale-sammlungen.de/) | historische Zeitungen der Bayerischen Staatsbibliothek, fast 9 Mio. Seiten mit Volltextsuche. Was schrieb die Presse zur Uraufführung? | frei |
| [Deutsches Zeitungsportal](https://www.deutsche-digitale-bibliothek.de/newspaper) | historische Zeitungen aus ganz Deutschland, 1609–1994, mit Volltext | frei |
| [Archivportal-D](https://www.archivportal-d.de/) | Bestände deutscher Archive an einem Ort | frei |
| [KVK](https://kvk.bibliothek.kit.edu/) | Karlsruher Virtueller Katalog: sucht in vielen Bibliothekskatalogen gleichzeitig | frei |
| [Ratsinformationssystem München](https://risi.muenchen.de/) | Anträge, Sitzungsvorlagen und Beschlüsse des Stadtrats, auch zum Kulturetat | frei |
| [München Transparent](https://www.muenchen-transparent.de/) | dieselben Dokumente, besser durchsuchbar. Ein Open-Source-Projekt, nicht die Stadt: Zitiert im Zweifel die offizielle Fassung | frei |
| [Bayerischer Landtag](https://www.bayern.landtag.de/parlament/dokumente/drucksachen/) | Drucksachen: Anfragen, Anträge, Antworten der Staatsregierung | frei |
| [DIP](https://dip.bundestag.de/) | dasselbe für Bundestag und Bundesrat | frei |
| [Theaterstatistik](https://www.buehnenverein.de/de/theaterstatistik) | Besuche, Etats und Personal der Theater, jährlich vom Bühnenverein | PDF frei |
| [Statistisches Bundesamt: Kultur](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Bildung-Forschung-Kultur/Kultur/_inhalt.html) | amtliche Zahlen, etwa der Kulturfinanzbericht | frei |

Zwei Statistiken, zwei Zahlen: Für die Theaterbesuche 2023/24 nennt der Bühnenverein 25,3 Mio., das Statistische Bundesamt 20,93 Mio. Bevor ihr eine davon übernehmt, prüft, was jeweils gezählt wird.

### 4. KI-unterstützte Recherche

Schon im Repo: alle Tools aus dem Seminar in KI-Tools mit Link (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“), Prompts in Von der Frage zum Auftrag (siehe Abschnitt „Prompten: von der Frage zum Auftrag“), neue Tools finden und prüfen in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [Arena](https://arena.ai/) | Antworten verschiedener Modelle auf dieselbe Frage nebeneinander vergleichen; dazu eine Rangliste aus Nutzerstimmen. Hieß bis Januar 2026 LMArena | frei |
| [Elicit](https://elicit.com/) | Studien finden und zusammenfassen, laut Anbieter über 138 Mio. Fachartikel. Ergänzt Scholar Labs und Consensus | Grundversion frei, mehr gegen Geld |

### 5. Faktencheck: Text, Bild, Ton, Social Media

Schon im Repo: Texte prüfen (siehe Abschnitt „Texte prüfen: das Handwerk“) mit dpa, GADMO, Faktenforum und Fact Check Explorer; Bilder prüfen (siehe Abschnitt „Bilder prüfen und Geolokation“) mit Google Lens, Rückwärtssuche, Detektoren und Geolokation; Social Media durchsuchen (siehe Abschnitt „Social Media durchsuchen“).

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [CORRECTIV.Faktencheck](https://correctiv.org/faktencheck/) | geprüfte Behauptungen aus Deutschland, mit Quellen | frei |
| [BR24 #Faktenfuchs](https://www.br.de/nachrichten/faktenfuchs-faktencheck,QzSIzl3) | Faktenchecks des Bayerischen Rundfunks | frei |
| [tagesschau faktenfinder](https://www.tagesschau.de/faktenfinder) | Faktenchecks und Hintergründe der ARD | frei |
| [Mimikama](https://www.mimikama.org/) | aus Österreich: virale Bilder, Kettenbriefe, Betrugsmaschen | frei |
| [Deepfake Total](https://deepfake-total.com/) | prüft Audiodateien oder YouTube-Links auf gefälschte Stimmen, vom Fraunhofer AISEC. Liefert eine Einschätzung, keinen Beweis. Bei einer verdächtigen Sprachnachricht hilft mehr: die Person auf einem bekannten Weg zurückrufen | frei |
| [Copernicus Browser](https://browser.dataspace.copernicus.eu/) | Satellitenbilder der EU, oft nur wenige Tage alt: Gab es die Flut, den Brand, die Baustelle an diesem Tag? | frei |
| [PeakVisor](https://peakvisor.com/) | erkennt Berge und zeigt das Panorama von jedem Punkt aus: hilft bei der Geolokation in den Bergen | im Browser und als App |
| [ICANN Lookup](https://lookup.icann.org/) | wer eine Domain registriert hat und seit wann es sie gibt. Für .de-Adressen: [DENIC](https://www.denic.de/services/whois-service/) | frei |

### 6. KI-Tools für die Arbeit

Schon im Repo: Transkription, Übersetzung und Dokumente befragen in KI-Tools mit Link (siehe Abschnitt „KI-Tools für die Recherche: alle mit Link“).

🔒 = läuft auf eurem Rechner, nichts geht ins Netz. Dafür braucht es einen kräftigen Rechner, und das erste Herunterladen dauert.

| Werkzeug | Wofür | Zugang |
|---|---|---|
| [aTrain](https://github.com/aTrainTranscription/aTrain) 🔒 | Interviews transkribieren, mit Sprechererkennung, von der Uni Graz | frei, Open Source; Windows und Linux |
| [Buzz](https://buzzcaptions.com/) 🔒 | Transkription und Übersetzung mit Whisper | frei, Open Source; Windows, Linux, Mac mit Intel-Chip |
| [Jan](https://jan.ai/) 🔒 | KI-Modelle auf dem eigenen Rechner, für Material, das nicht ins Netz darf | frei, Open Source |
| [Good Tape](https://goodtape.io/) | Transkription im Browser, laut Anbieter nach DSGVO und ohne Training mit euren Daten | Test ohne Konto, dann gegen Geld |
| [Datawrapper](https://www.datawrapper.de/) | Diagramme, Karten und Tabellen für eure Texte | frei mit dem Hinweis „Created with Datawrapper“, ohne ihn gegen Geld |
| [OpenRefine](https://openrefine.org/) 🔒 | Tabellen aufräumen: Schreibweisen vereinheitlichen, doppelte Einträge finden | frei, Open Source |
| [Duden-Mentor](https://mentor.duden.de/) | Rechtschreibung und Grammatik prüfen | frei |
| [LanguageTool](https://languagetool.org/de) | dasselbe, auch als Erweiterung für den Browser | frei, mehr mit Premium |

Was ihr in die Cloud-Dienste ladet (Good Tape, Duden-Mentor, LanguageTool), verlässt euren Rechner. Für vertrauliche Interviews nehmt die Programme mit 🔒 oder noScribe.

Weiterlesen und -hören: Lesetipps (siehe Abschnitt „Lesetipps: Artikel, Podcasts, Studien, Bücher“).

---

<!-- Datei im Repo: links/lesetipps.md -->

## Lesetipps: Artikel, Podcasts, Studien, Bücher

Zum Weiterlesen und Weiterhören, quer durch die sechs Kapitel des Seminars. Die Spalte „Kap.“ sagt, wozu ein Tipp passt. Stand: 10.11.2026.

**Prüfstufe:** Alle Links sind **geöffnet am 07. oder 10.11.2026**. Bei den Büchern stammen Verlag und Jahr von Verlags-, Rezensions- und Händlerseiten.

### Artikel und Essays

| Titel | Worum es geht | Kap. |
|---|---|---|
| Henning Fries: [Nachruf: Abschied von robots.txt (1994–2025)](https://www.heise.de/hintergrund/Nachruf-Abschied-von-robots-txt-1994-2025-10752448.html), heise online, 15.10.2025 | Ein Nachruf auf die kleine Textdatei, die dreißig Jahre lang regelte, welche Bots eine Website lesen dürfen, und auf das höfliche Internet, für das sie stand. Mit Zahlen von Cloudflare, wie oft KI-Crawler Seiten abrufen und wie selten sie Leser zurückschicken. Frei lesbar | 2, 4 |
| Ted Chiang: [ChatGPT Is a Blurry JPEG of the Web](https://www.newyorker.com/tech/annals-of-technology/chatgpt-is-a-blurry-jpeg-of-the-web), The New Yorker, 09.02.2023 | Das bekannteste Bild dafür, was ein Sprachmodell ist: eine unscharfe, stark gepackte Kopie des Webs. Erklärt, warum KI-Antworten glatt klingen und trotzdem danebenliegen. Englisch | 4 |
| Anthropic: [Building effective agents](https://www.anthropic.com/research/building-effective-agents), 19.12.2024 | Was ein Workflow ist, was ein Agent, und warum man meist mit dem Einfachsten anfangen sollte. Vom Hersteller von Claude, gut lesbar. Englisch | 4 |
| Wikipedia: [Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing) | Woran Wikipedia-Autor:innen KI-Text erkennen, mit vielen Beispielen. Hilft beim Gegenlesen, ersetzt aber keinen Faktencheck. Englisch | 5 |
| Konstantin Nowotny: [The Velvet Sundown auf Spotify: Killt KI den Musikkritiker?](https://www.freitag.de/autoren/konstantin-nowotny/the-velvet-sundown-auf-spotify-wird-die-ki-den-musikkritiker-killen), der Freitag, 19.08.2025 | Eine KI-Band findet auf Spotify ein Millionenpublikum. Was das für die Musikkritik bedeutet. Frei lesbar | 5 |

### Podcasts

| Titel | Worum es geht | Kap. |
|---|---|---|
| [Die OpenAI Story](https://www.ardsounds.de/sendung/die-openai-story/urn:ard:show:8862c28ddc06b3b7/), Deutschlandfunk, 2026 | Sechs Folgen von je rund einer halben Stunde, von Fritz Espenlaub: wie aus einem gemeinnützigen Forschungslabor der Konzern hinter ChatGPT wurde, mit Machtkämpfen und roten Linien. Im selben Feed: Die Peter Thiel Story | 4 |
| [Der KI-Podcast](https://www.ardsounds.de/sendung/der-ki-podcast/urn:ard:show:65505255c703e51e/), ARD | Jeden Dienstag, für Einsteiger und Profis: Was kann KI wirklich, was ist Marketing, und wie nutzt man sie, ohne sich täuschen zu lassen? Mit Gregor Schmalzried, Marie Kilg und Fritz Espenlaub | 4, 6 |

Weitere Podcasts und Newsletter zum Dranbleiben, etwa das KI-Update von heise, stehen in Neue KI-Tools finden (siehe Abschnitt „Neue KI-Tools finden und prüfen“).

### Studien

| Titel | Was herauskam | Kap. |
|---|---|---|
| EBU und BBC: [AI assistants misrepresent news content 45% of the time](https://www.bbc.co.uk/mediacentre/2025/new-ebu-research-ai-assistants-news-content), 22.10.2025 | 22 öffentlich-rechtliche Sender aus 18 Ländern haben über 3.000 Antworten von ChatGPT, Copilot, Gemini und Perplexity auf Nachrichtenfragen geprüft. 45 Prozent hatten mindestens einen erheblichen Fehler, oft bei den Quellen. Englisch | 4, 5 |
| Tow Center: [AI Search Has a Citation Problem](https://www.cjr.org/tow_center/we-compared-eight-ai-search-engines-theyre-all-bad-at-citing-news.php), Columbia Journalism Review, 06.03.2025 | Acht KI-Suchen sollten zu kurzen Textausschnitten den Originalartikel nennen: Titel, Medium, Datum, Link. Über 60 Prozent der Antworten waren falsch, oft mit großer Gewissheit, manche mit erfundenen Links. Englisch | 4, 5 |
| Pew Research Center: [Google users are less likely to click on links when an AI summary appears](https://www.pewresearch.org/short-reads/2025/07/22/google-users-are-less-likely-to-click-on-links-when-an-ai-summary-appears-in-the-results/), 22.07.2025 | Wer eine KI-Zusammenfassung über den Treffern sieht, klickt seltener auf eine Quelle. Englisch | 2 |
| Hans-Bredow-Institut: [Reuters Institute Digital News Report 2026, Ergebnisse für Deutschland](https://leibniz-hbi.de/hbi-publications/reuters-institute-digital-news-report-2026-ergebnisse-fuer-deutschland/), Juni 2026 | Wie Menschen in Deutschland Nachrichten nutzen. Neu in diesem Jahr: Wie sie mit Originalquellen umgehen, wenn ihnen Nachrichten über Social Media, Suchmaschinen und KI-Antworten begegnen. PDF frei | 1, 4 |
| Wharton School: Prompting Science Reports, 2025, etwa [Expert Personas Don't Improve Factual Accuracy](https://gail.wharton.upenn.edu/research-and-insights/playing-pretend-expert-personas/) | Vier kurze Studien, welche Prompt-Tricks wirklich zu richtigeren Antworten führen: Rollen wie „Du bist Experte“ helfen bei Fakten nicht, Drohungen und Trinkgeld auch nicht. Englisch | 4 |

### Regeln und Leitfäden

| Titel | Was drinsteht | Kap. |
|---|---|---|
| [Pressekodex](https://www.presserat.de/pressekodex.html) des Deutschen Presserats, Fassung vom 19.03.2025 | Ziffer 2, Sorgfalt: Unbestätigtes als solches kennzeichnen. Seit 2024 sagt die Präambel: Die Verantwortung gilt auch für künstlich erzeugte Inhalte. Eine eigene Kennzeichnungspflicht für KI-Text gibt es nicht, [so der Presserat](https://www.presserat.de/presse-nachrichten-details/redaktionen-auch-fuer-ki-generierte-inhalte-ethisch-verantwortlich.html) | 4, 5 |
| Netzwerk Recherche: [KI-Positionspapier](https://netzwerkrecherche.org/wp-content/uploads/2025/09/KI-Positionspapier.pdf), September 2025 | Wann ihr KI-Einsatz offenlegt, was nie in eine Online-KI gehört (alles, was auf Informant:innen schließen lässt) und wann lokale Modelle der Ausweg sind. Kurz und praxisnah | 4, 6 |
| EU-KI-Verordnung, [Artikel 50](https://artificialintelligenceact.eu/de/article/50/) | Seit 02.08.2026 muss KI-Text gekennzeichnet werden, der die Öffentlichkeit informieren soll, außer ein Mensch hat ihn geprüft und jemand trägt die redaktionelle Verantwortung. Die Seite ist inoffiziell, zum Zitieren den Wortlaut auf EUR-Lex nehmen | 4 |
| European Journalism Centre: [Verification Handbook](https://datajournalism.com/read/handbook/verification-3) | Das Standardwerk zur Verifikation von Bildern, Videos, Konten und Kampagnen, von Praktiker:innen aus Redaktionen. Frei online, englisch | 5 |

### Bücher

| Titel | Worum es geht | Kap. |
|---|---|---|
| Juan Moreno: [Tausend Zeilen Lüge. Das System Relotius und der deutsche Journalismus](https://www.perlentaucher.de/buch/juan-moreno/tausend-zeilen-luege.html), Rowohlt Berlin 2019 | Wie ein Reporter den Spiegel jahrelang mit erfundenen Reportagen täuschte, erzählt von dem Kollegen, der es aufdeckte. Und warum die Kontrollen im Haus nicht griffen. 2022 verfilmt als „Tausend Zeilen“ | 5 |
| Karen Hao: [Empire of AI](https://www.penguin.co.uk/books/460331/empire-of-ai-by-hao-karen/9781802064650), 2025 | Die Geschichte von OpenAI, recherchiert von einer Tech-Journalistin, mit den Kosten, die selten in den Schlagzeilen stehen: Daten, Arbeit, Energie. Englisch, passt zum Podcast oben | 4 |
| Ethan Mollick: Co-Intelligenz, Redline 2025 | Wie man mit KI arbeitet, als Kollegin, Lehrer und Coach, mit vielen Beispielen. Original: Co-Intelligence, 2024. Mollick schreibt dazu den Newsletter [One Useful Thing](https://www.oneusefulthing.org/), englisch und frei | 4, 6 |

---

<!-- Datei im Repo: links/kultur.md -->

## Recherche-Links zu Kulturthemen

Aus dem Anhang der Seminarfolien, ergänzt um einige Datenbanken. Stand: 10.11.2026.

**Prüfstufe: übernommen.** Die Links stehen genau so auf Florians Folien und wurden für dieses Repo nicht erneut geöffnet. Funktioniert ein Link nicht mehr, sucht die Seite über ihren Namen oder im [Internet Archive](https://web.archive.org/). Ausnahme: Die mit **neu** markierten Einträge sind hinzugekommen und **geöffnet am 07. oder 10.11.2026**.

„via Munzinger“ heißt: Zugang über die Munzinger-Datenbank mit eurem Ausweis der Stadtbibliothek oder der Stabi, siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“). Die Module unterscheiden sich je nach Zugang etwas.

### Literatur und Text

#### Literatur-Klassiker

| Angebot | Was ihr dort findet |
|---|---|
| [Projekt Gutenberg-DE](http://www.projekt-gutenberg.org/) | deutschsprachige gemeinfreie Literatur |
| [Project Gutenberg](http://www.gutenberg.org/) | internationale gemeinfreie Literatur |
| [Deutsches Textarchiv](http://www.deutschestextarchiv.de/) | Texte vom 17. bis 20. Jahrhundert |
| [TextGrid Digitale Bibliothek](https://textgrid.de/digitale-bibliothek) | deutschsprachige Belletristik |

#### Germanistik

| Angebot | Was ihr dort findet |
|---|---|
| [Grimm'sches Wörterbuch](https://dwb.uni-trier.de/) | Deutsches Wörterbuch von Jacob und Wilhelm Grimm |
| [BDSL](http://www.bdsl-online.de/) | Bibliographie der deutschen Sprach- und Literaturwissenschaft |
| [DWDS](http://www.dwds.de/) | der deutsche Wortschatz von 1600 bis heute |
| [Kalliope](https://kalliope-verbund.info/) | Nachlässe, Briefe und Autographen in Archiven und Bibliotheken · **neu** |
| [Voyant Tools](https://voyant-tools.org/) | Lese- und Analysewerkzeuge für Texte |
| [Duden Sprachwissen](https://online.munzinger.de/publikation/duden_sprachwissen) | via Munzinger |

#### Aktuelle Literatur

| Angebot | Was ihr dort findet |
|---|---|
| [Perlentaucher](http://www.perlentaucher.de/) | Kultur- und Literaturmagazin, mit Presseschau zu Rezensionen |
| [Arts & Letters Daily](http://www.aldaily.com/) | Auswahl von Essays und Rezensionen, englisch |
| [Kritisches Lexikon zur deutschsprachigen Gegenwartsliteratur](https://online.munzinger.de/publikation/klg) | via Munzinger |
| [Kritisches Lexikon zur fremdsprachigen Gegenwartsliteratur](https://online.munzinger.de/publikation/klfg) | via Munzinger |
| [Kindlers Literatur Lexikon](https://online.munzinger.de/publikation/kll) | via Munzinger |

#### Aphorismen, Sprichwörter und Zitate

| Angebot | Was ihr dort findet |
|---|---|
| [aphorismen.de](http://www.aphorismen.de/) | Aphorismen und Sprichwörter |
| [zitate.eu](http://www.zitate.eu/) | sehr umfangreiche Zitatesammlung |

Zitatsammlungen sind Findehilfen, keine Belege. Ein Zitat prüft ihr bis zur Originalstelle, zum Beispiel mit dem Herkunftscheck (siehe Abschnitt „Herkunftscheck zum Mitnehmen“).

#### Medien: Presse, Rundfunk, Online, PR

| Angebot | Was ihr dort findet |
|---|---|
| [turi2](http://www.turi2.de/) | Branchendienst Medien und Kommunikation |
| [Meedia](http://www.meedia.de/) | Branchendienst Medien |
| [CLAP](https://clap-club.de/) | Branchenmagazin Kommunikation und PR |

### Theater, Oper und Kino

| Angebot | Was ihr dort findet |
|---|---|
| [nachtkritik.de](https://nachtkritik.de/) | Besprechungen von Theaterproduktionen |
| [theapolis](https://www.theapolis.de/de/productions/list?page=1) | Verzeichnis von Theaterproduktionen |
| [Deutscher Bühnenverein](http://www.buehnenverein.de/) | Theaterverzeichnis |
| [Der Theaterverlag](http://www.der-theaterverlag.de/) | Magazine zu Theater und Oper, viele Artikel frei lesbar |
| [operone](https://operone.de/opern/) | Opernverzeichnis |
| [Opera Guide](https://opera-guide.ch/operas/) | Opernverzeichnis |
| [Musicallexikon](http://www.musicallexikon.eu/) | Musical-Verzeichnis |
| [IMDb](http://www.imdb.com/) | Filme, Serien, Besetzung und Team |
| [filmportal.de](https://www.filmportal.de/) | deutsche Filme und Personen, vom Deutschen Filminstitut & Filmmuseum · **neu** |
| [epd Film](http://www.epd-film.de/) | Filmbesprechungen des Evangelischen Pressedienstes |
| [artechock](http://www.artechock.de/) | Filmbesprechungen |
| [Filmdienst](https://online.munzinger.de/publikation/film) | Filmkritiken, via Munzinger |

### Kunst, Architektur, Design und Museen

| Angebot | Was ihr dort findet |
|---|---|
| [art – Das Kunstmagazin](http://www.art-magazin.de/) | Artikel lest ihr über WISO oder Genios, siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“) |
| [Art History Resources](http://arthistoryresources.net/) | Linksammlung Kunstgeschichte |
| [Getty Research Portal](https://portal.getty.edu/) | digitalisierte kunsthistorische Literatur |
| [archINFORM](https://deu.archinform.net/) | internationale Architektur-Datenbank |
| [Designlexikon](http://www.designlexikon.net/) | internationales Design-Lexikon |
| [museen.de](https://museen.de/) | Museumsverzeichnis Deutschland |
| [Museums of the World](https://museu.ms/) | weltweites Museumsverzeichnis |
| [Lost Art-Datenbank](https://www.lostart.de/) | Such- und Fundmeldungen zu NS-Raubgut und Kriegsverlusten · **neu** |
| [Proveana](https://www.proveana.de/) | Datenbank der Provenienzforschung: NS-Raubgut, Kriegsverluste, Entziehungen in SBZ und DDR, Sammlungsgut aus kolonialen Kontexten · **neu** |

### Musik, Audio, Video

| Angebot | Was ihr dort findet |
|---|---|
| [AllMusic](http://www.allmusic.com/) | Musikdatenbank, englisch |
| [MusicBrainz](https://musicbrainz.org/) | offene Musik-Enzyklopädie: Künstler, Veröffentlichungen, Aufnahmen · **neu** |
| [miz.org](https://miz.org/) | Deutsches Musikinformationszentrum: Zahlen und Studien zum Musikleben, Institutionen · **neu** |
| [klassik.com Lexikon](https://magazin.klassik.com/lexikon/list.cfm?letter=A) | Lexikon zur klassischen Musik |
| [IMSLP](https://imslp.org/) | Noten-Archiv |
| [Volkslieder-Verzeichnis](https://ingeb.org/Volksong.html) | Volkslieder mit Texten |
| [Munzinger Pop](https://online.munzinger.de/publikation/pop) | via Munzinger |
| [Komponisten der Gegenwart](https://online.munzinger.de/publikation/kdg) | via Munzinger, nur im Stabi-Zugang |
| [fyyd](https://fyyd.de/) | Datenbank überwiegend deutschsprachiger Podcasts |
| [Podsearch](https://podsearch.com/) | Datenbank englischsprachiger Podcasts |
| [ARD Audiothek](http://www.ardaudiothek.de/) | Mediathek der öffentlich-rechtlichen Radiosender |
| [MediathekViewWeb](https://mediathekviewweb.de/) | durchsucht die öffentlich-rechtlichen TV-Mediatheken aus Deutschland, Österreich und der Schweiz, Syntax siehe Datenbanken (siehe Abschnitt „Datenbanken: Zugänge und Suchsyntax“) |
